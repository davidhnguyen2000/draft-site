"""The shipped robot specifications.

One directory per robot, and a robot IS its directory: `parameters.yaml` (a flat
table of numbers), `tree.yaml` (the kinematic tree, whose numeric fields are
expressions over that table) and, where the root body is not a cylinder, a
`mesh.yaml` of stacked cross-sections to loft. Nothing here is Python.

Discovery is simply "every directory that has a parameters.yaml and a tree",
so adding a robot means adding a folder — no engine code, no registry entry.
Ask for one by name rather than rebuilding the path from a repo root, which is
what `robot_dir` is for: it works the same from a checkout and an installed
wheel.
"""

from pathlib import Path

#: Directory holding one subdirectory per robot.
ROBOTS_DIR = Path(__file__).resolve().parent


def robot_dir(name: str) -> Path:
    """The directory for one robot, checked to exist.

    Raises FileNotFoundError naming what IS available, because the usual cause
    is a typo and the usual next question is "so what can I ask for?".
    """
    d = ROBOTS_DIR / name
    if not (d / "parameters.yaml").exists():
        raise FileNotFoundError(
            f"no robot {name!r} in {ROBOTS_DIR}. Available: {', '.join(available())}")
    return d


def available() -> list[str]:
    """Every robot that has a parameter table and a tree beside it."""
    return sorted(
        d.name for d in ROBOTS_DIR.iterdir()
        if d.is_dir() and (d / "parameters.yaml").exists()
        and ((d / "tree.yaml").exists() or (d / "tree.py").exists()))
