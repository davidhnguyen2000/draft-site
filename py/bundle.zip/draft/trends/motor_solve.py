"""Design a motor class from any TWO of (torque, speed, gear ratio, power).

A class used to be stated exactly one way — peak torque *and* no-load speed, with
the reduction declared alongside — and the fitted trends were applied to that triple
afterwards, as an opinion about it. But (tau, omega, N) is over-stated: the speed
law ``omega = 235.1 * N^-0.944`` (R^2=0.91, n=102) already ties output speed to
reduction, so a designer who has chosen a gearbox has chosen a speed, and one who
has chosen an output power and a gearbox has chosen both.

This module makes WHICH TWO you state a declared choice — ``<cls>_motor_mode`` —
and solves the rest from the fits. Two things follow from that:

* the same solve runs in the generator and in the GUI, so what the editor draws
  is what the pipeline builds, rather than the editor showing a number the
  pipeline then derives differently;
* the actuator's SCALE stops being a separate decision. Mass, radius, length,
  density and armature all fall out of (tau, N) through ``MotorTrends.size``, so
  moving the gear ratio moves the motor, live.

Modes
-----
``torque_speed``  tau, omega stated; N declared, else the anchor's, else inferred
                  from the speed trend. The historical behaviour, and the default.
``torque_gear``   tau, N stated; omega = speed trend (N).
``power_gear``    P, N stated; omega = speed trend (N), tau = 4P/omega.
``power_torque``  P, tau stated; omega = 4P/tau; N as in ``torque_speed``.

P is the catalogue's peak-power convention, ``tau*omega/4`` — which for the linear
torque-speed envelope this module draws is exactly the maximum of tau(omega)*omega,
reached at half the no-load speed. So "peak power" is not a separate convention
bolted on: it is the top of the curve.

Aspect ratio
------------
Geometry is the airgap relation, ``tau/N = 2*pi*sigma*r^2*L`` — see ``MotorTrends.size``.
It fixes ``r^2*L`` from the same (tau, N) the mass trend reads and says nothing about
how that splits, so ``<cls>_motor_aspect`` (L/D) is a live input in every mode. Its
default is the catalogue's own split at that (tau, N), R^2 = 0.64. Overriding it is
not consequence-free — armature goes as ``q^-2/3`` at fixed volume, and both the
radius envelope and the packing gate read r.

Frontier ceilings
-----------------
Because mass follows ``m = C(N) * tau^0.6798``, torque density ``tau/m`` RISES with
torque, so the catalogued frontier is a hard ceiling on tau at a given reduction
rather than a band you drift through::

    tau/m <= td_max     =>  tau <= (td_max * C)^(1/(1-e))
    tau*omega/4/m <= pd_max  =>  tau <= (4*pd_max*C/omega)^(1/(1-e))

``frontier_ceilings`` returns both, so a design can be shown the wall it is
walking towards instead of only being told it hit it.

stdlib only — the GUI, the generator and the plotters share one implementation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Sequence

from .feasibility import MotorTrends, motor_fits

#: Modes in the order a picker should offer them.
MODES: tuple[str, ...] = ("torque_speed", "torque_gear", "power_gear", "power_torque")

#: Human-readable name for each mode — what you state, and what follows.
MODE_LABELS: dict[str, str] = {
    "torque_speed": "torque + speed  (mass ← laws)",
    "torque_gear":  "torque + gear  (speed ← law)",
    "power_gear":   "power + gear  (torque, speed ← laws)",
    "power_torque": "power + torque  (speed = 4P/τ)",
}

#: The class inputs each mode READS. Everything else with these names is solved,
#: and the GUI greys it out rather than letting a stale number sit there.
MODE_INPUTS: dict[str, tuple[str, ...]] = {
    "torque_speed": ("effort", "velocity", "gear"),
    "torque_gear":  ("effort", "gear"),
    "power_gear":   ("power", "gear"),
    "power_torque": ("power", "effort", "gear"),
}

#: Fields the fitted trends own outright — see ``core/feasibility.py``.
DERIVED_FIELDS: tuple[str, ...] = ("r", "L", "rho", "armature", "mass")

#: Inputs every mode accepts, on top of the two its name states. ``aspect`` is
#: the actuator's slenderness L/D: the mass trend buys a VOLUME and the shape of
#: that volume is the designer's, so it is editable in every mode and defaults to
#: the population's own slenderness at this mass.
FREE_INPUTS: tuple[str, ...] = ("aspect",)


def normalize_mode(mode: object) -> str:
    """Mode name, defaulting to the historical torque+speed statement."""
    m = str(mode) if mode is not None else ""
    return m if m in MODE_INPUTS else "torque_speed"


def peak_power_W(tau_Nm: float, omega_rad_s: float) -> float:
    """The catalogue's peak mechanical power convention, tau*omega/4."""
    return tau_Nm * omega_rad_s / 4.0


# ── Operating point ───────────────────────────────────────────────────────────

@dataclass(frozen=True)
class OperatingPoint:
    """One actuator class's (tau, omega, N), and where each number came from."""

    tau: float
    omega: float
    gear: float
    mode: str
    gear_source: str
    notes: tuple[str, ...] = ()

    @property
    def power(self) -> float:
        return peak_power_W(self.tau, self.omega)


def _resolve_gear(gear: Optional[float], omega: Optional[float],
                  anchor: Optional[dict], laws: MotorTrends) -> tuple[float, str, list[str]]:
    """The reduction a class runs at, and how we know it.

    Declared beats the catalogue part beats the speed trend. Mass and armature both
    depend on N, so an inferred one is reported rather than assumed away.
    """
    if gear is not None:
        return float(gear), "declared", []
    if anchor and anchor.get("gear"):
        return float(anchor["gear"]), "catalogue_part", []
    if omega is None:
        raise ValueError("cannot infer a gear ratio without a declared no-load speed")
    n = laws.gear_from_speed(float(omega))
    return n, "inferred_from_speed_trend", [
        f"no gear ratio declared and none implied by a catalogue part — inferred "
        f"N={n:.1f} from the declared {omega:.1f} rad/s no-load speed. Mass and "
        f"armature both depend on it; declare it to pin it down."]


def solve_point(mode: str, *, effort: Optional[float] = None,
                velocity: Optional[float] = None, gear: Optional[float] = None,
                power: Optional[float] = None, anchor: Optional[dict] = None,
                laws: Optional[MotorTrends] = None) -> OperatingPoint:
    """Solve (tau, omega, N) from the two quantities ``mode`` says are stated."""
    laws = laws or motor_fits()
    mode = normalize_mode(mode)
    notes: list[str] = []

    def _need(value: Optional[float], name: str) -> float:
        if value is None:
            raise ValueError(f"mode {mode!r} needs {name}, which is not declared")
        return float(value)

    if mode == "torque_gear":
        tau = _need(effort, "peak torque")
        n, src, ns = _resolve_gear(gear, velocity, anchor, laws)
        omega = laws.speed_coef * n ** laws.speed_exp
        notes += ns
    elif mode == "power_gear":
        p = _need(power, "peak power")
        n, src, ns = _resolve_gear(gear, velocity, anchor, laws)
        omega = laws.speed_coef * n ** laws.speed_exp
        tau = 4.0 * p / omega
        notes += ns
    elif mode == "power_torque":
        p = _need(power, "peak power")
        tau = _need(effort, "peak torque")
        omega = 4.0 * p / tau
        n, src, ns = _resolve_gear(gear, omega, anchor, laws)
        notes += ns
    else:  # torque_speed
        tau = _need(effort, "peak torque")
        omega = _need(velocity, "no-load speed")
        n, src, ns = _resolve_gear(gear, omega, anchor, laws)
        notes += ns

    return OperatingPoint(tau=tau, omega=omega, gear=n, mode=mode,
                          gear_source=src, notes=tuple(notes))


# ── Mass response and the frontier ceilings it implies ────────────────────────

def mass_coefficient(gear: float, anchor: Optional[dict],
                     laws: Optional[MotorTrends] = None) -> tuple[float, float]:
    """(C, e) with actuator mass = C * tau^e at this reduction.

    Splitting the mass trend this way is what makes the frontier invertible: at a
    fixed N the only free variable left is torque, so "the heaviest torque this
    gearbox can carry" has a closed form instead of needing a search.

    Since the trend dropped its gear term, C no longer varies with N for an
    unanchored class — the split is kept because an ANCHORED class still reads
    its reference part's reduction, and because the frontier is quoted per
    reduction either way.
    """
    laws = laws or motor_fits()
    e = laws.tau_exp
    if anchor and anchor.get("gear"):
        c = (anchor["mass"] * anchor["tau"] ** -e
             * (gear / anchor["gear"]) ** laws.gear_exp)
    else:
        c = laws.mass_coef * gear ** laws.gear_exp
    return c, e


def frontier_of(category: Optional[str], laws: Optional[MotorTrends] = None) -> dict:
    """The catalogued density frontier for an actuator family (or ALL)."""
    laws = laws or motor_fits()
    return laws.frontier.get(category or "ALL", laws.frontier["ALL"])


def frontier_ceilings(gear: float, omega: float, anchor: Optional[dict] = None,
                      category: Optional[str] = None,
                      laws: Optional[MotorTrends] = None) -> dict:
    """Largest peak torque the catalogued frontier allows at this (N, omega).

    Two independent walls — torque density and power density — inverted through
    the mass trend. The binding one is whichever is lower.
    """
    laws = laws or motor_fits()
    c, e = mass_coefficient(gear, anchor, laws)
    front = frontier_of(category, laws)
    inv = 1.0 / (1.0 - e)
    out = {"by_torque_density": (front["torque_density_Nm_per_kg"]["max"] * c) ** inv}
    if omega > 0:
        out["by_power_density"] = (
            4.0 * front["power_density_W_per_kg"]["max"] * c / omega) ** inv
    else:
        out["by_power_density"] = float("inf")
    out["tau_max"] = min(out["by_torque_density"], out["by_power_density"])
    out["binding"] = ("torque_density"
                      if out["by_torque_density"] <= out["by_power_density"]
                      else "power_density")
    return out


def _density_status(value: float, stats: dict) -> str:
    if value > stats["max"]:
        return "beyond_frontier"
    return "above_p90" if value > stats["p90"] else "ok"


# ── A designed class ──────────────────────────────────────────────────────────

@dataclass
class ClassDesign:
    """One motor class solved end to end: stated inputs → operating point → scale."""

    cls: str
    point: OperatingPoint
    sized: dict
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
    anchor: Optional[dict] = None
    #: The population this class was solved against. Carried on the design rather
    #: than looked up again, so a frontier verdict cannot be read out of a
    #: different catalogue than the one that sized the actuator.
    laws: Optional[MotorTrends] = None

    @property
    def category(self) -> str:
        return self.sized.get("category") or "ALL"

    @property
    def mass(self) -> float:
        return float(self.sized["mass"])

    @property
    def torque_density(self) -> float:
        return self.point.tau / self.mass

    @property
    def power_density(self) -> float:
        return self.point.power / self.mass

    def densities(self, laws: Optional[MotorTrends] = None) -> dict:
        """Both density metrics against the frontier of this class's family."""
        front = frontier_of(self.sized.get("category"), laws or self.laws)
        td, pd = front["torque_density_Nm_per_kg"], front["power_density_W_per_kg"]
        return {
            "category": self.category,
            "torque_density": {"value": self.torque_density, "unit": "Nm/kg",
                               "p90": td["p90"], "max": td["max"],
                               "argmax": td["argmax"],
                               "status": _density_status(self.torque_density, td)},
            "power_density": {"value": self.power_density, "unit": "W/kg",
                              "p90": pd["p90"], "max": pd["max"],
                              "argmax": pd["argmax"],
                              "status": _density_status(self.power_density, pd)},
        }

    def ceilings(self, laws: Optional[MotorTrends] = None) -> dict:
        return frontier_ceilings(self.point.gear, self.point.omega, self.anchor,
                                 self.sized.get("category"), laws or self.laws)

    def as_params(self) -> dict:
        """The ``<cls>_motor_*`` keys this design implies, inputs and derived alike."""
        c = self.cls
        out = {f"{c}_motor_effort": self.point.tau,
               f"{c}_motor_velocity": self.point.omega,
               f"{c}_motor_gear": self.point.gear,
               f"{c}_motor_power": self.point.power,
               f"{c}_motor_mode": self.point.mode,
               f"{c}_motor_aspect": self.sized["aspect"]}
        for f in DERIVED_FIELDS:
            out[f"{c}_motor_{f}"] = self.sized[f]
        return out


def catalog_name_for(cls: str, params: dict) -> Optional[str]:
    """Catalogue part a class is anchored on, from either spelling."""
    name = params.get(f"_{cls}_motor_catalog")
    if not isinstance(name, str):
        name = params.get(f"{cls}_motor")
    return name if isinstance(name, str) else None


def design_class(cls: str, params: dict,
                 laws: Optional[MotorTrends] = None) -> ClassDesign:
    """Solve one motor class out of a flat parameter dict.

    Reads ``<cls>_motor_mode`` to decide which inputs are stated, falls back to
    whatever numbers ARE present when a mode's input is missing (so switching
    modes in an editor never lands on a half-defined class), and returns the full
    trend-derived envelope plus the frontier verdict.

    The trends come from the one fitted actuator catalogue, so the generator
    and the GUI cannot disagree about
    it and a hand is never priced by the hip catalogue.
    """
    laws = laws or motor_fits()
    mode = normalize_mode(params.get(f"{cls}_motor_mode"))
    warnings: list[str] = []

    cat_name = catalog_name_for(cls, params)
    anchor = laws.anchor(cat_name) if cat_name else None
    if cat_name and anchor is None:
        warnings.append(
            f"[{cls}] catalogue part '{cat_name}' has no published envelope — "
            f"falling back to the population fit for this class.")

    def _num(key: str) -> Optional[float]:
        v = params.get(f"{cls}_motor_{key}")
        return None if v is None else float(v)

    effort, velocity = _num("effort"), _num("velocity")
    gear, power = _num("gear"), _num("power")
    aspect = _num("aspect")          # free in every mode; None = population fit
    # A mode's input may simply not be in the file yet (`power` never is, for a
    # design written before modes existed). Seed it from the pair that IS there
    # rather than refusing: the seeded value is the same operating point, just
    # re-parameterised, so nothing about the robot changes.
    if power is None and effort is not None and velocity is not None:
        power = peak_power_W(effort, velocity)

    point = solve_point(mode, effort=effort, velocity=velocity, gear=gear,
                        power=power, anchor=anchor, laws=laws)
    warnings.extend(f"[{cls}] {n}" for n in point.notes)

    sized = laws.size(point.tau, point.gear, anchor, aspect=aspect)
    errors, warns = laws.check(f"[{cls}]", point.tau, point.omega, point.gear, sized)
    warnings.extend(warns)
    return ClassDesign(cls=cls, point=point, sized=sized, errors=list(errors),
                       warnings=warnings, anchor=anchor, laws=laws)


# ── Curves, for plotting the shift ────────────────────────────────────────────

def speed_axis(designs: Sequence[ClassDesign], n: int = 96,
               pad: float = 1.08) -> list[float]:
    """A shared omega grid covering every class's envelope.

    Shared because uplot draws one x array for all series; padded so a curve that
    is currently the fastest still has room to grow when you drag it.
    """
    hi = max((d.point.omega for d in designs), default=1.0) * pad
    hi = max(hi, 1e-3)
    return [hi * i / (n - 1) for i in range(n)]


def envelope_curve(point: OperatingPoint, omegas: Sequence[float]) -> list[float]:
    """Torque available at each speed: the straight line from stall to no load.

    NaN past the no-load speed, so the plotted line ends where the actuator does
    instead of continuing into negative torque.
    """
    return [point.tau * (1.0 - w / point.omega) if w <= point.omega else float("nan")
            for w in omegas]


def frontier_curve(design: ClassDesign, omegas: Sequence[float],
                   laws: Optional[MotorTrends] = None) -> list[float]:
    """The torque the best catalogued actuator OF THIS MASS could hold at each speed.

    ``min(td_max*m, 4*pd_max*m/omega)`` — a torque-density plateau that rolls off
    into a constant-power hyperbola. Drawn against the class's current mass, so it
    moves with the design and shows how much headroom a change just spent.
    """
    front = frontier_of(design.sized.get("category"), laws or design.laws)
    m = design.mass
    td = front["torque_density_Nm_per_kg"]["max"] * m
    pd = 4.0 * front["power_density_W_per_kg"]["max"] * m
    return [td if w <= 0 else min(td, pd / w) for w in omegas]
