# `draft.trends` — §IV, grounding the model parameters

**The claim:** the generator guarantees a model is internally consistent; it does
not guarantee the design could be built. This is what makes it buildable — trends
fitted to 114 catalogued actuators and 49 published robot descriptions, compiled
back into the pipeline as a named catalogue and a validator that runs on every
generated model.

| file | what it owns |
|---|---|
| `feasibility.py` | `MotorTrends`, `LinkTrends`, `BatteryTrend`, and every refusal |
| `motor_solve.py` | the two numbers a design states about an actuator class → the eight the generator needs |
| `motor_catalog.py` | resolving a class anchored on a named catalogue part |
| `data/` | the fitted coefficients themselves |

## Why `data/` is here and not beside the datasets

§IV-E argues that "the generator reads the catalog and the thresholds from these
same files at generation time, so the pipeline and the numbers reported here
cannot drift apart." That used to be implemented as a relative path reaching
sideways into a sibling directory, which broke the moment the package was
installed. Four files now ship *with* the code:

```
data/actuator_trends.json    the four fitted actuator relations, per Table I
data/actuator_catalog.json   the 114 modules, for anchoring a class on a real part
data/battery_trends.json     the Ragone frontier and the pack-sizing rule
data/link_trends.json        structural density, allometry, mass fractions
```

The numbered stages under `datasets/*/scripts/` are their **only** writers.
Nothing here writes them back.

## Keep the two words apart

The *fits* are **trends**: regressions over a finite sample of real hardware, not
statements about what is physically possible. Call them laws and a reader will
over-trust them. What the pipeline does with them — sizing a design, then judging
whether it could exist — is a **feasibility check**.

The one genuine law in the chain is the airgap relation `τ_rotor ∝ r²ℓ`, which is
imposed by physics rather than fitted; the catalogue supplies only the shear
stress it leaves out.

## The refusals

A class above its family's frontier raises `FeasibilityViolation` and nothing is
written. So does a pair of actuators sharing the same litre of space when they
are consecutive on one chain, where no joint angle can separate them.
`allow_hypothetical: true` and `allow_motor_overlap: true` downgrade these to
warnings recorded in `feasibility_report.yaml` — which is how the deliberately
beyond-frontier designs in this repository are built at all.

The frontier is not a fitted trend. It is the extreme of what the catalogue
contains, and because mass goes as `τ^0.666` torque density *rises* with torque,
so it is a hard ceiling on torque at a given reduction rather than a band.

## Read before quoting a number

`armature` is still the loosest number the generator emits. Quote reflected
inertia at **1.56×** — the error on what a design gets back after stating a
torque and a speed, which compounds the radius step's 1.11× through the fourth
power. The 1.44× in `loo_prediction.json` scores the rule against a part's own
measured radius, which the pipeline never has.

The law is `J = 27.2·r⁴`, r⁴ imposed by rigid-body physics and one areal
constant fitted onto it. It replaced `φ·½ρπr⁴ℓ` — identically `φ·½·m·r²`, half
the whole module at the package radius — which billed a rotor for the length of
its gearbox and so over-predicted the most geared parts. See the note on
`MotorTrends` in `feasibility.py` before leaning on any of it.

Methodology, validation, limitations and how to add an entry:
[`docs/actuator-dataset.md`](../../../docs/actuator-dataset.md) and
[`docs/robot-dataset.md`](../../../docs/robot-dataset.md).
