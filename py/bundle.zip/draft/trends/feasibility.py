"""Feasibility — is this design buildable, and what does the data say it weighs?

Two things live here, and the names keep them apart. The empirical FITS are laws:
they are regressions over real hardware, they are called ``MotorTrends``,
``LinkTrends`` and ``BatteryTrend``, and they are read from ``*_trends.json`` in
``datasets/actuators/`` and ``datasets/robot_descriptions/``. What the generator does WITH them — sizing a
design and then judging whether it could exist — is a feasibility check, which is
what this module, ``FeasibilityViolation`` and ``feasibility_report.yaml`` are
named for. A fit is a description of hardware; a check is a verdict on a design.

Before this module the fits were analysis artifacts: a sweep script applied them,
everything else was free to ignore them. ``parameters.yaml`` could name a 5000 Nm
actuator in a 68 g package and the pipeline would emit it. Now they are the SOURCE
of the numbers instead of a post-hoc opinion about them.

Three fit families, all committed:

  src/draft/trends/data/actuator_trends.json   actuator mass / geometry / rotor inertia
  src/draft/trends/data/battery_trends.json   Ragone-frontier battery pack sizing
  src/draft/trends/data/link_trends.json      link + segment mass fractions, 21 humanoids

Which quantities are DERIVED (you cannot set them) and which are INPUTS:

  input    two of (peak torque τ, no-load speed ω, gear ratio N, peak power P),
           link lengths, `link_rho`
  derived  the rest of that quadruple, motor radius r, motor length L, motor
           density ρ, joint armature, torso density (from the battery pack the
           design implies), and every segment density the population measures
  checked  torque density, power density, radius envelope, ω vs the speed trend,
           link density band, actuator packing, actuator mass fraction, trunk
           mass fraction, mass vs size

The derived set is exactly the set that used to be hand-written and wrong: the
humanoid shipped armature = 0.01 for a joint whose declared AK80-64 reduction
implies 0.55, and a torso density fixed at 650 kg/m³ regardless of how much
motor power the design installed.

Why the operating point stays partly free
-----------------------------------------
Torque, speed, reduction and power are what a designer actually chooses, and the
fits do not over-determine them: ``speed_vs_gear`` (R²=0.79) is a population trend
with real scatter, not a constraint. So a design states any TWO of them and
``core/motor_solve.py`` solves the rest; under the default ``torque_speed`` mode ω
is checked against the speed trend rather than replaced by it, which keeps an
independent power axis for the power×gear sweep.

Anchoring
---------
When a class names a catalogued part (``_L_motor_catalog: AK80-64``) the trend is
applied RELATIVE to that part's measured mass and envelope, so a design built on
a real actuator gets that actuator's real numbers and the trend only charges the
DEVIATION from it. Only unanchored classes fall back to the absolute population
fit, which carries the full ±(fit scatter) of a 53-point regression.

Nothing here imports MuJoCo, numpy or torch — stdlib + json only, so the
generator, the sweeps and the plotters can all share one implementation.
"""

from __future__ import annotations

import json
import math
import re
from pathlib import Path
from typing import Optional

#: The fitted trends ship as package data, beside this module, rather than in the
#: dataset directories that produced them. That is what makes the guarantee in
#: the paper structural rather than a convention: an installed Draft reads the
#: same four files the reported numbers were computed from, so the pipeline and
#: those numbers cannot drift apart. The stages under ``datasets/`` are the only
#: writers; nothing here writes them back.
_DATA = Path(__file__).resolve().parent / "data"
ACTUATOR_TRENDS_JSON = _DATA / "actuator_trends.json"
BATTERY_TRENDS_JSON = _DATA / "battery_trends.json"
LINK_TRENDS_JSON = _DATA / "link_trends.json"
CATALOG_JSON = _DATA / "actuator_catalog.json"


class FeasibilityViolation(ValueError):
    """Raised when a design is not physically realisable under the fitted trends.

    Carries every violation found, not just the first, so one generation attempt
    reports the full story instead of one error at a time.
    """

    def __init__(self, messages: list[str]):
        self.messages = messages
        super().__init__("\n".join(["design violates the fitted physical laws:"]
                                   + [f"  - {m}" for m in messages]))


def _load(path: Path) -> dict:
    with Path(path).open() as f:
        return json.load(f)


#: Parameters that are OUTPUTS of a datasets/robot_descriptions calibration stage, not choices.
#:
#: These are set by the fits — but not by any single fitted trend this module can
#: evaluate at generation time. Each is solved by gridding it, GENERATING A REAL
#: MODEL at every point and scoring that model against every measured limb class
#: at once, because what the data constrains is the product ``rho * r^2`` (the
#: structural linear density lambda) rather than either factor. No one class's
#: median can stand in: on the shipped humanoid the per-class lambda fits demand
#: 781 / 302 / 162 / 291 kg/m3 for thigh / shank / upper arm / forearm, and 700
#: is the compromise the grid picked.
#:
#: So they stay inputs — and are labelled as calibrated, so nobody mistakes one
#: for a free number. Changing a design's structure means re-running its stage,
#: not nudging the value.
CALIBRATED_PARAMS: dict[str, str] = {
}


# ── Motor laws ────────────────────────────────────────────────────────────────

def parse_gear_ratio(text: str) -> Optional[float]:
    """Pull a reduction ratio out of a catalogue name or notes field.

    FALLBACK ONLY. Every catalogue row now carries a checked ``gear`` field and
    ``anchor()`` reads that; this is what remains for a row predating it. Do not
    reach for it first: a row's ``notes`` are prose that often discusses a
    SIBLING part number's ratio, so the regex reads the wrong variant — which is
    exactly the bug that once cost the datasets/actuators fits 38 of 102 geared rows and
    mis-read 8 more.

    Matches the two forms the catalogue actually uses: ``"9:1 planetary"`` in
    notes and the trailing number of a CubeMars-style name (``AK80-64``). Returns
    None when neither is present rather than guessing.
    """
    if not text:
        return None
    m = re.search(r"(\d+(?:\.\d+)?)\s*:\s*1", text)
    if m:
        return float(m.group(1))
    m = re.search(r"[A-Za-z]+\d+-(\d+(?:\.\d+)?)", text)
    return float(m.group(1)) if m else None


class MotorTrends:
    """Sizes and vets an actuator class from (peak torque, gear ratio).

    ``size()`` returns the whole physical envelope — mass, radius, length,
    effective density and reflected rotor inertia — with density solved so that
    ``ρ·π·r²·L`` reproduces the trend's mass EXACTLY. That closure is what stops
    the generator from emitting a cylinder whose mass disagrees with the mass the
    law charged for it, which is how the old free-parameter set drifted.
    """

    def __init__(self,
                 laws_path: Path | None = None,
                 catalog_path: Path | None = None):
        laws_path = laws_path or ACTUATOR_TRENDS_JSON
        catalog_path = catalog_path or CATALOG_JSON
        laws = _load(laws_path)
        self._laws = laws
        ml, gm, il = laws["mass_trend"], laws["geometry_from_mass"], laws["inertia_trend"]
        raw = laws["raw_fits"]

        # mass_kg = coef · τ^tau_exp   (n=103, R²=0.90)
        #
        # Torque alone. A reduction term was fitted and then dropped: it landed
        # at -0.021 ± 0.034, moved mass by 7% across a catalogue spanning 6:1 to
        # 161:1, and a paired leave-one-out test could not separate the two laws
        # (Δ fold error 0.0008, CI95 [-0.011, 0.012]). So how a joint's torque is
        # produced costs nothing in mass, and a reduction is paid for in speed
        # and in reflected inertia instead. `gear_exp` survives as exactly 0.0 so
        # that every call site below can keep reading a (τ, N) power law.
        self.mass_coef = ml["coef"]
        self.tau_exp = ml["tau_exp"]
        self.gear_exp = ml.get("gear_exp", 0.0)
        self.gear_median = ml["N_median"]

        # geometry split off MASS (not off torque), as VOLUME + SHAPE rather than
        # as radius + length. The two are the same fit — log V = log(pi r^2 L) is a
        # linear combination of the r(m) and L(m) regressions, so volume_exp IS
        # 2*radius_exp + length_exp and nothing is refitted — but they separate the
        # information the way a designer meets it: how much SPACE the actuator needs
        # is set by its mass (rho is the exact complement), while its SLENDERNESS
        # q = L/D is not. q correlates with nothing the designer states (R^2 0.09 vs
        # mass, 0.00 vs peak power) and strongly with the reduction the design has
        # already chosen (R^2 0.56), so it is a free input with a measured band, not
        # a law. At the default q this reproduces the old r(m)/L(m) exactly.
        self.radius_exp = gm["radius_exp"]
        self.length_exp = gm["length_exp"]
        self.radius_coef_mm = raw["radius_vs_mass"]["coef"]
        self.length_coef_mm = raw["length_vs_mass"]["coef"]
        # ── Geometry: the airgap relation, driven by the same (tau, N) as mass ────
        # A motor makes torque by shearing its airgap:
        #     tau_rotor = sigma * (2*pi*r_a*L_a) * r_a = 2*pi*sigma*r_a^2*L_a
        # so tau/N goes as r^2*L. That proportionality is IMPOSED — it is how the
        # machine works, not something a regression votes on — and what the
        # catalogue supplies is the two things the argument does not: that we
        # measure the PACKAGE rather than the airgap (and the rotor's share of it
        # shrinks as the gearbox grows, exponent k), and that sigma itself rises
        # with machine size (exponent s). Inverted for the generator:
        #     pi*r^2*L = tau^(1-s) * N^(k-1) / (2*sigma0)
        # This SUPERSEDES splitting geometry off the mass trend. Leave-one-out it
        # predicts radius at 1.12x against 1.19x, length 1.14x against 1.19x and
        # slenderness 1.19x against 1.35x, because (tau, N) is what a motor's
        # torque actually depends on and mass is a noisier stand-in for it.
        gl = laws.get("geometry_trend")
        if gl:
            self.sigma0_Pa = gl["sigma0_Pa"]
            self.shear_tau_exp = gl["s_torque_exp"]
            self.shear_gear_exp = gl["k_gear_exp"]
            # Derived from (sigma0, s, k) rather than read from the JSON's own
            # convenience fields, which are the same numbers rounded separately:
            # this keeps tau/N = 2*pi*sigma*r^2*L an identity to floating point,
            # so the trend and the shear stress it reports cannot drift apart.
            self.volume_coef_m3 = 1.0 / (2.0 * self.sigma0_Pa)
            self.volume_tau_exp = 1.0 - self.shear_tau_exp
            self.volume_gear_exp = self.shear_gear_exp - 1.0
            self.aspect_coef = gl["q_coef"]
            self.aspect_tau_exp = gl["q_tau_exp"]
            self.aspect_gear_exp = gl["q_gear_exp"]
        else:
            # A pre-2026-08-29 laws file: fall back to geometry split off mass,
            # written as a (tau, N) law so the rest of this class is unchanged.
            v_exp = 2 * self.radius_exp + self.length_exp
            q_exp = self.length_exp - self.radius_exp
            m_c, m_t, m_g = ml["coef"], ml["tau_exp"], self.gear_exp
            self.sigma0_Pa = None
            self.shear_tau_exp = self.shear_gear_exp = None
            self.volume_coef_m3 = (math.pi * self.radius_coef_mm ** 2
                                   * self.length_coef_mm * 1e-9) * m_c ** v_exp
            self.volume_tau_exp, self.volume_gear_exp = m_t * v_exp, m_g * v_exp
            self.aspect_coef = (self.length_coef_mm / (2.0 * self.radius_coef_mm)
                                * m_c ** q_exp)
            self.aspect_tau_exp, self.aspect_gear_exp = m_t * q_exp, m_g * q_exp

        # What the catalogue's own slenderness does: the band the check reports.
        al = laws.get("aspect_trend") or {}
        self.aspect_band = (al.get("p10"), al.get("p90"))
        self.aspect_range = (al.get("min"), al.get("max"))

        # J_rotor = k · r⁴, with r⁴ required by rigid-body physics and k the one
        # thing the catalogue supplies: an areal density, the geometric mean of
        # J/r⁴ over the 88 parts whose vendor publishes a rotor inertia.
        #
        # k lumps the rotor's ρ and its stack length, and lumping them is the
        # point. This replaced J = φ·½ρπr⁴L, which is identically φ·½·m·r² —
        # half the whole MODULE swung at the package radius. That form charges
        # rotor inertia in proportion to package length, and package length is
        # mostly gearbox. A gearbox does not spin at rotor speed, so it
        # over-predicted exactly the high-reduction modules: its residual
        # correlates with log N at -0.67 against +0.16 here, it held out at
        # 1.66x against 1.44x, and freeing the length exponent put it at
        # 0.41 ± 0.15 rather than the 1.0 a solid cylinder requires.
        #
        # active_fraction_* stays in the trends file and is still measured, but
        # it is diagnostic now rather than the law.
        self.inertia_coef = il["k_areal_kg_m2"]
        self.active_fraction = il["active_fraction_mean"]

        # ω_NL = coef · N^exp — used to sanity-check a declared speed, not to set it
        self.speed_coef = raw["speed_vs_gear"]["coef"]
        self.speed_exp = raw["speed_vs_gear"]["exp"]

        env = laws["heuristic_envelope_mm"]
        self.r_lo_k, self.r_hi_k = env["r_lo_P_cbrt"], env["r_hi_P_cbrt"]
        self.frontier = laws["frontier"]

        self._catalog_path = Path(catalog_path)
        self._catalog: Optional[list[dict]] = None

    # ── catalogue ─────────────────────────────────────────────────────────────

    @property
    def catalog(self) -> list[dict]:
        if self._catalog is None:
            self._catalog = (_load(self._catalog_path)
                             if self._catalog_path.exists() else [])
        return self._catalog

    @staticmethod
    def _norm(name: str) -> str:
        return name.lower().replace(" ", "_").replace("-", "_")

    def find_part(self, name: str) -> Optional[dict]:
        """Catalogue entry by case/dash/space-insensitive name, or None."""
        want = self._norm(name)
        return next((e for e in self.catalog if self._norm(e["name"]) == want), None)

    def anchor(self, name: str) -> Optional[dict]:
        """Reference point for the relative law: a real part's measured envelope.

        Returns None when the part has no published dimensions — an anchor
        without geometry cannot seed r/L, so those classes use the absolute fit.
        """
        e = self.find_part(name)
        if e is None or not e.get("has_dims"):
            return None
        r = e["OD_mm"] / 2000.0
        L = e["L_mm"] / 1000.0
        gear = (e.get("gear")
                or parse_gear_ratio(e.get("notes", ""))
                or parse_gear_ratio(e["name"]))
        return {"name": e["name"], "category": e["category"], "tau": e["tau_peak_Nm"],
                "mass": e["mass_kg"], "r": r, "L": L, "gear": gear,
                "omega": e["omega_NL_rad_s"]}

    # ── sizing ────────────────────────────────────────────────────────────────

    def gear_from_speed(self, omega_rad_s: float) -> float:
        """Reduction implied by an output no-load speed, inverting the speed trend.

        ``ω = coef·N^exp`` fitted over the 102 geared actuators (R²=0.91). Used only
        when a class declares neither a reduction nor a catalogue part: a design
        that says "this joint tops out at 50 rad/s" has effectively told us its
        gearing, and inferring it is far better than assuming the dataset median,
        because mass and armature both depend on N.
        """
        return (omega_rad_s / self.speed_coef) ** (1.0 / self.speed_exp)

    def mass(self, tau_Nm: float, gear: float, anchor: Optional[dict] = None) -> float:
        """Actuator mass (kg) for a peak torque and reduction."""
        if anchor and anchor.get("gear"):
            return (anchor["mass"]
                    * (tau_Nm / anchor["tau"]) ** self.tau_exp
                    * (gear / anchor["gear"]) ** self.gear_exp)
        return self.mass_coef * tau_Nm ** self.tau_exp * gear ** self.gear_exp

    def shear_stress(self, tau_Nm: float, gear: float) -> Optional[float]:
        """Effective airgap shear stress (Pa) over the PACKAGE at this design point.

        ``sigma_eff = (tau/N) / (2*pi*r^2*L)``. It is an order of magnitude below a
        real airgap because most of the package is not airgap; divided by the
        independently measured active fraction it lands on the textbook figure.
        """
        if self.sigma0_Pa is None:
            return None
        return (self.sigma0_Pa * tau_Nm ** self.shear_tau_exp
                * gear ** -self.shear_gear_exp)

    def _law_ratio(self, coef: float, t_exp: float, g_exp: float,
                   tau_Nm: float, gear: float, anchor: Optional[dict]) -> float:
        """A (tau, N) power law, relative to an anchor part when there is one."""
        val = coef * tau_Nm ** t_exp * gear ** g_exp
        if anchor and anchor.get("gear"):
            ref = coef * anchor["tau"] ** t_exp * anchor["gear"] ** g_exp
            return val / ref
        return val

    def aspect_default(self, tau_Nm: float, gear: float,
                       anchor: Optional[dict] = None) -> float:
        """Slenderness ``q = L/D`` the catalogue expects at this (tau, N).

        The shape half of the geometry trend. The airgap argument fixes ``r^2*L``
        and says nothing about how that is divided between r and L; the catalogue
        does, at R^2 = 0.64 — the reduction sets it (a harmonic runs long, a QDD
        runs flat) and torque trims it, because torque is bought more cheaply in
        radius than in length.
        """
        rel = self._law_ratio(self.aspect_coef, self.aspect_tau_exp,
                              self.aspect_gear_exp, tau_Nm, gear, anchor)
        return rel * (anchor["L"] / (2.0 * anchor["r"])) if anchor else rel

    def volume(self, tau_Nm: float, gear: float,
               anchor: Optional[dict] = None) -> float:
        """Package volume (m^3), inverted from the airgap relation."""
        rel = self._law_ratio(self.volume_coef_m3, self.volume_tau_exp,
                              self.volume_gear_exp, tau_Nm, gear, anchor)
        return rel * (math.pi * anchor["r"] ** 2 * anchor["L"]) if anchor else rel

    def size(self, tau_Nm: float, gear: float,
             anchor: Optional[dict] = None,
             aspect: Optional[float] = None) -> dict:
        """Full envelope for one actuator class.

        Returns mass, volume, radius, length, slenderness, effective density,
        rotor inertia and the output-side reflected inertia (MuJoCo ``armature``),
        plus the no-load speed the gear law would predict for this reduction.

        Geometry comes from the airgap relation, ``tau/N = 2*pi*sigma*r^2*L``, driven
        by the same (tau, N) as mass rather than split off the mass trend's answer.
        Density is then ``m/V``, so the emitted cylinder still weighs exactly what
        the mass trend charged — but ``rho`` is now the RATIO of two independently
        fitted trends instead of a residual with no other job.

        ``aspect`` is ``L/D``, the one thing the airgap argument does not
        determine: it fixes ``r^2*L`` and is silent on how that splits between r
        and L. Leave it None for the catalogue's own slenderness at this (tau, N)
        — R^2 = 0.64, so it is a real expectation, not a shrug. Overriding it is
        not free of consequence: at fixed volume the rotor inertia goes as
        ``q^(-2/3)``, and the packing gate and the radius envelope both read r.
        """
        m = self.mass(tau_Nm, gear, anchor)
        V = self.volume(tau_Nm, gear, anchor)
        q_pop = self.aspect_default(tau_Nm, gear, anchor)
        q = float(aspect) if aspect else q_pop
        if q <= 0:
            raise ValueError(f"aspect ratio L/D must be positive, got {aspect!r}")
        # V = pi r^2 L with L = 2 q r  =>  V = 2 pi q r^3
        r = (V / (2.0 * math.pi * q)) ** (1.0 / 3.0)
        L = 2.0 * q * r
        # Density is not fitted: it is the exact complement of the volume trend, and
        # solving it here is what makes the emitted cylinder weigh exactly what the
        # mass trend charged. Shape cannot change it — rho = m/V either way.
        rho = m / (math.pi * r * r * L)
        j_rotor = self.inertia_coef * r ** 4
        j_source = "areal(k*r^4)"
        return {
            "mass": m, "r": r, "L": L, "rho": rho,
            "volume": V,
            "shear_Pa": self.shear_stress(tau_Nm, gear),
            "aspect": q,
            "aspect_population": q_pop,
            "aspect_source": "declared" if aspect else "population_fit",
            "J_rotor": j_rotor,
            "J_rotor_source": j_source,
            "armature": gear ** 2 * j_rotor,   # reflected to the output
            "omega_law": self.speed_coef * gear ** self.speed_exp,
            "anchor": anchor["name"] if anchor else None,
            "category": (anchor or {}).get("category"),
        }

    # ── validation ────────────────────────────────────────────────────────────

    def check(self, label: str, tau_Nm: float, omega_rad_s: float,
              gear: float, sized: dict) -> tuple[list[str], list[str]]:
        """Return (errors, warnings) for a sized class.

        Errors mean "no catalogued actuator of this category comes close, in a
        dataset that already includes the best parts on the market". Warnings
        mean "you are claiming a best-in-class unit" or "this is off the fitted
        trend" — unusual, but a real design could be there.
        """
        errors: list[str] = []
        warns: list[str] = []
        cat = sized.get("category") or "ALL"
        front = self.frontier.get(cat, self.frontier["ALL"])
        mass = sized["mass"]

        td = tau_Nm / mass
        td_max = front["torque_density_Nm_per_kg"]["max"]
        td_p90 = front["torque_density_Nm_per_kg"]["p90"]
        if td > td_max:
            errors.append(
                f"{label}: torque density {td:.0f} Nm/kg beats the best catalogued "
                f"{cat} actuator ({td_max:.0f} Nm/kg, "
                f"{front['torque_density_Nm_per_kg']['argmax']}). "
                f"τ={tau_Nm:.0f} Nm at N={gear:g} implies {mass*1e3:.0f} g.")
        elif td > td_p90:
            warns.append(
                f"{label}: torque density {td:.0f} Nm/kg is above the {cat} p90 "
                f"({td_p90:.0f} Nm/kg) — best-in-class territory.")

        p_peak = tau_Nm * omega_rad_s / 4.0     # the catalogue's envelope convention
        pd = p_peak / mass
        pd_max = front["power_density_W_per_kg"]["max"]
        pd_p90 = front["power_density_W_per_kg"]["p90"]
        if pd > pd_max:
            errors.append(
                f"{label}: power density {pd:.0f} W/kg beats the best catalogued "
                f"{cat} actuator ({pd_max:.0f} W/kg, "
                f"{front['power_density_W_per_kg']['argmax']}). "
                f"P_peak={p_peak:.0f} W in {mass*1e3:.0f} g.")
        elif pd > pd_p90:
            warns.append(
                f"{label}: power density {pd:.0f} W/kg is above the {cat} p90 "
                f"({pd_p90:.0f} W/kg) — best-in-class territory.")

        # Declared speed vs the gear-ratio speed trend. Wide gate (2.5x): the fit is
        # a population trend (R²=0.79), so only gross mismatches are meaningful.
        ratio = omega_rad_s / sized["omega_law"]
        if ratio > 2.5 or ratio < 1 / 2.5:
            warns.append(
                f"{label}: no-load speed {omega_rad_s:.1f} rad/s is {ratio:.1f}x the "
                f"speed trend's {sized['omega_law']:.1f} rad/s for N={gear:g} "
                f"(ω = {self.speed_coef:.0f}·N^{self.speed_exp:.2f}).")

        # Slenderness. A DECLARED aspect ratio is a design choice, not a fit, so
        # the only thing to say about it is whether any catalogued actuator is
        # shaped like that. Warn past the observed extremes, not past the p10-p90
        # band: the band is where the market clusters, the extremes are what has
        # actually been built.
        lo, hi = self.aspect_range
        q = sized.get("aspect")
        if q and lo and hi and (q < lo or q > hi):
            p10, p90 = self.aspect_band
            warns.append(
                f"{label}: aspect ratio L/D = {q:.2f} is outside every catalogued "
                f"actuator in this population ({lo:.2f}-{hi:.2f}, p10-p90 "
                f"{p10:.2f}-{p90:.2f}). Volume is still the trend's, so mass is "
                f"unchanged; what moves is r, and armature goes as (L/D)^(-2/3).")

        # Radius envelope. Only meaningful for the direct/mid-geared families;
        # harmonic units run long and narrow for their power.
        if cat != "Harmonic" and p_peak > 0:
            r_mm = sized["r"] * 1000.0
            lo, hi = self.r_lo_k * p_peak ** (1 / 3), self.r_hi_k * p_peak ** (1 / 3)
            if r_mm < lo * 0.5 or r_mm > hi * 2.0:
                warns.append(
                    f"{label}: radius {r_mm:.0f} mm is outside the empirical envelope "
                    f"{lo:.0f}-{hi:.0f} mm for P_peak={p_peak:.0f} W.")
        return errors, warns


def rotor_inertia(r_m: float) -> float:
    """Motor-side rotor inertia (kg·m²) from the package radius alone.

    ``k·r⁴``, which is what ``MotorTrends.size`` emits. Prefer
    ``motor_fits().size(tau, N)['J_rotor']``; this is kept for callers that have
    a radius and nothing else. Neither length nor density is read — see the note
    in ``MotorTrends.__init__`` for why package length was dropped. Still the
    loosest number the generator emits, good to about 1.44x held out.
    """
    return motor_fits().inertia_coef * r_m ** 4


def armature_for(r_m: float, gear_ratio: float) -> float:
    """MuJoCo ``armature`` (output-side reflected inertia) = N²·J_rotor."""
    return gear_ratio ** 2 * rotor_inertia(r_m)


# ── Battery / torso law ───────────────────────────────────────────────────────

class BatteryTrend:
    """Torso mass from the battery pack the design's installed power implies.

    Sizing a pack is a TWO-constraint problem and the old rule solved only one of
    them (``m = duty·P/η / 600 W/kg``, a specific power that is not a point on
    the measured frontier). Here::

        P_peak_elec = coincidence · P_installed / η_drive
        E_required  = duty · P_installed / η_drive · runtime
        m ≥ E/SE  and  m ≥ P_peak/SP,  with SP = A·SE^-k on the fitted frontier
        ⇒ SE* = (A·E/P_peak)^(1/(k+1)),  m = max(E/SE*, P_peak/SP(SE*))

    ``duty`` is calibrated against fielded humanoids (Unitree G1/H1, Optimus Gen 2
    imply a median 6.2 W/kg average electrical draw), not asserted.

    The trunk is pack + electronics + shell. The SHELL is not a flat constant:
    it is the trunk's own volume at the measured structural density of a real
    robot trunk segment (datasets/robot_descriptions pelvis ρ_eff, actuators removed). A flat
    constant would make trunk mass depend only on installed power, which would
    erase the whole point of the body-type variants — a wider torso has to weigh
    more than a narrow one carrying the same battery.

    Electronics mass remains an asserted constant, flagged as such in the report
    so nobody mistakes it for a measurement.
    """

    LEGACY_SP_BATT_W_PER_KG = 600.0
    LEGACY_DUTY = 0.40

    DRIVE_EFF = 0.85           # motor + driver electrical→mechanical
    M_ELECTRONICS_KG = 2.5     # asserted: compute + drivers + power distribution
    M_STRUCTURE_KG = 3.0       # asserted: fallback shell mass when no volume is given

    def __init__(self, laws_path: Path = BATTERY_TRENDS_JSON, legacy: bool = False,
                 runtime_h: float | None = None, duty: float | None = None,
                 coincidence: float | None = None):
        self.legacy = legacy
        laws = _load(laws_path)
        pack = laws["pack"]
        self.A_pack = pack["coef"]
        self.k = pack["k"]
        self.se_lo, self.se_hi = pack["SE_window_Wh_per_kg"]
        self.duty = duty if duty is not None else laws["duty_calibration"]["duty_calibrated"]
        self.runtime_h = runtime_h if runtime_h is not None else laws["load_case"]["runtime_h"]
        self.coincidence = (coincidence if coincidence is not None
                            else laws["load_case"]["coincidence"])
        if legacy:
            self.duty = self.LEGACY_DUTY

    def size_pack(self, p_installed_W: float) -> dict:
        """Lightest pack meeting BOTH the peak transient and the energy need."""
        p_peak = self.coincidence * p_installed_W / self.DRIVE_EFF
        energy = self.duty * p_installed_W / self.DRIVE_EFF * self.runtime_h
        if self.legacy:
            m = (self.duty * p_installed_W / self.DRIVE_EFF) / self.LEGACY_SP_BATT_W_PER_KG
            return {"mass_kg": m, "SE_pack_Wh_per_kg": float("nan"),
                    "SP_pack_W_per_kg": self.LEGACY_SP_BATT_W_PER_KG,
                    "energy_Wh": energy, "P_peak_elec_W": p_peak, "binding": "legacy"}
        se_star = (self.A_pack * energy / p_peak) ** (1.0 / (self.k + 1.0))
        se = min(max(se_star, self.se_lo), self.se_hi)
        sp = self.A_pack * se ** (-self.k)
        m_e, m_p = energy / se, p_peak / sp
        m = max(m_e, m_p)
        binding = ("both" if abs(m_e - m_p) / m < 1e-3
                   else ("energy" if m_e > m_p else "power"))
        return {"mass_kg": m, "SE_pack_Wh_per_kg": se, "SP_pack_W_per_kg": sp,
                "energy_Wh": energy, "P_peak_elec_W": p_peak, "binding": binding}

    def shell_mass(self, torso_volume_m3: float | None,
                   shell_rho: float | None = None) -> float:
        """Structural mass of the trunk enclosure itself."""
        if not torso_volume_m3:
            return self.M_STRUCTURE_KG
        if shell_rho is None:
            shell_rho = link_fits().trunk_shell_density()
        return shell_rho * torso_volume_m3

    def torso_mass(self, p_installed_W: float, torso_volume_m3: float | None = None,
                   shell_rho: float | None = None) -> float:
        return (self.size_pack(p_installed_W)["mass_kg"]
                + self.M_ELECTRONICS_KG
                + self.shell_mass(torso_volume_m3, shell_rho))

    def torso_density(self, p_installed_W: float, torso_volume_m3: float,
                      shell_rho: float | None = None) -> float:
        return (self.torso_mass(p_installed_W, torso_volume_m3, shell_rho)
                / torso_volume_m3)


# ── Link / whole-robot trends ───────────────────────────────────────────────────

class LinkTrends:
    """Structural-density band and whole-robot mass-composition audit.

    Link geometry is a design variable, so these are checks on the OUTCOME rather
    than a sizing rule: the measured robots say what fraction of a machine is
    actuator, what fraction is trunk, and what effective density a structural
    limb member has once its actuators are separated out. A generated robot that
    lands outside those bands is not necessarily wrong, but it is not a robot of
    the kind the dataset describes.

    ONE INSTANCE PER POPULATION. Every quantity here — actuator fraction, trunk
    fraction, the allometry, the limb-density band, the trunk-density ceiling —
    is fitted separately for humanoids and for quadrupeds, because they are not
    one population. Measured on the same links: the humanoid λ trend overpredicts a
    quadruped thigh by 2.1x and a quadruped shank by 1.9x (datasets/robot_descriptions stage 6,
    `cross_population`), and the humanoid mass-vs-height trend predicts 1.4 kg for
    a quadruped's 0.22 m "standing height". Applying the humanoid bands to a
    quadruped is not a conservative approximation; it is checking nothing.

    ``population`` selects the block. ``humanoid`` is the top level of
    link_trends.json (21 robots); ``quadruped`` is ``laws["quadruped"]``, the same
    four law families fit over 11 decomposed quadrupeds (16 for the allometry).
    """

    #: Populations datasets/robot_descriptions fits, i.e. legal `mass_composition_reference`s.
    POPULATIONS = ("humanoid", "quadruped")

    def __init__(self, laws_path: Path = LINK_TRENDS_JSON,
                 population: str = "humanoid"):
        if population not in self.POPULATIONS:
            raise ValueError(
                f"unknown reference population {population!r}; datasets/robot_descriptions fits "
                f"{', '.join(self.POPULATIONS)}. A robot with no comparable "
                f"measured population (a hand, a payload) should omit "
                f"`mass_composition_reference` rather than borrow another's.")
        all_laws = _load(laws_path)
        self.population = population
        self._all = all_laws
        self._laws = all_laws if population == "humanoid" else all_laws[population]

        wr = self._laws["whole_robot"]
        self.actuator_fraction = wr["actuator_mass_fraction"]
        self.trunk_fraction = self._laws["segment_mass_fraction"]["trunk_pelvis_torso_head"]
        # mass = coef · S^exp, with S the population's own size metric: a
        # humanoid's standing height, a quadruped's leg (thigh + shank). A
        # quadruped's z-span is the crouch depth of whatever neutral pose its
        # description ships — R²=0.07 against mass, versus 0.88 for the leg.
        self.mass_vs_size = wr["mass_vs_height"]
        self.size_metric = wr.get("adopted_size_metric", "z_span_m")
        self.size_range = tuple(wr.get("size_range_m") or (0.0, float("inf")))
        # Backwards-compatible alias: this used to be humanoid-only.
        self.mass_vs_height = self.mass_vs_size
        # Structural effective density of the limb segments the generator emits
        # as cylinders. hand/foot are excluded: the generator models those as a
        # sphere and a box with their own geometry, and the measured hands are
        # near-empty shells (p10 = 33 kg/m³) that would make the band meaningless.
        eff = self._laws["effective_density"]
        self._limb_rho = {k: eff[k]["rho_eff_kg_m3"]
                          for k in ("thigh", "shank", "forearm") if k in eff}

    def distal_taper(self, chain: str = "leg") -> dict | None:
        """How much lighter per metre each step out along a limb chain is.

        datasets/robot_descriptions's fifth law family, and the only one fit WITHIN robots: every
        machine is demeaned in log space before the regression, so this is limb
        shape and says nothing about the level. That is what makes it usable
        where the per-class absolute densities are not — the absolute density of
        an unseen robot's thigh is a ~2.3x guess whatever model you use, but the
        ratio between its thigh and its shank is pinned to ±15%.

        Structural λ, because a generated link geom IS m_struct by construction:
        the actuators bolted to it are priced separately by ``MotorTrends``. The
        adopted span is the proximal pair (thigh→shank), since the falloff
        decelerates at the terminal segment.
        """
        blk = (self._laws.get("distal_taper") or {}).get("chains", {}).get(chain)
        if not blk:
            return None
        adopted = (self._laws.get("distal_taper") or {}).get("adopted") or {}
        span = adopted.get("span", "proximal_pair")
        fit = (blk.get(span) or {}).get("lambda_struct")
        if not fit or not fit.get("per_step"):
            return None
        return {**fit, "chain": chain, "span": span,
                "classes": blk["classes"][:2] if span == "proximal_pair"
                           else blk["classes"],
                "population": self.population,
                # WHICH KNOB the population uses to shed that mass. A humanoid
                # thins AND hollows its distal links; a quadruped only thins
                # (its ρ taper is not significant), so imposing a density
                # gradient on a quadruped would be inventing an effect the data
                # says is not there. See `taper_mode` in parameters.yaml.
                "rho_per_step": ((blk.get(span) or {}).get("rho_struct") or {})
                                .get("per_step")}

    def check_distal_taper(self, achieved: float, chain: str = "leg") -> list[str]:
        """Is the emitted limb's own λ gradient one a real limb of this kind has?

        A warning, never a violation: the taper is a population trend and a
        design is allowed to be an outlier on it deliberately. What it catches is
        the case nothing else does — a limb carrying the right total mass spread
        the wrong way along itself, which every mass check passes and every
        swing-inertia number fails.
        """
        law = self.distal_taper(chain)
        if not law or not achieved or achieved <= 0:
            return []
        lo, hi = law["per_step_ci95"]
        if lo <= achieved <= hi:
            return []
        which = "flatter" if achieved > hi else "steeper"
        return [f"{chain} distal taper {achieved:.2f}x per chain step is {which} "
                f"than the measured {self.population} band "
                f"{lo:.2f}-{hi:.2f} (median {law['per_step']:.2f}, n={law['n']} "
                f"segments over {law['n_robots']} robots): the limb carries its "
                f"mass spread differently along itself than the population does, "
                f"which mass checks cannot see."]

    def trunk_shell_density(self) -> float:
        """Measured structural density of a trunk-class segment, actuators removed.

        The datasets/robot_descriptions pelvis median. Used to give the trunk enclosure a mass that
        follows its own geometry instead of a flat asserted constant.
        """
        return self._laws["effective_density"]["pelvis"]["rho_eff_kg_m3"]["median"]

    #: Segment classes whose density is NOT theirs to give. Only the two trunk
    #: classes, which ``trunk_density`` owns rather than this route (a humanoid's
    #: `torso_rho` and a quadruped's body are the same parameter, so they cannot
    #: be matched by name like every other class).
    #:
    #: The four limb members used to be here too, sharing the single `link_rho`.
    #: They now take their own class median like everything else the population
    #: has measured, because there was no principle behind the split — a thigh's
    #: mass is measured the same way a foot's is, and the classes ARE separable
    #: (thigh 803 vs shank 524 kg/m³, Mann-Whitney p<0.001 on log ρ). Measured on
    #: the four twins the change is worth 0.001 in total-mass GMFE, so it buys
    #: consistency rather than accuracy: structural links are 9-13% of a machine
    #: and the actuators are half of it. Housings have no `<seg>_rho` parameter
    #: to match, so this route never reaches them; a generated housing MEMBER
    #: takes its class median through ``member_density`` instead (there is no
    #: stated `link_rho` left). A housing keeps under 10% of its own mass once
    #: its actuator is attributed away, so its ρ_eff is the loosest of these
    #: measurements, and an earlier trial found it worth 0.004 in twin GMFE.
    _DENSITY_LAW_EXCLUDES = ("torso", "pelvis")

    #: Which measured class IS the trunk, per population. A humanoid's root body
    #: is the segment the waist joints drive; a quadruped has no torso/pelvis
    #: split at all — it is one body, and datasets/robot_descriptions files it under `pelvis`.
    TRUNK_CLASS = {"humanoid": "torso", "quadruped": "pelvis"}

    def trunk_density(self) -> Optional[dict]:
        """Measured structural density of the trunk, for ``torso_rho``.

        This replaces sizing the trunk from the battery pack the installed power
        implies. That route asserted a flat 2.5 kg of electronics regardless of
        machine size — 15% of a 16 kg quadruped — and sized the pack for every
        actuator at peak simultaneously, a coincidence no robot pays. A measured
        trunk density asserts nothing: whatever a real trunk holds, battery and
        compute included, is already in the number.

        Read the quadruped figure with more caution than the humanoid one. Some
        of that population carries a full sensor suite in the body and some does
        not, and the body is where it goes, so the class is genuinely wider than
        the humanoid trunk rather than merely more thinly sampled.
        """
        cls = self.TRUNK_CLASS.get(self.population)
        if cls is None:
            return None
        stats = (self._laws["effective_density"].get(cls) or {}).get("rho_eff_kg_m3")
        if not stats or stats.get("median") is None:
            return None
        return {"segment": cls, "rho": float(stats["median"]),
                "p10": stats["p10"], "p90": stats["p90"], "n": stats["n"],
                "population": self.population}

    def segment_density(self, segment: str) -> Optional[dict]:
        """Measured structural density of one segment class, or None.

        A head is a shell around empty volume, a hand is a shell around a
        mechanism, a foot is a plate — each has its own measured effective
        density (actuators separated out), and each is emitted by the generator
        as its own primitive with its own geometry. So there is nothing to solve:
        the density IS the measurement, and a parameter file restating it is a
        copy that can go stale. This returns the number to derive it from.

        Excludes the classes another law already owns; see
        ``_DENSITY_LAW_EXCLUDES``.
        """
        if segment in self._DENSITY_LAW_EXCLUDES:
            return None
        entry = self._laws["effective_density"].get(segment)
        stats = (entry or {}).get("rho_eff_kg_m3")
        if not stats or stats.get("median") is None:
            return None
        return {"segment": segment, "rho": float(stats["median"]),
                "p10": stats["p10"], "p90": stats["p90"], "n": stats["n"],
                "population": self.population}

    def member_density(self, segment: str) -> Optional[dict]:
        """Structural effective density of one class, for a generated MEMBER.

        Like ``segment_density`` but without its trunk exclusion: a member the
        tree files under `torso` (the humanoid's pelvis link, below the waist) is
        a structural member of that class, whereas `torso_rho` is the trunk MESH
        and is owned by ``trunk_density``. Housings are included — every member
        a population has measured is priced at its own class median.
        """
        entry = self._laws["effective_density"].get(segment)
        stats = (entry or {}).get("rho_eff_kg_m3")
        if not stats or stats.get("median") is None:
            return None
        return {"segment": segment, "rho": float(stats["median"]),
                "p10": stats["p10"], "p90": stats["p90"], "n": stats["n"],
                "population": self.population}

    def structural_mass(self, segment: str, length_m: float) -> Optional[dict]:
        """Structural mass a member of this class and joint-to-joint length carries.

        m = c L^e, the class's power fit of structural mass against length
        (`structural_linear_density[cls].m_struct_vs_L`), inside the length range
        the fit has support over. Outside it the mass per metre is HELD at its
        value at the nearest edge of that range, c L_edge^(e-1), and the member
        weighs that times L: the exponent is not extrapolated where no robot sits,
        and the trend stays continuous. Dropping to the class median instead made
        it jump (a quadruped thigh went from 4.8 kg/m at 0.35 m to 1.9 just past
        it), so the longer-legged designs got LIGHTER legs per metre than the
        cheetah and the giraffe's foot outweighed its whole shank budget. The
        mass per metre is clamped to the class p10-p90 either way. Keyed
        to the LINK'S length and not to the robot's total mass, because half of a
        robot is actuator chosen for a task, and a mass-keyed target would size
        structure from the actuator choice. Returns None for a class this
        population has not fitted.
        """
        block = (self._laws.get("structural_linear_density") or {}).get(segment)
        if not block or length_m <= 0:
            return None
        lam = block.get("lambda_kg_per_m") or {}
        if lam.get("median") is None:
            return None
        fit = block.get("m_struct_vs_L")
        lo, hi = block.get("length_range_m") or (0.0, float("inf"))
        L = float(length_m)
        if fit:
            edge = min(max(L, lo), hi)
            per_m = fit["coef"] * edge ** (fit["exp"] - 1.0)
            basis = f"m = {fit['coef']:.4g} L^{fit['exp']:.3g} (n={fit['n']})"
            if edge != L:
                basis += (f", mass per metre held at its {edge:.3f} m value: "
                          f"L={L:.3f} m is outside the fitted {lo}-{hi} m")
        else:
            per_m = float(lam["median"])
            basis = f"median {per_m:.3g} kg/m x L (no power fit)"
        clamped = min(max(per_m, lam["p10"]), lam["p90"])
        if clamped != per_m:
            basis += f", clamped to the class p10-p90 ({clamped:.3g} kg/m)"
        return {"segment": segment, "population": self.population,
                "length_m": L, "lambda_kg_per_m": clamped,
                "mass_kg": clamped * L, "basis": basis}

    def segment_density_params(self, params: dict) -> dict[str, dict]:
        """``<seg>_rho`` parameters this population can derive, keyed by parameter.

        Matched by NAME against the measured classes, so a robot that grows a new
        primitive body picks the trend up by declaring ``<seg>_rho`` — nothing here
        enumerates the humanoid's head, hand and foot one by one.
        """
        out = {}
        for key in params:
            k = str(key)
            if not k.endswith("_rho"):
                continue
            # `torso_rho` is the trunk, and which measured class that IS depends
            # on the population — see ``TRUNK_CLASS``. Every other key matches a
            # class by its own name.
            law = self.trunk_density() if k == "torso_rho" else self.segment_density(k[:-4])
            if law is not None:
                out[k] = law
        return out

    def check_trunk_density(self, rho: float) -> tuple[list[str], list[str]]:
        """Does the battery-sized trunk mass actually fit in the trunk volume?

        The battery trend returns a MASS; turning it into a density can quietly
        demand a torso denser than anything buildable. The bound comes from the
        measured pelvis segments (the densest trunk-class segment in datasets/robot_descriptions,
        actuators included) rather than an asserted packing limit: real robot
        trunks reach ~3400 kg/m³, so beyond that the design is asking for a pack
        that does not fit the body it declared.
        """
        stats = self._laws["effective_density"]["pelvis"]["rho_total_kg_m3"]
        if rho > stats["max"]:
            return ([f"trunk density {rho:.0f} kg/m³ exceeds the densest measured "
                     f"robot trunk segment ({stats['max']:.0f} kg/m³): the battery "
                     f"pack this design's installed power requires does not fit in "
                     f"the torso volume it declares."], [])
        if rho > stats["p90"]:
            return ([], [f"trunk density {rho:.0f} kg/m³ is above the p90 of measured "
                         f"trunk segments ({stats['p90']:.0f} kg/m³) — the pack only "
                         f"just fits the declared torso volume."])
        return ([], [])

    def link_density_band(self) -> tuple[float, float]:
        """(p10, p90) of structural effective density across the limb segments.

        Deliberately wide — it pools the population's limb classes across robots
        whose construction ranges from a 3 kg toy to Valkyrie (humanoid) or a
        2.5 kg Solo to a 75 kg B2 (quadruped). It is a sanity gate for "this
        density is not a robot limb", not a tight design constraint.
        """
        return (min(v["p10"] for v in self._limb_rho.values()),
                max(v["p90"] for v in self._limb_rho.values()))

    def check_link_density(self, rho: float) -> list[str]:
        lo, hi = self.link_density_band()
        if lo <= rho <= hi:
            return []
        meds = ", ".join(f"{k} {v['median']:.0f}" for k, v in self._limb_rho.items())
        return [f"link_rho {rho:.0f} kg/m³ is outside the measured structural band "
                f"{lo:.0f}-{hi:.0f} kg/m³ (datasets/robot_descriptions effective density, actuator "
                f"mass separated out; segment medians: {meds})."]

    # Bodies that make up the trunk. The reference band is
    # ``trunk_pelvis_torso_head``, which in the source URDFs is one segment per
    # robot INCLUDING whatever actuators are bolted to it — so comparing it to
    # the root mesh alone would flatter the design. The generator spreads the
    # same anatomy over a chain of bodies, so the trunk is matched by name.
    TRUNK_BODY_PATTERNS = ("torso", "core", "pelvis", "head", "waist", "trunk")

    @classmethod
    def trunk_mass(cls, mass_by_body: dict, patterns=None) -> float:
        pats = tuple(patterns or cls.TRUNK_BODY_PATTERNS)
        return sum(m for b, m in mass_by_body.items()
                   if any(p in b for p in pats))

    def audit(self, mass_by_role: dict, size_m: float | None = None,
              mass_by_body: dict | None = None, trunk_patterns=None) -> dict:
        """Compare a generated robot's mass composition to the measured bands.

        Every band comes from this instance's population — see the class
        docstring for why that is not a detail. ``size_m`` is the length the
        allometry is fit against, named by ``self.size_metric``: a joint z-span
        for a humanoid, thigh + shank for a quadruped.

        Robots with no comparable measured population (the hands) do not
        call this at all; the generator skips the audit when a design declares no
        ``mass_composition_reference``.
        """
        total = sum(mass_by_role.values())
        out: dict = {"reference_population": self.population,
                     "size_metric": self.size_metric,
                     "total_mass_kg": total, "by_role_kg": dict(mass_by_role),
                     "checks": []}
        if total <= 0:
            return out

        def band(name, value, stats, unit=""):
            if not stats:            # law family missing this class entirely
                out["checks"].append({"quantity": name, "value": round(value, 4),
                                      "status": "no_reference_data"})
                return "no_reference_data"
            status = ("ok" if stats["p10"] <= value <= stats["p90"]
                      else ("outside_p10_p90" if stats["min"] <= value <= stats["max"]
                            else "outside_measured_range"))
            out["checks"].append({
                "quantity": name, "value": round(value, 4), "status": status,
                "median": stats["median"], "p10": stats["p10"], "p90": stats["p90"],
                "min": stats["min"], "max": stats["max"], "n": stats["n"],
                "unit": unit})
            return status

        band("actuator_mass_fraction",
             mass_by_role.get("motor", 0.0) / total, self.actuator_fraction)

        if mass_by_body:
            trunk = self.trunk_mass(mass_by_body, trunk_patterns) / total
            out["trunk_bodies"] = sorted(
                b for b in mass_by_body
                if any(p in b for p in (trunk_patterns or self.TRUNK_BODY_PATTERNS)))
            band("trunk_mass_fraction", trunk, self.trunk_fraction)

        if size_m:
            law = self.mass_vs_size
            lo_fit, hi_fit = self.size_range
            inside = lo_fit <= size_m <= hi_fit
            pred = law["coef"] * size_m ** law["exp"]
            lo = pred * math.exp(-2 * law["sigma_log"])
            hi = pred * math.exp(+2 * law["sigma_log"])
            # Extrapolate and flag it rather than decline. This used to return
            # early without a number, on the argument that a power law past its
            # data is not evidence — true, but refusing removes the check
            # exactly where a design study is most likely to be pointed. A robot
            # the surveyed population does not contain is often the question
            # being asked, and a band marked as extrapolated is more use to a
            # reader than no band at all. The status still says the size is
            # outside the fit, so nothing here can be read as measured.
            check = {
                "quantity": "total_mass_vs_size_kg", "value": round(total, 3),
                "status": ("ok" if lo <= total <= hi else "outside_2sigma")
                          if inside else "size_outside_fit_range",
                "predicted": round(pred, 3), "lo_2sigma": round(lo, 3),
                "hi_2sigma": round(hi, 3), "size_m": round(size_m, 4),
                "size_metric": self.size_metric, "extrapolated": not inside}
            if not inside:
                check["fit_range_m"] = [lo_fit, hi_fit]
                # How far past, and what the exponent does with it: the reader
                # needs the leverage, not just the fact.
                reach = size_m / hi_fit if size_m > hi_fit else lo_fit / size_m
                check["reach_past_fit"] = round(reach, 3)
                check["mass_leverage"] = round(reach ** law["exp"], 2)
            out["checks"].append(check)
        return out

    def warnings(self, audit: dict) -> list[str]:
        pop = {"humanoid": "humanoids", "quadruped": "quadrupeds"}.get(
            audit.get("reference_population"), "robots")
        msgs = []
        for c in audit.get("checks", []):
            if c["status"] in ("ok", "no_reference_data"):
                continue
            if "median" in c:
                msgs.append(
                    f"{c['quantity']} = {c['value']:.3f} is {c['status'].replace('_', ' ')} "
                    f"(measured median {c['median']:.3f}, p10-p90 "
                    f"{c['p10']:.3f}-{c['p90']:.3f}, n={c['n']} {pop}).")
            elif c["quantity"].endswith("_distal_taper"):
                msgs.extend(self.check_distal_taper(
                    c["value"], c["quantity"][:-len("_distal_taper")]))
            elif c["status"] == "size_outside_fit_range":
                lo, hi = c["fit_range_m"]
                inband = c["lo_2sigma"] <= c["value"] <= c["hi_2sigma"]
                msgs.append(
                    f"{c['size_metric']} = {c['size_m']:.2f} m is outside the "
                    f"{lo:.2f}-{hi:.2f} m range of the measured {pop}, so "
                    f"mass-vs-size is EXTRAPOLATED: the law predicts "
                    f"{c['predicted']:.1f} kg and the design is "
                    f"{c['value']:.1f} kg, "
                    f"{'inside' if inband else 'outside'} 2σ. At "
                    f"{c['reach_past_fit']:.2f}x past the fitted range a "
                    f"^{self.mass_vs_size['exp']:.2f} law carries "
                    f"{c['mass_leverage']:.1f}x of leverage on mass, so treat "
                    f"this as a sanity check and not as evidence.")
            else:
                msgs.append(
                    f"{c['quantity']} = {c['value']:.1f} kg is outside 2σ of the "
                    f"{pop[:-1]} mass-vs-size law (predicts {c['predicted']:.1f} kg "
                    f"for {c['size_metric']} = {c['size_m']:.2f} m).")
        return msgs


# ── Convenience: shared singletons ────────────────────────────────────────────

_MOTOR_FITS: list[MotorTrends] = []
_LINK_FITS: dict[str, LinkTrends] = {}


def motor_fits() -> MotorTrends:
    """The fitted actuator trends, built once and shared.

    One population: datasets/actuators's integrated QDD / MidGear / High-GR catalogue,
    2.5-1180 N·m. Every generated robot is priced against it.
    """
    if not _MOTOR_FITS:
        _MOTOR_FITS.append(MotorTrends())
    return _MOTOR_FITS[0]


def link_fits(population: str = "humanoid") -> LinkTrends:
    """Link/whole-robot trends for one measured population, cached per population.

    Defaults to ``humanoid`` so a robot that declares no reference still gets a
    structural-density sanity gate; anything that AUDITS a design must pass the
    design's own ``mass_composition_reference``.
    """
    if population not in _LINK_FITS:
        _LINK_FITS[population] = LinkTrends(population=population)
    return _LINK_FITS[population]
