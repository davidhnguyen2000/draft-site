"""The fitted trends, and the feasibility checks they imply (paper §IV).

`feasibility.py` owns the regressions — `MotorTrends`, `LinkTrends`,
`BatteryTrend` — and the gate that decides whether an assembled design could be
built. `motor_solve.py` turns the two numbers a design states about an actuator
class into the eight the generator needs. `motor_catalog.py` resolves a class
anchored on a named catalogue part.

The fitted coefficients live in `data/` **inside this package**, not beside the
datasets that produced them. That is deliberate: the generator and the numbers
reported in the paper are then the same file, so an installed copy cannot drift
from the fits it was validated with. `datasets/` holds the raw rows and the
stages that write these four files; nothing else writes them.
"""

from .feasibility import (  # noqa: F401
    ACTUATOR_TRENDS_JSON, BATTERY_TRENDS_JSON, CATALOG_JSON, LINK_TRENDS_JSON,
    BatteryTrend, FeasibilityViolation, LinkTrends, MotorTrends,
    link_fits, motor_fits,
)
