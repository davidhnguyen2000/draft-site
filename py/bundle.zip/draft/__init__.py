"""Draft — a parametric design tool for robot exploration.

A robot is two files: a flat table of numeric parameters and a kinematic tree
whose numeric fields are arithmetic expressions over that table. The engine
compiles the pair into a simulation-ready MJCF. Whatever the design does not
state is filled in from trends fitted to 114 catalogued actuators and 49
published robot descriptions, and the assembled machine is then checked against
what that hardware can actually do.

    draft.generation   the compiler: table + tree -> MJCF
    draft.trends       the fitted trends, and the feasibility checks they imply
    draft.robots       the shipped specifications (humanoid, quadruped)
    draft.twins        rebuilding four off-the-shelf platforms, end to end
    draft.tasks        the locomotion environments a generated design trains in
    draft.editor       the browser editor -- the normal way to build a design
    draft.viz          shared viser/MuJoCo visualisation

draft.retargeting supports motion work that is not part of the Draft paper;
see its own README.
"""

__version__ = "0.1.0"
