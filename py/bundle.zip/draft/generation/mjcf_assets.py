"""Load an MJCF that may have changed on disk since the last load.

MuJoCo caches mesh assets by resolved path for the life of the process and does
not re-read a file that changed underneath it. That is the right default for a
simulator loading fixed content and the wrong one for everything in this repo
that REGENERATES into a fixed directory and reloads:

  the editors                 rebuild into the selected folder on every build
  `twins/synthesize.build`    rewrites `torso_mesh.stl` on every pass of its
                              fixed point

In both the ROOT MESH is the asset, and it is the one part of the robot the
stale cache freezes: every actuator and every link is a primitive written into
the XML and so is always current, while the trunk stays whatever it was on the
first load. A trunk from one parameter set drawn among actuators from another
looks exactly like a design that intersects itself, and no offline measurement
can reproduce it, because a fresh process reads the file.

Handing the bytes over explicitly bypasses the cache. Verified by swapping one
twin's STL for another's between two loads in one process: with `from_file` the
first mesh stays, with these the model follows the file.
"""
from __future__ import annotations

import os
from pathlib import Path

#: What MuJoCo may reference out of a model's own directory.
ASSET_SUFFIXES = {".stl", ".obj", ".msh", ".png", ".skn"}

#: What makes a directory another model's own, rather than this one's assets.
MODEL_SUFFIXES = {".xml", ".urdf", ".mjcf"}


def read_assets(path: Path) -> dict:
    """Every asset beside a model, as `{name: bytes}`, read right now.

    A DIRECTORY THAT HOLDS ITS OWN MODEL IS NOT WALKED. The recursion is needed
    — an adapted URDF keeps its converted meshes in `meshes/` — but a
    subdirectory carrying an XML or a URDF of its own is a DIFFERENT robot's
    folder, and its meshes are that robot's. MuJoCo matches an asset by
    basename, so anything picked up there answers to a name the model being
    loaded may already use, and the deeper copy wins.

    That is not a hypothetical. A twin directory holds the vendor's adapted
    copies as well as the twin — `shipped_mjcf/meshes/` from the URDF
    conversion, `shipped_rl/assets/` from the cluster upload — under the
    vendor's own basenames. `render.PairRenderer` attaches the twin's spec to
    the vendor's and compiles the two together against the merged asset table,
    so every one of those overrode the shipped half's mesh of the same name:
    the B2 plate lost the painted per-part shells its MJCF draws, taking the
    black trim with them, and drew one foot on the floor beside the robot at
    the merged mesh's own origin. Fourteen of B2's meshes, and every mesh of
    G1, H2 and Go2's vendor halves, were being drawn from the wrong file.

    SHALLOWEST WINS for the bare-name alias, within what is left. A twin-tuning tool
    once wrote its working model into `<twin>/tuned/`, and that alone moved the
    Go2 twin's reported mass from 12.78 kg to 14.39 — a folder that now holds a
    model and so is not read at all.
    """
    path = Path(path).resolve()
    root = path.parent
    assets: dict = {}
    for folder, subdirs, files in os.walk(root):
        folder = Path(folder)
        subdirs[:] = sorted(s for s in subdirs
                            if not _holds_model(folder / s))
        for name in sorted(files):
            f = folder / name
            if f.suffix.lower() not in ASSET_SUFFIXES:
                continue
            rel = str(f.relative_to(root))
            assets[rel] = f.read_bytes()
            assets.setdefault(f.name, assets[rel])
    return assets


def _holds_model(folder: Path) -> bool:
    """Is this directory some other model's own folder?"""
    return any(f.suffix.lower() in MODEL_SUFFIXES
               for f in folder.iterdir() if f.is_file())


def load_model(path: Path):
    """`MjModel.from_xml_path`, reading the assets rather than trusting the cache."""
    import mujoco
    path = Path(path).resolve()
    try:
        assets = read_assets(path)
        if assets:
            return mujoco.MjModel.from_xml_string(path.read_text(), assets)
    except Exception:                                   # noqa: BLE001
        pass                                            # fall back rather than fail
    return mujoco.MjModel.from_xml_path(str(path))


def load_spec(path: Path):
    """`MjSpec.from_file`, reading the assets rather than trusting the cache."""
    import mujoco
    path = Path(path).resolve()
    try:
        assets = read_assets(path)
        if assets:
            return mujoco.MjSpec.from_string(path.read_text(), assets=assets)
    except Exception:                                   # noqa: BLE001
        pass
    return mujoco.MjSpec.from_file(str(path))
