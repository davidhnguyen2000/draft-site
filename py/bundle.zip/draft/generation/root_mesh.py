"""Abstract base class for parametric root/torso meshes.

A RootMesh subclass defines a robot's root body geometry as a loft:
  - loft_axis   : the axis the cross-sections are stacked along
  - get_layers() : returns a list of Layer objects (position + 2D vertices)
                   computed from a parameter dict

The base class handles building, inertial property computation, and export
via the existing LayeredMeshBuilder infrastructure.

Usage (in a generator or notebook)::

    from humanoid.mesh import HumanoidTorsoMesh
    import yaml

    with open("parameters.yaml") as f:
        params = yaml.safe_load(f)

    mesh_obj = HumanoidTorsoMesh()
    mesh, props = mesh_obj.build_and_save(params, output_dir="generated/test/")
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path

import trimesh

from .layered_mesh import LayeredMeshBuilder, chamfered_rect_polygon, inertial_properties


# ── Layer dataclass ────────────────────────────────────────────────────────────

@dataclass
class Layer:
    """A single cross-section in a loft mesh.

    pos      : position along the loft axis
    vertices : 2-D polygon as [[u, v], ...] ordered CCW when viewed from +axis
    """
    pos: float
    vertices: list[list[float]]


# ── Convenience constructors ───────────────────────────────────────────────────

def rect_layer(pos: float, lx: float, ly: float,
               chamfer: float = 0.15,
               cx: float = 0.0, cy: float = 0.0) -> Layer:
    """Create a Layer with a chamfered-rectangle cross-section."""
    return Layer(pos=pos, vertices=chamfered_rect_polygon(lx, ly, chamfer, cx, cy))


def polygon_layer(pos: float, vertices: list[list[float]]) -> Layer:
    """Create a Layer from an explicit list of 2-D [u, v] vertices."""
    return Layer(pos=pos, vertices=vertices)


# ── Base class ─────────────────────────────────────────────────────────────────

class RootMesh(ABC):
    """Abstract base class for parametric root body meshes.

    Subclass interface
    ------------------
    loft_axis     : class var — 'x', 'y', or 'z'
    name          : class var — used as the STL / YAML file prefix
    density_param : class var — key in the params dict for density (kg/m³)

    get_layers(params) : abstract — return List[Layer] given a resolved params dict

    The vertex count must be identical across all layers returned by get_layers().
    Use rect_layer() for chamfered-rectangle cross-sections or polygon_layer()
    for arbitrary polygons.
    """

    loft_axis:     str = 'z'
    name:          str = 'root'
    density_param: str = 'torso_rho'  # override if your density key differs

    @abstractmethod
    def get_layers(self, params: dict) -> list[Layer]:
        """Return loft cross-sections computed from params."""
        ...

    # ── Private helpers ────────────────────────────────────────────────────────

    def _builder(self, params: dict) -> LayeredMeshBuilder:
        layers = self.get_layers(params)
        density = params.get(self.density_param, params.get('torso_rho', 100.0))
        return LayeredMeshBuilder(
            axis=self.loft_axis,
            planes=[{'position': l.pos, 'vertices': l.vertices} for l in layers],
            density=density,
            name=self.name,
        )

    # ── Public API ─────────────────────────────────────────────────────────────

    def build(self, params: dict) -> trimesh.Trimesh:
        """Return a watertight trimesh.Trimesh for the given parameters."""
        return self._builder(params).build()

    def build_and_save(self, params: dict, output_dir) -> tuple[trimesh.Trimesh, dict]:
        """Build mesh, export STL, and save inertial-properties YAML.

        Mirrors the LayeredMeshBuilder.build_and_save() output convention so
        the result integrates seamlessly with the existing xacro pipeline:
          {name}_mesh.stl
          {name}_inertial_properties.yaml

        Returns (mesh, props) where props is the inertial_properties() dict.
        """
        return self._builder(params).build_and_save(output_dir)
