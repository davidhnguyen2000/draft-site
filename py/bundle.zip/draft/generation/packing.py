"""Actuator packing — do the motors this design draws fit next to each other?

Every other law in `core/feasibility.py` prices a part. This one asks whether the parts
can be in the same machine at the same time: two actuator cylinders that share
volume are not a robot, they are two robots drawn on top of one another. Nothing
caught it before, and the failure is silent — the mass is charged twice into the
same litre of space, the inertia is wrong, and the model still simulates.

It bites hardest where a real machine packs a 3-DOF cluster: a hip whose three
axes cross within a few centimetres is normal hardware, and this tree can only
represent it by putting three full-size cylinders that far apart along one chain.
So a design measured off a real robot — a twin — is exactly the case that fails.

The test
--------
Each actuator is bounded by an ORIENTED box in its own frame — `L` along its
axis, `2r` across the other two — placed by the pose MuJoCo computes for it at
the neutral pose. Overlap is the separating-axis test over the 15 candidate axes
of two OBBs (three face normals each, nine edge cross-products), and the
penetration depth is the smallest overlap among them.

This used to be an axis-aligned test, justified by "bodies carry no rotation in
any tree here and every motor axis is a world axis". That was not a fact about
robots, it was a restriction the arithmetic imposed on them: a design could not
cant a hip without the gate silently mismeasuring it. The poses now come out of
the compiled model, so the restriction is gone.

Conservative in one direction only: two cylinders whose boxes overlap may still
miss each other (diagonally offset parallel cylinders). It never misses a real
intersection, which is the direction that matters for a feasibility gate.
"""

from __future__ import annotations

import math

import numpy as np

_AXIS_INDEX = {'x': 0, 'y': 1, 'z': 2}

#: Absolute floor: two actuators bolted face to face share a plane, and
#: floating-point noise must not fail a design.
TOLERANCE_M = 5e-4

#: …and a relative one. The gate cannot be tighter than the thing it measures:
#: the actuator envelope is DERIVED by a regression whose scatter is a good deal
#: wider than a percent, so an overlap of 2% of the smaller envelope is inside
#: the noise of `motor_r` and `motor_L` themselves and says nothing about
#: buildability. The base quadruped sits here — its hip-pitch and knee actuators
#: are coaxial and overlap 1.2 mm out of an 82 mm envelope, i.e. bolted flush.
#: A design that is actually infeasible overlaps by tens of millimetres.
TOLERANCE_FRACTION = 0.02

#: Below this fraction of an actuator's own volume, `structure_overlap`'s Monte
#: Carlo cannot tell overlap from sampling noise, so nothing smaller is even
#: recorded.
STRUCTURE_NOISE = 0.002

#: …and this is where the STRUCTURE gate trips. Same argument as
#: `TOLERANCE_FRACTION`: a percent of an actuator's volume is inside the scatter
#: of the regression that sized it. Above it, the solid really is inside the
#: trunk.
STRUCTURE_TOL = 0.01


def _obb(motor: dict) -> tuple:
    """Centre, rotation (columns are the box's own axes) and half-extents.

    An emitter that compiled the model supplies `R` and `half` directly. The
    fallback reconstructs the older world-axis form, so a caller that still
    describes an actuator by its axis letter keeps working.
    """
    c = np.asarray(motor['center'], dtype=float)
    if motor.get('R') is not None and motor.get('half') is not None:
        return (c, np.asarray(motor['R'], dtype=float).reshape(3, 3),
                np.asarray(motor['half'], dtype=float))
    ax = _AXIS_INDEX.get(str(motor.get('axis', 'z')).lstrip('+-'), 0)
    half = np.array([motor['r'], motor['r'], motor['r']], dtype=float)
    half[ax] = motor['L'] / 2.0
    return c, np.eye(3), half


def _tolerance(ra: float, rb: float) -> float:
    """Tolerance on ONE candidate axis, from the extents being compared on it.

    Deliberately per-axis rather than a single figure for the pair: the relative
    part of the tolerance stands for the scatter in `motor_r` / `motor_L`, and
    the scatter that matters is the one on the dimension actually being measured.
    Taking the smallest half-extent of either box instead makes the gate tighter
    than the regression it is built on, and refuses designs over a millimetre of
    a dimension that was never in question.
    """
    return max(TOLERANCE_M, TOLERANCE_FRACTION * 2.0 * min(ra, rb))


def overlap(a: dict, b: dict) -> dict | None:
    """Penetration between two actuators, or None when they are clear.

    Returns the depth and the axis it is measured on, so a report can say *how*
    the two collide rather than only that they do.
    """
    ca, Ra, ha = _obb(a)
    cb, Rb, hb = _obb(b)
    d = cb - ca

    # Candidate separating axes: three face normals from each box, then the nine
    # cross-products of their edge directions. Degenerate crosses (parallel
    # edges) drop out — the face normals already cover those cases.
    axes, labels = [], []
    for i in range(3):
        axes.append(Ra[:, i]); labels.append(f'a{"xyz"[i]}')
        axes.append(Rb[:, i]); labels.append(f'b{"xyz"[i]}')
    for i in range(3):
        for j in range(3):
            v = np.cross(Ra[:, i], Rb[:, j])
            n = float(np.linalg.norm(v))
            if n > 1e-9:
                axes.append(v / n)
                labels.append(f'a{"xyz"[i]}xb{"xyz"[j]}')

    depth, axis, tol = None, None, TOLERANCE_M
    for v, label in zip(axes, labels):
        # Projected half-width of each box onto the candidate axis.
        ra = float(np.abs(Ra.T @ v) @ ha)
        rb = float(np.abs(Rb.T @ v) @ hb)
        gap = abs(float(d @ v)) - (ra + rb)
        axis_tol = _tolerance(ra, rb)
        if gap >= -axis_tol:
            return None                      # a separating axis exists
        if depth is None or -gap < depth:
            depth, axis, tol = -gap, label, axis_tol
    return {'a': a['name'], 'b': b['name'], 'depth_m': round(depth, 6),
            'axis': axis, 'tolerance_m': round(tol, 6),
            'a_class': a.get('motor_class'), 'b_class': b.get('motor_class'),
            'a_drives': a.get('drives'), 'b_drives': b.get('drives')}


def _consecutive(a: dict, b: dict, all_motors: list) -> bool:
    """Are these two actuators neighbours on one chain, with nothing between?

    This is the distinction that makes the gate usable. Two actuators that sit
    one after the other on the same limb are held apart by exactly one thing —
    the link between them — and if they interpenetrate the design is not
    buildable at any joint angle. Two actuators on DIFFERENT limbs that touch in
    the neutral pose (a humanoid's hand hangs beside its hip) are a pose
    artifact: the joints between them can move them apart, and refusing the
    design over it would refuse most humanoids.
    """
    pa, pb = a.get('path') or (), b.get('path') or ()
    if len(pa) > len(pb):
        pa, pb = pb, pa
    if pb[:len(pa)] != pa:
        return False                          # different branches
    between = set(pb[len(pa):-1])
    return not any(m['body'] in between for m in all_motors)


def check(motor_geoms: list, exempt: set | None = None) -> dict:
    """Every interpenetrating pair of actuators, split by whether it can move apart.

    `exempt` holds geom names a tree has declared are drawn representations of an
    actuator already counted elsewhere — the quadruped's belt-driven knee pulley
    is drawn at the knee while its motor is priced at the hip, and the two are
    the same physical actuator rather than two that collide.
    """
    exempt = exempt or set()
    live = [m for m in motor_geoms if m['name'] not in exempt]
    by_name = {m['name']: m for m in live}
    hard, soft = [], []
    for i, a in enumerate(live):
        for b in live[i + 1:]:
            if a['body'] == b['body']:
                continue                     # one body draws at most one actuator
            hit = overlap(a, b)
            if not hit:
                continue
            (hard if _consecutive(a, b, live) else soft).append(hit)
    hard.sort(key=lambda p: -p['depth_m'])
    soft.sort(key=lambda p: -p['depth_m'])
    return {
        'n_actuator_geoms': len(live),
        'n_exempt': len(exempt),
        'n_overlapping_pairs': len(hard),
        'n_neutral_pose_pairs': len(soft),
        'worst_depth_m': hard[0]['depth_m'] if hard else 0.0,
        'worst_neutral_pose_depth_m': soft[0]['depth_m'] if soft else 0.0,
        'tolerance_m': TOLERANCE_M,
        'tolerance_fraction': TOLERANCE_FRACTION,
        'pairs': hard[:24],
        'neutral_pose_pairs': soft[:12],
    }


def messages(report: dict) -> list:
    """One line per un-buildable pair, in the form `FeasibilityViolation` prints."""
    out = []
    for p in report['pairs']:
        drives = ''
        if p.get('a_drives') and p.get('b_drives'):
            drives = f" ({p['a_drives']} → {p['b_drives']})"
        out.append(
            f"actuator packing: {p['a']} and {p['b']}{drives} interpenetrate by "
            f"{p['depth_m'] * 1e3:.1f} mm along {p['axis']} "
            f"(tolerance {p['tolerance_m'] * 1e3:.1f} mm). They are consecutive "
            f"on one chain, so no joint angle separates them: the link between "
            f"them is shorter than the two actuator half-envelopes it must hold "
            f"apart.")
    extra = report['n_overlapping_pairs'] - len(report['pairs'])
    if extra > 0:
        out.append(f"actuator packing: {extra} further overlapping pair(s) not listed.")
    return out


def soft_messages(report: dict) -> list:
    """Actuators that touch in the neutral pose but can be driven apart."""
    if not report['n_neutral_pose_pairs']:
        return []
    worst = report['neutral_pose_pairs'][0]
    return [
        f"actuator packing: {report['n_neutral_pose_pairs']} actuator pair(s) "
        f"interpenetrate in the NEUTRAL POSE only — worst {worst['a']} vs "
        f"{worst['b']} at {worst['depth_m'] * 1e3:.0f} mm. Joints separate them, "
        f"so the design is buildable, but that part of the workspace is not "
        f"reachable and contact will be generated there."]


def structure_overlap(model, data, rho: float, samples: int = 8000,
                      role_of=None) -> dict:
    """Actuator volume sitting inside the root MESH, and what it is charged twice.

    The gate above tests actuator against actuator. Nothing tested actuator
    against STRUCTURE, and the two failures that hole allows look identical in a
    picture: a member drawn through the actuator it hangs from (fixed
    analytically by `tree_ops.proximal_inset`) and an actuator drawn inside the
    trunk (not fixable analytically — the trunk is a lofted mesh — so it is
    measured and reported here).

    Some of it is deliberate — `shoulder_motor_inset` puts a stated fraction of
    the shoulder unit inside the trunk wall precisely so the trunk can be as
    wide as the one it is copying — and that volume is priced here, because it
    is charged once at the trunk's density and once at the density the motor trend
    solved. Everything else is a VIOLATION, not a warning: an actuator the
    design did not ask to bury is a solid drawn inside another solid. Which
    roles are allowed is stated per design in `structure_overlap_allowed`, and
    `structure_violations` below is the gate.

    Monte Carlo, because the trunk is an arbitrary loft. Only actuators whose
    axis-aligned box meets the mesh's are sampled, so the usual cost is one or
    two of them.
    """
    import mujoco
    out = {'mesh_volume_cm3': None, 'inside_cm3': 0.0, 'double_charged_kg': 0.0,
           'actuators': []}
    if model is None or data is None:
        return out
    meshes = [g for g in range(model.ngeom)
              if model.geom_type[g] == mujoco.mjtGeom.mjGEOM_MESH]
    if not meshes:
        return out
    try:
        import trimesh
    except ImportError:                                  # noqa: BLE001
        return out
    g = meshes[0]
    mid = model.geom_dataid[g]
    v0, nv = model.mesh_vertadr[mid], model.mesh_vertnum[mid]
    f0, nf = model.mesh_faceadr[mid], model.mesh_facenum[mid]
    R = np.asarray(data.geom_xmat[g]).reshape(3, 3)
    verts = model.mesh_vert[v0:v0 + nv].reshape(-1, 3) @ R.T + data.geom_xpos[g]
    tm = trimesh.Trimesh(vertices=verts,
                         faces=model.mesh_face[f0:f0 + nf].reshape(-1, 3),
                         process=False)
    lo, hi = verts.min(axis=0), verts.max(axis=0)
    out['mesh_volume_cm3'] = round(float(tm.volume) * 1e6, 1)
    rng = np.random.default_rng(0)
    total = 0.0
    for gi in range(model.ngeom):
        name = mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_GEOM, gi) or ''
        # Every SOLID the tree draws, not only the actuators. Scanning `_motor`
        # alone answered "is an actuator buried in the trunk" and left the
        # question that was actually being asked — is anything drawn inside the
        # trunk — unanswered, and the thing that was hiding in the gap was the
        # neck: `head_link_link` runs up from the shoulder-axis origin and its
        # first `shoulder_pitch_motor_r * 1.5` is inside the loft, 31% of it on
        # the G1 twin and 35% on H2, charged at `link_rho` and again at
        # `torso_rho`. `_detail` rings are skipped: they are weightless and
        # always co-located with the `_motor` that already answers for them.
        if (not name.endswith(('_motor', '_link', '_sphere'))
                or name.endswith('_detail')
                or model.geom_type[gi] != mujoco.mjtGeom.mjGEOM_CYLINDER):
            continue
        c = np.asarray(data.geom_xpos[gi], float)
        r, h = float(model.geom_size[gi][0]), float(model.geom_size[gi][1])
        reach = math.sqrt(r * r + h * h)
        if np.any(c + reach < lo) or np.any(c - reach > hi):
            continue
        Rg = np.asarray(data.geom_xmat[gi]).reshape(3, 3)
        z = rng.uniform(-h, h, samples)
        t = rng.uniform(0, 2 * math.pi, samples)
        rr = r * np.sqrt(rng.uniform(0, 1, samples))
        pts = np.stack([rr * np.cos(t), rr * np.sin(t), z], 1) @ Rg.T + c
        frac = float(tm.contains(pts).mean())
        if frac <= STRUCTURE_NOISE:
            continue
        vol = math.pi * r * r * 2 * h * frac
        total += vol
        out['actuators'].append({'geom': name, 'inside_frac': round(frac, 4),
                                 'drives': (role_of or {}).get(name),
                                 'inside_cm3': round(vol * 1e6, 1)})
    out['inside_cm3'] = round(total * 1e6, 1)
    out['double_charged_kg'] = round(total * float(rho), 4)
    return out


def structure_violations(report: dict, allowed, tol: float = STRUCTURE_TOL) -> list:
    """Actuators drawn inside the root mesh that the design did not ask for.

    The counterpart of `messages` for the actuator-vs-actuator gate. An actuator
    inside the trunk is the same failure as two actuators inside each other —
    one litre of space holding two solids, and its mass charged twice — and it
    was only ever reported. It is a violation now, and a design says which roles
    are exceptions with `structure_overlap_allowed`: the humanoid's
    `shoulder_pitch`, because `shoulder_motor_inset` puts it there on purpose,
    and the quadruped's `hip_roll`, which is 100% buried by construction because
    the trunk density it is charged at was measured against a box containing it.

    `tol` is a Monte-Carlo noise floor, not a licence: 1% of an actuator's own
    volume is below what this sampling can resolve, and above it the geometry is
    real.
    """
    out = []
    ok = set(allowed or ())
    for a in report.get('actuators') or ():
        # By ROLE where the tree declares one, and by GEOM NAME otherwise. An
        # actuator that arrives inside an attached `module:` MJCF has no
        # `motor_for` to declare — the module is a plain MJCF file — so its name
        # is the only handle the design has on it, the same handle
        # `packing_exempt_geoms` uses.
        if (float(a.get('inside_frac') or 0.0) <= tol
                or a.get('drives') in ok or a.get('geom') in ok):
            continue
        out.append(
            f"{a['geom']} is drawn {100 * a['inside_frac']:.0f}% inside the root "
            f"mesh ({a['inside_cm3']:.0f} cm3), which no design declared: it "
            f"drives {a.get('drives') or 'an undeclared role'}, and only "
            f"{', '.join(sorted(ok)) or '(nothing)'} may live in the structure. "
            f"That volume holds two solids and is charged at both their "
            f"densities.")
    return out


def structure_messages(report: dict, trunk_mass: float,
                       frac: float = 0.05) -> list:
    """Warn when the trunk is paying for a meaningful volume of actuator."""
    kg = float(report.get('double_charged_kg') or 0.0)
    if trunk_mass <= 0 or kg <= frac * trunk_mass:
        return []
    worst = max(report.get('actuators') or [], key=lambda a: a['inside_cm3'],
                default=None)
    return [f"{report['inside_cm3']:.0f} cm3 of actuator is drawn inside the root "
            f"mesh, so {kg:.2f} kg is charged both at the trunk's density and at "
            f"the motor trend's — {kg / trunk_mass * 100:.0f}% of the trunk"
            + (f", worst {worst['geom']} at {worst['inside_frac'] * 100:.0f}% "
               f"buried" if worst else "") + "."]


def required_separation(a: dict, b: dict, axis: str) -> float:
    """Centre-to-centre distance along world `axis` that would just clear the pair."""
    v = np.zeros(3)
    v[_AXIS_INDEX[axis]] = 1.0
    _, Ra, ha = _obb(a)
    _, Rb, hb = _obb(b)
    return (float(np.abs(Ra.T @ v) @ ha) + float(np.abs(Rb.T @ v) @ hb)
            + TOLERANCE_M)
