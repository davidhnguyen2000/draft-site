"""RobotGenerator: tree.yaml/tree.py + mesh.py + parameters.yaml → MJCF.

New-robot checklist
-------------------
1. Create  src/draft/robots/<name>/
2. Add     parameters.yaml   — flat param values (motor sizes, link lengths, colors, …)
3. Add     tree.yaml         — static kinematic tree using ${param} expressions, OR
           tree.py           — define get_tree(params) -> dict for variable-topology
                               robots (hand, or any robot where the structure depends
                               on params such as a configurable number of fingers)
4. Add     mesh.yaml         — the root body's mesh as a stack of cross-sections
   (omit it for robots whose root body is a primitive geom or has no mesh; a
    mesh.py RootMesh subclass remains as an escape hatch for a shape that is not
    a loft at all)

There is no separate design-space file. Which parameters a sweep may move used to
be declared in `design_space.yaml`, with bounds; the fitted trends now decide what a
design is allowed to be, and they check the assembled robot rather than a stated
range. A hand-maintained classification alongside them was a second source of
truth that nothing read and that had already drifted from the values it named.

Then call  RobotGenerator(Path('src/draft/<name>')).generate(output_dir)
or run     draft-generate --robot <name>
"""

from __future__ import annotations

import importlib.util
import math
import re
import shutil
import sys
from datetime import datetime
from pathlib import Path
from typing import Any

import yaml

from .expr_eval import attrdict, resolve
from .mesh_spec import MeshSpec
from ..trends.feasibility import (BatteryTrend, FeasibilityViolation, LinkTrends,
                          link_fits)
from ..trends.motor_solve import (DERIVED_FIELDS, FREE_INPUTS, MODE_INPUTS,
                          design_class)
from .spec_builder import SpecEmitter
from .tree_ops import apply_distal_taper, expand_mirrors, measured_taper
from . import packing
from ..trends.motor_catalog import resolve_catalog_motors


# ── YAML helpers ───────────────────────────────────────────────────────────────

def _load_yaml(path: Path) -> dict:
    with path.open() as f:
        return yaml.safe_load(f) or {}


# ── Mesh class loader ──────────────────────────────────────────────────────────

def _ensure_src_path(robot_dir: Path) -> None:
    """Add src/ to sys.path so absolute imports inside robot modules work.

    Found by walking up rather than by counting parents, so a robot directory can
    be nested however the layout wants it (it moved from
    `draft/robots/<name>/` to `draft/robots/<name>/`, and counting
    would have silently put the wrong directory on the path).
    """
    for parent in robot_dir.resolve().parents:
        if parent.name == 'src':
            if str(parent) not in sys.path:
                sys.path.insert(0, str(parent))
            return


def _load_root_mesh(robot_dir: Path):
    """The robot's root-body mesh: a `mesh.yaml`, or a `mesh.py` class, or None.

    `mesh.yaml` is preferred and is what every robot here uses — a root mesh is a
    stack of parallel cross-sections, which is data. `mesh.py` stays as the
    escape hatch for a shape that is not (a swept curve, a boolean, imported
    CAD), on the same terms as `tree.py`. Both are returned as an INSTANCE with
    `.name`, `.density_param` and `.build_and_save(params, out)`, so nothing
    downstream has to know which was used.
    """
    mesh_yaml = robot_dir / 'mesh.yaml'
    if mesh_yaml.exists():
        return MeshSpec.load(mesh_yaml)

    mesh_py = robot_dir / 'mesh.py'
    if not mesh_py.exists():
        return None

    _ensure_src_path(robot_dir)
    spec = importlib.util.spec_from_file_location('_robot_mesh', mesh_py)
    mod  = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)

    # Find any RootMesh subclass by duck-typing (avoids cross-import issues)
    for name in dir(mod):
        obj = getattr(mod, name)
        try:
            if (isinstance(obj, type)
                    and obj.__name__ != 'RootMesh'
                    and hasattr(obj, 'get_layers')
                    and hasattr(obj, 'build_and_save')):
                return obj()
        except Exception:
            continue
    return None


def _load_tree_fn(robot_dir: Path):
    """Import tree.py from robot_dir and return its get_tree function, or None.

    Use this instead of tree.yaml for robots with variable topology (e.g. hand).
    """
    tree_py = robot_dir / 'tree.py'
    if not tree_py.exists():
        return None

    _ensure_src_path(robot_dir)
    spec = importlib.util.spec_from_file_location('_robot_tree', tree_py)
    mod  = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return getattr(mod, 'get_tree', None)


# ── Physical-law application ───────────────────────────────────────────────────

# A motor CLASS key is a bare token before `_motor_effort` (L, M, S, F …).
# `hip_pitch_motor_effort` is a per-JOINT key and must not be mistaken for one.
_CLASS_RE = re.compile(r'^([A-Za-z][A-Za-z0-9]*)_motor_effort$')

# Fields the fitted trends OWN. A value for one of these in parameters.yaml is
# ignored, because the trend derives it from (peak torque, gear ratio).
_DERIVED_MOTOR_FIELDS = tuple(f for f in DERIVED_FIELDS if f != 'mass')

# Inputs a MODE derives rather than reads (`torque_gear` computes the no-load
# speed, so a speed left in the file is stale). Recorded like the derived
# envelope fields, for the same reason: a number that no longer drives anything
# should be visible as such rather than sitting there looking authoritative.
_MODE_SOLVED_FIELDS = ('effort', 'velocity', 'gear', 'power')


def reference_population(params: dict) -> str:
    """Measured population this design is sized and vetted against.

    ``mass_composition_reference`` names it. A robot that declares none (the
    hands) still gets the structural-density gate, and the humanoid band is the
    widest one available — but it is NOT audited, which the generator decides
    from the declaration itself rather than from this fallback.
    """
    ref = params.get('mass_composition_reference')
    return ref if ref in LinkTrends.POPULATIONS else 'humanoid'


def _motor_class_names(params: dict) -> list[str]:
    """Motor size classes declared in params, in declaration order."""
    out = []
    for key in params:
        m = _CLASS_RE.match(str(key))
        if m and '_' not in m.group(1):
            out.append(m.group(1))
    return out


def size_actuators(params: dict, strict: bool = True) -> tuple[dict, dict]:
    """Size every motor class from its stated operating point via the fitted trends.

    A class states any TWO of (torque, speed, gear ratio, power) — which two is
    ``<cls>_motor_mode``, defaulting to the historical torque+speed — and
    ``core/motor_solve.py`` solves the rest. Radius, length, effective density and
    armature are DERIVED here, as is whichever of the operating-point quantities
    the mode does not read; whatever parameters.yaml said about any of them is
    overwritten, and the overwrite is recorded in the report so a stale hand-set
    value is visible rather than silent.

    Raises FeasibilityViolation when a class beats the catalogued frontier, unless the
    design opts in to hypothetical actuators via ``allow_hypothetical: true``.
    """
    params = dict(params)
    allow = bool(params.get('allow_hypothetical', False))
    report: dict = {'classes': {}, 'errors': [], 'warnings': []}

    for cls in _motor_class_names(params):
        design = design_class(cls, params)
        point, sized = design.point, design.sized

        ignored = []
        for key, derived in design.as_params().items():
            if key.endswith('_mode'):
                continue
            field = key.rsplit('_', 1)[-1]
            # `aspect` is stated in every mode (it is a packaging choice, not a
            # law), so it is never a value the solve overwrote.
            solved = (field in _DERIVED_MOTOR_FIELDS
                      or (field not in MODE_INPUTS[point.mode]
                          and field not in FREE_INPUTS))
            old = params.get(key)
            if (solved and old is not None
                    and abs(float(old) - derived) > 1e-9 * max(1.0, abs(derived))):
                ignored.append({'param': key, 'declared': float(old),
                                'derived': round(derived, 8)})
            params[key] = derived

        report['errors'].extend(design.errors)
        report['warnings'].extend(design.warnings)
        dens = design.densities()
        report['classes'][cls] = {
            'anchor': sized['anchor'], 'category': sized['category'],
            'designed_from': point.mode,
            'gear_ratio': round(point.gear, 3), 'gear_source': point.gear_source,
            'effort_Nm': round(point.tau, 4),
            'velocity_rad_s': round(point.omega, 6),
            'mass_kg': round(sized['mass'], 6),
            'radius_m': round(sized['r'], 6), 'length_m': round(sized['L'], 6),
            'volume_cm3': round(sized['volume'] * 1e6, 2),
            'aspect_LD': round(sized['aspect'], 4),
            'aspect_source': sized['aspect_source'],
            'density_kg_m3': round(sized['rho'], 2),
            'rotor_inertia_kgm2': round(sized['J_rotor'], 12),
            'rotor_inertia_from': sized['J_rotor_source'],
            'armature_kgm2': round(sized['armature'], 9),
            'torque_density_Nm_per_kg': round(dens['torque_density']['value'], 1),
            'power_density_W_per_kg': round(dens['power_density']['value'], 1),
            'peak_power_W': round(point.power, 1),
            'frontier_tau_max_Nm': round(design.ceilings()['tau_max'], 1),
            'overridden_by_law': ignored,
        }

    if 'link_rho' in params:
        # Against the design's OWN population: a quadruped limb is a lighter
        # structure than a humanoid one (measured band 201-742 vs 52-1450 kg/m³),
        # so checking one against the other's band is not conservative.
        report['errors'].extend(
            link_fits(reference_population(params)).check_link_density(
                float(params['link_rho'])))

    if report['errors'] and strict and not allow:
        raise FeasibilityViolation(report['errors'])
    if allow and report['errors']:
        report['warnings'] = ([f'allow_hypothetical: {m}' for m in report['errors']]
                              + report['warnings'])
        report['errors'] = []
    return params, report


def _inertia_box_volume(props: dict) -> float | None:
    """Volume of the solid box that reproduces a body's principal inertias.

    The same construction `datasets/robot_descriptions/scripts/02_parse_descriptions.py` applies
    to every official description, so a generated body and a measured one are
    described by the same number. Shape only: the box depends on the NORMALISED
    inertia, so a uniform body gives the same box at any density.

        I_xx = m(b²+c²)/12  ->  a² = 6(I_yy + I_zz - I_xx)/m   (and cyclic)

    Returns None for a tensor no solid body can have (the triangle inequality
    fails), which is a real thing in shipped descriptions and must not become a
    silent zero here.
    """
    import numpy as _np
    m = float(props.get('mass') or 0.0)
    I = props.get('inertia_com')
    if m <= 0 or I is None:
        return None
    d = _np.linalg.eigvalsh(_np.asarray(I, dtype=float))
    sq = [6.0 * (d[(i + 1) % 3] + d[(i + 2) % 3] - d[i]) / m for i in range(3)]
    if any(v <= 0 for v in sq):
        return None
    a, b, c = (math.sqrt(v) for v in sq)
    return float(a * b * c)


def derive_segment_densities(params: dict) -> tuple[dict, dict]:
    """Derive every ``<seg>_rho`` the design's population has measured.

    The humanoid shipped `head_rho: 449.0`, `hand_rho: 503.5`, `foot_rho: 286.2`
    — three copies of datasets/robot_descriptions medians, pasted in by a calibration run and free
    to drift from the dataset the moment it was re-fit. They are measurements, not
    choices: a head is a shell around empty volume and the fit says what that
    weighs. So they are read from the trends instead of restated, exactly like the
    actuator envelope.

    Applied ONLY to a design that declares ``mass_composition_reference``. A robot
    with no comparable measured population (the hands) must not borrow another
    body plan's densities — the same rule that governs the mass-composition audit.
    ``link_rho`` is untouched: it is a cross-class compromise solved per design by
    `datasets/robot_descriptions/scripts/08_calibrate_generator.py`, not any one class's median.
    """
    params = dict(params)
    report: dict = {'population': params.get('mass_composition_reference'),
                    'derived': {}, 'warnings': []}
    if params.get('mass_composition_reference') not in LinkTrends.POPULATIONS:
        report['note'] = ('no measured population declared — segment densities '
                          'left as stated')
        return params, report

    laws = link_fits(reference_population(params))
    for key, law in laws.segment_density_params(params).items():
        declared = params.get(key)
        params[key] = law['rho']
        entry = {'segment': law['segment'], 'rho_kg_m3': round(law['rho'], 3),
                 'measured_p10_p90': [law['p10'], law['p90']], 'n': law['n'],
                 'source': f"{law['population']} {law['segment']} structural "
                           f"effective density (datasets/robot_descriptions)"}
        if declared is not None and abs(float(declared) - law['rho']) > 1e-9:
            entry['declared'] = float(declared)
        report['derived'][key] = entry
    return params, report


def _joint_axis(joint: dict) -> tuple | None:
    """A tree joint's axis as a unit vector in its body frame, or None."""
    a = joint.get('axis')
    if isinstance(a, str):
        return {'x': (1.0, 0.0, 0.0), 'y': (0.0, 1.0, 0.0),
                'z': (0.0, 0.0, 1.0)}.get(a.strip().lstrip('+-'))
    if isinstance(a, (list, tuple)) and len(a) == 3:
        v = [float(x) for x in a]
        n = math.sqrt(sum(x * x for x in v))
        return tuple(x / n for x in v) if n > 0 else None
    return None


def _assign_structural_mass(tree: dict, fits: LinkTrends,
                            population: str | None) -> None:
    """Give every structural member its class trend's mass and density.

    Members are grouped into SEGMENTS the way datasets/robot_descriptions groups
    a shipped description (stage 2): a body with a joint starts one, and bodies
    with no joint of their own belong to it — the quadruped's lateral hip link
    and its thigh hang off the same hip-pitch joint, so they are one thigh.

    A segment's target is its class's structural mass
    (``LinkTrends.structural_mass``) at the segment's joint-to-joint length: the
    distance from its joint to the next joint down the chain, or its members'
    own length for a terminal segment (hand, foot, shank, head). Where the two
    joint axes are parallel (hip pitch to knee) it is the distance between the
    AXES, not the anchors: an anchor slides along its own axis without changing
    any kinematics, and this tree puts the hip-pitch anchor inboard of the leg
    plane, so anchor to anchor was a diagonal that priced a Go2 thigh at 0.233 m
    against its 0.213. It is shared
    among that segment's members of the class in proportion to their length.
    The root body is the trunk, not a limb segment, so a member on it uses its
    own length. Each member also takes its class's structural effective density
    (``LinkTrends.member_density``) unless the tree states one.

    Written onto the resolved tree as ``link_mass_kg`` / ``link_mass_basis`` /
    ``link_rho`` for the emitter, which solves the radius. A member naming a
    class its population has no law for is an error, not a fallback.
    """
    segs: dict[str, dict] = {}

    def pos(node):
        return [float(v) for v in (node.get('pos') or (0.0, 0.0, 0.0))]

    def walk(node, seg, offset, is_root=False):
        j = node.get('joint')
        if not is_root and isinstance(j, dict) and j.get('name'):
            here, below = segs[seg]['axis'], _joint_axis(j)
            if here is not None and below is not None and abs(
                    sum(a * b for a, b in zip(here, below))) > 0.999:
                along = sum(o * a for o, a in zip(offset, here))
                offset = [o - along * a for o, a in zip(offset, here)]
            segs[seg]['child_joints'].append(math.sqrt(sum(v * v for v in offset)))
            seg, offset = node['name'], [0.0, 0.0, 0.0]
            segs[seg] = {'members': [], 'child_joints': [], 'root': False,
                         'axis': _joint_axis(j)}
        g = node.get('geometry') or {}
        if g.get('link_mass_class') and float(g.get('link_l') or 0.0) > 0.0:
            segs[seg]['members'].append(node)
        for child in node.get('children', []) or []:
            walk(child, seg, [a + b for a, b in zip(offset, pos(child))])

    segs[tree['name']] = {'members': [], 'child_joints': [], 'root': True,
                          'axis': None}
    walk(tree, tree['name'], [0.0, 0.0, 0.0], is_root=True)

    for seg_name, s in segs.items():
        by_cls: dict[str, list] = {}
        for n in s['members']:
            by_cls.setdefault(str(n['geometry']['link_mass_class']), []).append(n)
        for cls, nodes in by_cls.items():
            lengths = [float(n['geometry']['link_l']) for n in nodes]
            groups = ([([n], [L]) for n, L in zip(nodes, lengths)] if s['root']
                      else [(nodes, lengths)])
            for grp, lens in groups:
                seg_len = (max(s['child_joints'])
                           if s['child_joints'] and not s['root'] else sum(lens))
                pop_ok = population in LinkTrends.POPULATIONS
                law = fits.structural_mass(cls, seg_len) if pop_ok else None
                rho = fits.member_density(cls) if pop_ok else None
                if law is None or rho is None:
                    raise ValueError(
                        f"{grp[0].get('name')}: link_mass_class {cls!r} has no "
                        f"structural {'linear density' if law is None else 'density'} "
                        f"law for population {population!r} "
                        f"(datasets/robot_descriptions link_trends.json)")
                for n, L in zip(grp, lens):
                    g = n['geometry']
                    share = L / sum(lens)
                    g['link_mass_kg'] = law['mass_kg'] * share
                    g['link_mass_basis'] = {**law, 'segment_root': seg_name,
                                            'share': round(share, 4)}
                    g.setdefault('link_rho', rho['rho'])


def collect_joints(node: dict, out: list | None = None) -> list[dict]:
    """Every actuated joint in a resolved tree, with its motor class.

    A `module:` node brings joints in from a separate MJCF file, so it declares
    them under `joints:` — the trends price one actuator per declared joint, and an
    undeclared one would ride into the model without being paid for.
    """
    out = [] if out is None else out
    j = node.get('joint')
    if isinstance(j, dict) and 'motor_class' in j:
        out.append({'name': j.get('name', node.get('name')),
                    'motor_class': str(j['motor_class']),
                    'effort': j.get('effort'), 'velocity': j.get('velocity')})
    prefix = str(node.get('prefix', f"{node.get('name', '')}_"))
    for jname, cls in (node.get('joints') or {}).items():
        out.append({'name': f'{prefix}{jname}', 'motor_class': str(cls),
                    'effort': None, 'velocity': None})
    for child in node.get('children', []) or []:
        collect_joints(child, out)
    return out


def installed_power_W(joints: list[dict], params: dict) -> float:
    """Σ peak mechanical power over the actuators, in the catalogue's τ·ω/4 convention.

    This is the load the pack is sized against, and it is now COUNTED from the
    mirror-expanded tree rather than carried as a hand-updated constant — a design
    that adds a limb pays for it in battery mass automatically.
    """
    total = 0.0
    for j in joints:
        cls = j['motor_class']
        tau = float(j['effort'] if j.get('effort') is not None
                    else params[f'{cls}_motor_effort'])
        omega = float(j['velocity'] if j.get('velocity') is not None
                      else params[f'{cls}_motor_velocity'])
        total += tau * omega / 4.0
    return total


def actuator_mass_audit(joints: list[dict], params: dict,
                        emitted_motor_kg: float) -> dict:
    """Does the model weigh the actuators the trends actually charged for?

    The motor trends price one actuator per declared joint. What MuJoCo weighs is
    whatever motor geoms the tree drew, at whatever radius and length it drew
    them — and a tree is free to override both. Nothing connected the two, so a
    tree could render an actuator twice, or at 60% of its envelope, and every
    downstream law would still be computed from the price list rather than from
    the machine. This is the reconciliation: charged vs emitted.

    It is a warning, not an error. Drawing one actuator as two bodies (a
    belt-driven knee with its motor at the hip and its output at the joint) is a
    legitimate way to model a real drivetrain — but then the two geoms have to
    SPLIT the actuator's mass, not each carry it.
    """
    charged = sum(float(params[f"{j['motor_class']}_motor_mass"]) for j in joints)
    ratio = emitted_motor_kg / charged if charged > 0 else None
    return {
        'n_joints': len(joints),
        'charged_by_motor_law_kg': round(charged, 4),
        'emitted_motor_geom_kg': round(emitted_motor_kg, 4),
        'emitted_over_charged': round(ratio, 4) if ratio else None,
    }


def _z_span(node: dict, z: float = 0.0, acc: list | None = None) -> float:
    """Vertical span of the joint frames in the neutral pose (no euler in any tree)."""
    acc = [] if acc is None else acc
    z = z + float((node.get('pos') or [0, 0, 0])[2])
    acc.append(z)
    for child in node.get('children', []) or []:
        _z_span(child, z, acc)
    return max(acc) - min(acc)


def size_metric(params: dict, tree: dict, population: str) -> float | None:
    """The length this design's allometry is checked against.

    Each measured population is fit against its own size (datasets/robot_descriptions stage 5):
    a humanoid against the vertical span of its joint frames, a quadruped against
    thigh + shank. The z-span of a quadruped is the crouch depth of the neutral
    pose the tree happens to declare and predicts nothing (R²=0.07 against mass,
    versus 0.88 for the leg), so it cannot be the one metric for both.

    A robot states its own with ``size_metric_expr`` — an ``${expr}`` over
    parameters.yaml — because only the design knows which of its links form the
    limb. Absent that, the z-span is used, which is right for a humanoid and is
    why the humanoid does not need to declare one.
    """
    expr = params.get('size_metric_expr')
    if expr:
        return float(resolve(str(expr), params))
    if population == 'quadruped':
        return None      # z-span would be actively misleading — check nothing
    return _z_span(tree) or None


# ── Parameter expansion ────────────────────────────────────────────────────────

def _resolve_param_exprs(params: dict) -> dict:
    """Resolve ``${}`` expressions used as parameter VALUES.

    A parameters file states a design's inputs, but some of those inputs are
    rules over the others rather than free numbers — the quadruped's foot radius
    is defined as a multiple of its calf's, so a design that changes motor class
    or leg proportions cannot leave a stale foot behind. Resolved in repeated
    passes, so one derived parameter may key off another; keys ending in
    ``_expr`` are left alone, since those are consumed as expressions elsewhere
    (``size_metric_expr``). Runs after the motor trends, so a rule is free to
    reference the trend-derived actuator envelope.
    """
    out = dict(params)
    pending = {k: v for k, v in out.items()
               if isinstance(v, str) and '${' in v and not k.endswith('_expr')}
    while pending:
        done = []
        for key, expr in pending.items():
            try:
                out[key] = resolve(expr, out)
            except ValueError:
                continue      # depends on a parameter not resolved yet
            done.append(key)
        if not done:
            raise ValueError('Parameter expressions cannot be resolved (unknown '
                             'name or circular reference): '
                             + ', '.join(f'{k}: {v}' for k, v in sorted(pending.items())))
        for key in done:
            pending.pop(key)
    return out


def _expand_motor_params(params: dict) -> dict:
    """Add {joint}_motor_* derived keys from every {joint}_mot assignment.

    Example: hip_pitch_mot: L  →  hip_pitch_motor_r, hip_pitch_motor_L, … all
    equal to the corresponding L_motor_* values. This lets tree.yaml use
    ${hip_pitch_motor_L} without manual look-up.

    Runs AFTER size_actuators, so the per-class values it copies onto each joint
    are the trend-derived ones — a joint can never carry a geometry the class does
    not have.
    """
    expanded = dict(params)
    classes = set(_motor_class_names(params))
    global_rho = float(params.get('motor_rho', 2700.0))
    for key, val in list(params.items()):
        if not (key.endswith('_mot') and isinstance(val, str) and val in classes):
            continue
        joint = key[:-4]   # strip '_mot'
        cls   = val
        fields = ('r', 'L', 'effort', 'velocity', 'friction', 'damping', 'armature')
        for f in fields:
            expanded.setdefault(f'{joint}_motor_{f}', params[f'{cls}_motor_{f}'])
        # Use catalog-resolved per-class rho when available, fall back to global
        cls_rho = float(params.get(f'{cls}_motor_rho', global_rho))
        expanded.setdefault(f'{joint}_motor_rho', cls_rho)
    return expanded


# ── Tree resolution ────────────────────────────────────────────────────────────

def _resolve_value(v: Any, params: dict) -> Any:
    if isinstance(v, dict):
        return {k: _resolve_value(vv, params) for k, vv in v.items()}
    if isinstance(v, list):
        return [_resolve_value(x, params) for x in v]
    if isinstance(v, str):
        return resolve(v, params)
    return v

def disabled_roles(params: dict) -> set:
    """Joint roles this design has switched off, via ``<role>_dof: false``.

    A companion to the ``<role>_mot`` convention. The parametric trees have a
    fixed topology, which is wrong for any real robot that has fewer joints than
    the tree does: a twin of a 4-DOF arm should not carry three wrists it then
    has to pay actuator mass for. Turning the role off removes the joint AND the
    actuator that drove it, leaving the structural link in place — the limb
    segment is still there, it simply does not bend at that point.
    """
    return {str(k)[:-4] for k, v in params.items()
            if str(k).endswith('_dof') and v is False}


def prune_disabled_joints(node: dict, roles: set, removed: list | None = None) -> list:
    """Strip every joint whose role is off, and the actuator geom that drove it.

    Matching is by SUFFIX so one parameter covers both sides of a mirrored tree
    (``shoulder_yaw_dof: false`` takes out ``left_shoulder_yaw`` and
    ``right_shoulder_yaw``). The actuator is found through the ``motor_for`` key
    a tree puts on the geometry block that draws it, because in these trees a
    body draws its CHILD's actuator — the link from joint to geom is not
    something a name can be relied on to carry.
    """
    removed = [] if removed is None else removed
    if not roles:
        return removed
    j = node.get('joint')
    if isinstance(j, dict):
        jname = str(j.get('name', node.get('name', '')))
        if any(jname == r or jname.endswith(f'_{r}') for r in roles):
            node['joint'] = None
            removed.append(jname)
    g = node.get('geometry')
    if isinstance(g, dict) and g.get('motor_for') in roles:
        g['motor_class'] = None
    for child in node.get('children', []) or []:
        prune_disabled_joints(child, roles, removed)
    return removed


def _resolve_tree(node: dict, params: dict, scope: dict | None = None) -> dict:
    """Resolve all ${} expressions in a tree node, recursing into children.

    ``scope`` holds the loop variables of any enclosing ``for_each``; they shadow
    parameters of the same name for the duration of that subtree.
    """
    ns = params if not scope else {**params, **scope}
    result = {}
    for k, v in node.items():
        if k == 'children':
            result[k] = _expand_children(v or [], params, scope)
        else:
            result[k] = _resolve_value(v, ns)
    return result


def _expand_children(children: list, params: dict, scope: dict | None) -> list:
    """Resolve a `children` list, instantiating every `for_each` entry.

    ``for_each`` is what makes a variable-length limb array declarative — a hand
    whose finger count is a parameter, rather than a `tree.py` that assembles the
    same dicts in Python. It is the same idea as `mirror_of`, which is a loop of
    two with a reflection; this one is a loop of N with the item in scope::

        - for_each: ${fingers}          # any expression yielding a list
          as: f                         # name the item is bound to (default: item)
          where: ${f.dof_type == '2dof'}    # optional filter
          node:                         # the subtree, instantiated once per item
            name: ${f.name}_metacarpal
            ...

    ``where`` exists so a tree can send different items to different subtrees —
    a finger with three joints is a different MJCF module from one with two, and
    that is a choice of FILE, not a conditional inside a node. Deliberately, that
    is the only branching the syntax has: anything finer belongs in a module.
    """
    out: list[dict] = []
    for child in children:
        if 'for_each' not in child:
            out.append(_resolve_tree(child, params, scope))
            continue
        base = params if not scope else {**params, **scope}
        items = _resolve_value(child['for_each'], base)
        if not isinstance(items, (list, tuple)):
            raise ValueError(f"for_each must resolve to a list, got "
                             f"{type(items).__name__}: {child['for_each']!r}")
        alias = str(child.get('as', 'item'))
        template = child.get('node')
        if not isinstance(template, dict):
            raise ValueError("a for_each entry needs a `node:` subtree to repeat")
        for index, item in enumerate(items):
            inner = {**(scope or {}), alias: attrdict(item),
                     f'{alias}_index': index}
            if 'where' in child and not _resolve_value(child['where'],
                                                       {**params, **inner}):
                continue
            out.append(_resolve_tree(template, params, inner))
    return out


# ── Scene.xml writer ───────────────────────────────────────────────────────────

def _write_scene(output_dir: Path, robot_name: str) -> None:
    (output_dir / 'scene.xml').write_text(
        f'<mujoco>\n'
        f'  <include file="./{robot_name}.xml"/>\n'
        f'  <worldbody>\n'
        f'    <geom name="floor" type="plane" size="10 10 0.1" pos="0 0 0"\n'
        f'          rgba="0.8 0.8 0.8 1" contype="1" conaffinity="1"/>\n'
        f'    <light name="top_light" pos="0 0 5" dir="0 0 -1" diffuse="0.6 0.6 0.6"/>\n'
        f'  </worldbody>\n'
        f'</mujoco>\n',
        encoding='utf-8',
    )


# ── Public API ─────────────────────────────────────────────────────────────────

class RobotGenerator:
    """Generates MJCF for a robot from tree.yaml + mesh.py + parameters.yaml.

    Parameters
    ----------
    robot_dir : Path
        Directory containing parameters.yaml, tree.yaml and (optional) mesh.py.

    Usage
    -----
    gen = RobotGenerator(Path('src/draft/robots/humanoid'))
    out = gen.generate(Path('generated/humanoid_test'))
    """

    def __init__(self, robot_dir: Path) -> None:
        self.robot_dir = Path(robot_dir)
        self.params       = _load_yaml(self.robot_dir / 'parameters.yaml')
        self.mesh         = _load_root_mesh(self.robot_dir)

        # Prefer tree.py (programmatic) over tree.yaml (static)
        self._tree_fn = _load_tree_fn(self.robot_dir)
        self.tree     = ({} if self._tree_fn is not None
                         else _load_yaml(self.robot_dir / 'tree.yaml'))

    @property
    def name(self) -> str:
        return self.robot_dir.name

    def _build_tree(self, params: dict) -> dict:
        """Resolve ${}, expand mirrors, drop disabled joints. Pure — re-callable."""
        raw_tree = self._tree_fn(params) if self._tree_fn is not None else self.tree
        tree = expand_mirrors(_resolve_tree(raw_tree, params))
        # After mirroring, so one `<role>_dof: false` covers both sides.
        prune_disabled_joints(tree, disabled_roles(params))
        return tree

    def generate(self,
                 output_dir: Path,
                 params_override: dict | None = None,
                 strict: bool = True) -> Path:
        """Generate MJCF into output_dir and return output_dir.

        Every robot is sized and vetted by the fitted physical laws on the way
        out (see ``core/feasibility.py``). With ``strict`` (the default) a design that
        beats the catalogued actuator frontier raises ``FeasibilityViolation`` instead of
        being written to disk.
        """
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        params = dict(self.params)
        if params_override:
            params.update(params_override)

        # 1. Motor classes: catalogue names → torque/speed, then the fitted trends
        #    derive envelope, mass and reflected rotor inertia.
        params = resolve_catalog_motors(params)
        params, actuator_report = size_actuators(params, strict=strict)
        # Segment densities the population has measured (head, hand, foot …).
        # Before the expression pass, so a `${}` rule may key off a derived one.
        params, density_report = derive_segment_densities(params)
        params = _expand_motor_params(params)
        params = _resolve_param_exprs(params)

        # 2. First tree pass — needed to count the actuators the pack must feed.
        expanded = self._build_tree(params)
        joints = collect_joints(expanded)

        # 3. Battery law: torso density follows from the power the design installs.
        #    Opt-in, because only robots whose root body houses the pack should
        #    have their trunk mass set this way.
        battery_report = None
        mesh_volume = None
        if self.mesh is not None:
            # Re-run below if the battery trend moves the density, so the saved
            # inertial properties always match the emitted model.
            _, mesh_props = self.mesh.build_and_save(params, output_dir)
            mesh_volume = float(mesh_props['volume'])
        population = reference_population(params)
        pop_fits = link_fits(population)

        # 3a. Volume convention. `trunk_density` is m / V_box, with V_box the
        #     solid box that reproduces the segment's principal inertias — the
        #     only volume datasets/robot_descriptions can compute without ever opening a mesh
        #     file. The generated torso is a lofted solid, and its MESH volume is
        #     a different quantity: 3.55 L against an 8.11 L inertia box on the
        #     G1 twin, so applying the measurement straight to it under-charges
        #     the trunk 2.3x. Rescale by the shape factor, and the emitted body
        #     then weighs rho_measured * V_box exactly as the measurement means.
        trunk_shape = None
        if (mesh_volume and not params.get('battery_sized_torso')
                and 'torso_rho' in density_report.get('derived', {})):
            box_v = _inertia_box_volume(mesh_props)
            if box_v and box_v > 0:
                factor = box_v / mesh_volume
                measured = float(params['torso_rho'])
                params['torso_rho'] = measured * factor
                trunk_shape = {
                    'measured_rho_kg_m3': round(measured, 2),
                    'mesh_volume_m3': round(mesh_volume, 6),
                    'inertia_box_volume_m3': round(box_v, 6),
                    'shape_factor': round(factor, 4),
                    'applied_rho_kg_m3': round(params['torso_rho'], 2),
                    'why': 'the measured density is mass / inertia-equivalent-box '
                           'volume; the emitted geom is charged on MESH volume, so '
                           'the ratio is applied to keep the mass the measurement '
                           'implies',
                }
                density_report['derived']['torso_rho']['volume_convention'] = trunk_shape
                expanded = self._build_tree(params)

        if params.get('battery_sized_torso') and mesh_volume:
            p_installed = installed_power_W(joints, params)
            battery = BatteryTrend(legacy=bool(params.get('legacy_battery_law', False)))
            pack = battery.size_pack(p_installed)
            # The enclosure is priced at the population's own measured trunk
            # structure — a quadruped body shell is not a humanoid pelvis.
            shell_rho = params.get('torso_shell_rho', pop_fits.trunk_shell_density())
            torso_mass = battery.torso_mass(p_installed, mesh_volume, shell_rho)
            declared = params.get('torso_rho')
            params['torso_rho'] = torso_mass / mesh_volume
            battery_report = {
                'n_actuators': len(joints),
                'installed_power_W': round(p_installed, 1),
                'pack_mass_kg': round(pack['mass_kg'], 4),
                'pack_binding_constraint': pack['binding'],
                'pack_SE_Wh_per_kg': round(pack['SE_pack_Wh_per_kg'], 2),
                'pack_SP_W_per_kg': round(pack['SP_pack_W_per_kg'], 1),
                'energy_Wh': round(pack['energy_Wh'], 1),
                'electronics_kg_asserted': battery.M_ELECTRONICS_KG,
                'shell_kg': round(battery.shell_mass(mesh_volume, shell_rho), 4),
                'shell_rho_kg_m3': round(shell_rho, 1),
                'shell_rho_source': ('declared torso_shell_rho'
                                     if 'torso_shell_rho' in params
                                     else f'{population} trunk structure (datasets/robot_descriptions)'),
                'torso_mass_kg': round(torso_mass, 4),
                'torso_volume_m3': round(mesh_volume, 6),
                'torso_rho_kg_m3': round(params['torso_rho'], 2),
                'torso_rho_declared': declared,
            }
            fit_errors, fit_warns = pop_fits.check_trunk_density(params['torso_rho'])
            actuator_report['warnings'].extend(fit_warns)
            if fit_errors:
                if strict and not params.get('allow_hypothetical'):
                    raise FeasibilityViolation(fit_errors)
                actuator_report['warnings'].extend(
                    f'allow_hypothetical: {m}' for m in fit_errors)
            # Re-resolve: a tree is free to reference ${torso_rho}.
            expanded = self._build_tree(params)

        # 4. Root mesh: re-save at the trend-derived density so its inertial
        #    properties YAML agrees with the MJCF.
        mesh_stl = None
        if self.mesh is not None:
            if battery_report is not None or trunk_shape is not None:
                self.mesh.build_and_save(params, output_dir)
            mesh_stl = f'{self.mesh.name}_mesh.stl'

        # 4b. Distal taper: pin each limb chain's λ gradient to the one its
        #     population measures. Last, because it rewrites resolved geometry
        #     and must see the final tree. Only chains whose fitted CI EXCLUDES
        #     1.0 are applied — the humanoid arm's does not, so the data cannot
        #     resolve a gradient there and none is imposed.
        taper_targets = {}
        if (params.get('taper_mode')
                and params.get('mass_composition_reference') in LinkTrends.POPULATIONS):
            for chain in ('leg', 'arm'):
                law = pop_fits.distal_taper(chain)
                if not law:
                    continue
                lo, hi = law['per_step_ci95']
                if lo < 1.0 < hi:
                    continue
                taper_targets[chain] = law['per_step']
        # 4a. Structural limb members. A link that declares a measured segment
        #     class (`link_mass_class: thigh`) carries the structural mass that
        #     class's length trend gives for its joint-to-joint length. The
        #     emitter solves its radius over the length the member actually
        #     occupies, so no radius is stated or calibrated for it anywhere.
        _assign_structural_mass(expanded, pop_fits,
                                params.get('mass_composition_reference'))

        taper_report = apply_distal_taper(
            expanded, {**params, 'taper_rho_band': pop_fits.link_density_band()},
            taper_targets)
        if taper_report:
            actuator_report['warnings'].extend(taper_report['warnings'])

        # Build the model through MjSpec and COMPILE it before writing anything.
        # Compiling is not a validation step bolted on the end — it is where the
        # actuator world poses the packing gate reads come from, and where a
        # model that MuJoCo would reject fails loudly instead of being written to
        # disk for a consumer to trip over later.
        emitter = SpecEmitter(self.name, mesh_stl, robot_dir=self.robot_dir,
                              asset_dir=output_dir)
        emitter.emit(expanded, params)
        model = emitter.compile(mesh_volume)
        actuator_report['warnings'].extend(emitter.module_warnings)
        if emitter.stated_members:
            actuator_report['warnings'].append(
                f"{len(emitter.stated_members)} structural member(s) declare no "
                f"link_mass_class, so their radius and density are stated rather "
                f"than derived: {', '.join(sorted(emitter.stated_members))}")
        for geom, e in (emitter.structural_link_report() or {}).items():
            if e['density_raised_at_cap'] and e['density_kg_m3'] > 2 * e['class_density_kg_m3']:
                actuator_report['warnings'].append(
                    f"{geom}: to weigh its {e['emitted_member_kg']:.3f} kg share of the "
                    f"{e['class']} trend inside the actuators it joins, the member's "
                    f"density is {e['density_kg_m3']:.0f} kg/m³ against the class's "
                    f"{e['class_density_kg_m3']:.0f}")
            if e['floored_at_5pct']:
                actuator_report['warnings'].append(
                    f"{geom}: the {e['fixed_in_segment_kg']:.3f} kg already in the "
                    f"segment exceeds the {e['class']} trend's {e['target_kg']:.3f} kg, "
                    f"so the member is floored at 5% of the target")
        xml_path = output_dir / f'{self.name}.xml'
        xml_path.write_text(emitter.to_string(), encoding='utf-8')
        # Assets a module brought with it (meshes). The emitted XML references
        # them by bare filename, so they belong beside the model — and they have
        # to be there BEFORE the round-trip check reloads it, since a missing
        # mesh is exactly the kind of broken artifact that check exists to catch.
        for dest, src in emitter.module_assets.items():
            shutil.copy2(src, output_dir / dest)
        roundtrip = emitter.roundtrip_check(xml_path, float(model.body_mass.sum()))

        # 5. Audit the assembled mass composition against the datasets/robot_descriptions fits for
        #    the design's OWN population, and write the whole derivation next to
        #    the model. A design that declares no population (the hands) has
        #    nothing measured to be compared against and is not audited.
        masses = emitter.mass_report(mesh_volume)
        # The role split is computed from the densities and envelopes that were
        # emitted; MuJoCo weighs the model itself. If they disagree, every trend
        # below is being applied to a different robot than the one on disk, so
        # this is surfaced rather than left in the returned dict.
        if masses.get('disagreement'):
            actuator_report['warnings'].append(masses['disagreement'])
        audited = params.get('mass_composition_reference') in LinkTrends.POPULATIONS
        audit = (pop_fits.audit(masses['by_role'],
                                size_m=size_metric(params, expanded, population),
                                mass_by_body=masses['by_body'],
                                trunk_patterns=params.get('trunk_bodies'))
                 if audited else
                 {'reference_population': params.get('mass_composition_reference'),
                  'total_mass_kg': masses['total'], 'checks': [],
                  'note': 'no measured population declared — mass composition '
                          'not audited (set mass_composition_reference to one of '
                          f'{", ".join(LinkTrends.POPULATIONS)})'})
        # 5b. Actuator packing. Two motor cylinders that share volume are not a
        #     robot; the mass is charged twice into the same space and nothing
        #     downstream notices. Strict by default, like the actuator frontier,
        #     and opted out of the same way.
        packing_report = packing.check(
            emitter.motor_geoms,
            exempt=set(params.get('packing_exempt_geoms') or ()))
        pack_msgs = packing.messages(packing_report)
        actuator_report['warnings'].extend(packing.soft_messages(packing_report))
        if pack_msgs:
            if strict and not params.get('allow_motor_overlap'):
                raise FeasibilityViolation(pack_msgs)
            actuator_report['warnings'].extend(f'allow_motor_overlap: {m}'
                                            for m in pack_msgs)

        # 5c. Actuator against STRUCTURE. The gate above pairs actuators with
        #     each other; this is the other half of the same question, and it is
        #     ENFORCED the same way. An actuator inside the trunk is the same
        #     failure as two actuators inside each other — one litre of space
        #     holding two solids, its mass charged at both their densities — and
        #     for a while it was only priced, on the argument that a design
        #     integrating a shoulder unit into its trunk is doing something real
        #     robots do. That argument covers the roles a design DECLARES, and
        #     nothing else: `structure_overlap_allowed` names them, and any other
        #     actuator found in there is now a violation.
        struct_overlap = packing.structure_overlap(
            emitter.model, emitter.model_data,
            float(params.get('torso_rho', 1000.0)),
            role_of={m['name']: m.get('drives') for m in emitter.motor_geoms})
        actuator_report['warnings'].extend(packing.structure_messages(
            struct_overlap, masses['by_role'].get('torso', 0.0)))
        struct_msgs = packing.structure_violations(
            struct_overlap, params.get('structure_overlap_allowed') or ())
        if struct_msgs:
            if strict and not params.get('allow_actuator_in_structure'):
                raise FeasibilityViolation(struct_msgs)
            actuator_report['warnings'].extend(
                f'allow_actuator_in_structure: {m}' for m in struct_msgs)

        act_audit = actuator_mass_audit(joints, params,
                                        masses['by_role'].get('motor', 0.0))
        ratio = act_audit['emitted_over_charged']
        if ratio is not None and abs(ratio - 1.0) > 0.05:
            actuator_report['warnings'].append(
                f"emitted motor geoms weigh {act_audit['emitted_motor_geom_kg']:.2f} kg, "
                f"{ratio:.2f}x the {act_audit['charged_by_motor_law_kg']:.2f} kg the "
                f"actuator trends charge for {act_audit['n_joints']} declared joints — "
                f"the tree draws an actuator more than once, or overrides a "
                f"trend-derived motor_r/motor_L. Every mass trend below is being applied "
                f"to a robot the motor trend did not price.")

        report = {
            'robot': self.name,
            'actuator_checks': actuator_report,
            'segment_densities': density_report,
            'battery_sizing': battery_report,
            'actuator_mass_audit': act_audit,
            'actuator_packing': packing_report,
            'actuator_in_structure': struct_overlap,
            'mass_kg': {k: round(v, 4) for k, v in sorted(masses['by_role'].items())},
            'total_mass_kg': round(masses['total'], 4),
            'mass_composition_check': audit,
            'distal_taper': taper_report,
            'link_render': emitter.link_render_report(params.get('link_rho')),
            'link_inset': emitter.link_inset_report(),
            'structural_links': emitter.structural_link_report(),
            'foot_render': emitter.foot_render_report(),
            'xml_roundtrip': roundtrip,
        }
        # The taper is audited whether or not it was APPLIED: a design that does
        # not opt into `taper_mode` still gets told that its limb spreads its
        # mass differently from the population, which no mass check can see.
        if audited:
            for chain, got in sorted(measured_taper(expanded, params).items()):
                law = pop_fits.distal_taper(chain)
                if not law:
                    continue
                lo, hi = law['per_step_ci95']
                audit.setdefault('checks', []).append({
                    'quantity': f'{chain}_distal_taper',
                    'value': round(got, 4),
                    'status': 'ok' if lo <= got <= hi else 'outside_ci95',
                    'measured': law['per_step'], 'ci95': [lo, hi],
                    'r2': law['r2'], 'n': law['n'], 'n_robots': law['n_robots'],
                    'unit': 'x per chain step (structural mass per metre)',
                })
        warnings = list(actuator_report['warnings']) + pop_fits.warnings(audit)
        report['warnings'] = warnings
        (output_dir / 'feasibility_report.yaml').write_text(
            yaml.safe_dump(report, sort_keys=False), encoding='utf-8')
        (output_dir / 'parameters_resolved.yaml').write_text(
            yaml.safe_dump({k: v for k, v in sorted(params.items())},
                           sort_keys=False), encoding='utf-8')
        for msg in warnings:
            print(f'WARNING {msg}')

        # Copy any additional .xml assets from the robot directory (e.g. cube.xml
        # for the hand).  These are tracked source files, not generated output.
        for xml_asset in self.robot_dir.glob('*.xml'):
            shutil.copy2(xml_asset, output_dir / xml_asset.name)

        _write_scene(output_dir, self.name)
        print(f'Generated {self.name} → {output_dir}')
        return output_dir

    @staticmethod
    def make_output_dir(base_dir: Path, prefix: str) -> Path:
        """Create a timestamped subdirectory under base_dir."""
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        d  = Path(base_dir) / f'{prefix}_{ts}'
        n  = 1
        while d.exists():
            d = Path(base_dir) / f'{prefix}_{ts}_{n:02d}'
            n += 1
        d.mkdir(parents=True)
        return d
