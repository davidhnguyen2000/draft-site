"""Builds a MuJoCo model from a resolved kinematic tree, through `mujoco.MjSpec`.

This replaces a hand-written `xml.etree` emitter. The difference is not stylistic:

* **The model is compiled before it is written.** Everything downstream that used
  to be re-derived from the tree — where an actuator sits in the world, what the
  robot weighs — is now read back from MuJoCo's own compiled model. The packing
  gate in particular used to assume "no body in any tree carries a rotation and
  every motor axis is a world axis", which was not an observation about robots
  but a restriction the arithmetic imposed on them. Real frames come out of
  `mj_forward`, so a design is free to cant a hip.

* **Subtrees can be real MJCF files.** A tree node that names a `module:` has
  that file parsed, parameterised, and attached with MuJoCo's own namespacing.
  A module is a valid model on its own — it opens in `simulate`, it has nominal
  numbers in it — which is the property a template language cannot have. See
  `_attach_module` for the contract.

The emitted XML is `spec.to_xml()`: normalised MuJoCo output, and a build
artifact. Source comments live in the robot's own files, not in the export.
"""
from __future__ import annotations

import math
from pathlib import Path
from typing import Any

import mujoco

from .tree_ops import (LINK_MOTOR_PENETRATION_M, avec, axis_center,
                       drawn_radius, euler_for_axis, link_span, proximal_inset,
                       geom_volume, motor_props, rgba, slim_density)


_GEOM_TYPE = {
    'sphere':   mujoco.mjtGeom.mjGEOM_SPHERE,
    'cylinder': mujoco.mjtGeom.mjGEOM_CYLINDER,
    'capsule':  mujoco.mjtGeom.mjGEOM_CAPSULE,
    'box':      mujoco.mjtGeom.mjGEOM_BOX,
    'mesh':     mujoco.mjtGeom.mjGEOM_MESH,
}

_SENSOR_TYPE = {
    'gyro':          (mujoco.mjtSensor.mjSENS_GYRO,          mujoco.mjtObj.mjOBJ_SITE),
    'accelerometer': (mujoco.mjtSensor.mjSENS_ACCELEROMETER, mujoco.mjtObj.mjOBJ_SITE),
    'velocimeter':   (mujoco.mjtSensor.mjSENS_VELOCIMETER,   mujoco.mjtObj.mjOBJ_SITE),
    'framepos':      (mujoco.mjtSensor.mjSENS_FRAMEPOS,      mujoco.mjtObj.mjOBJ_SITE),
    'framequat':     (mujoco.mjtSensor.mjSENS_FRAMEQUAT,     mujoco.mjtObj.mjOBJ_SITE),
    'subtreeangmom': (mujoco.mjtSensor.mjSENS_SUBTREEANGMOM, mujoco.mjtObj.mjOBJ_BODY),
    'subtreecom':    (mujoco.mjtSensor.mjSENS_SUBTREECOM,    mujoco.mjtObj.mjOBJ_BODY),
    'subtreelinvel': (mujoco.mjtSensor.mjSENS_SUBTREELINVEL, mujoco.mjtObj.mjOBJ_BODY),
}

#: MuJoCo's own default when a geom states neither mass nor density.
_DEFAULT_DENSITY = 1000.0


def _size3(vals) -> list:
    """MjSpec size fields are always length 3; pad what we are given."""
    out = [float(v) for v in vals]
    return (out + [0.0, 0.0, 0.0])[:3]


def _set_euler(elem, euler) -> None:
    """Point an element with Euler angles.

    `alt.euler` alone does nothing: `alt` is MuJoCo's alternative-orientation
    union and it stays on its default `quat` branch until `alt.type` selects
    another. Writing the angles without switching the branch silently emits an
    unrotated element — every motor cylinder came out axis-aligned, which the
    packing gate then read as a 7 mm interpenetration in the humanoid torso.
    """
    if not euler:
        return
    elem.alt.type = mujoco.mjtOrientation.mjORIENTATION_EULER
    elem.alt.euler = _size3(euler)


def _module_joints(bodies) -> list:
    """Every joint in a module's body tree. `spec.joints` is empty before a
    compile, so the tree has to be walked."""
    out = []
    for b in bodies:
        out.extend(b.joints)
        out.extend(_module_joints(b.bodies))
    return out


def _perdof(v: float) -> list:
    """Joint damping and stiffness are per-DOF vectors in MjSpec.

    A hinge has one DOF and MJCF's scalar form lands in slot 0, which is what
    `to_xml` reads back out as a scalar — writing the value into all three would
    round-trip as a three-vector nobody meant.
    """
    return [float(v), 0.0, 0.0]


class SpecEmitter:
    """Builds an `mujoco.MjSpec` from a resolved, mirror-expanded tree dict."""

    def __init__(self, model_name: str, mesh_stl: str | None = None,
                 robot_dir: Path | None = None, asset_dir: Path | None = None):
        self.spec = mujoco.MjSpec()
        self.spec.modelname = model_name
        self._mesh_name = Path(mesh_stl).stem if mesh_stl else None
        self._mesh_file = mesh_stl
        self._robot_dir = Path(robot_dir) if robot_dir else None
        self._asset_dir = Path(asset_dir) if asset_dir else None
        self._params: dict = {}

        self._motor_joints: list[tuple[str, dict]] = []
        # geom name → mass role, tagged at emission so the link-trend audit can
        # split the robot into actuator / structure / trunk without re-deriving
        # what each geom was from its name.
        self._geom_roles: dict[str, str] = {}
        # geom name → (mass_kg, body_name). Recorded as each geom is created,
        # which is the only moment the density and the envelope that produced it
        # are both in hand; validated against the compiled model in `compile`.
        self._geom_mass: dict[str, tuple] = {}
        self._link_render: dict[str, dict] = {}
        #: Links shortened so they stop at their actuator's housing face rather
        #: than running to the joint centre through it — see tree_ops.link_span.
        self._link_inset: dict[str, dict] = {}
        self._structural_links: dict[str, dict] = {}
        #: Members emitted with a stated radius/density rather than a class law.
        self.stated_members: list[str] = []
        #: body name -> the actuator IT draws, as {mp, axis, ctr}. A child reads
        #: its parent's entry to trim the end of its member that starts inside
        #: it — see `tree_ops.proximal_inset`.
        self._body_motor: dict[str, dict] = {}
        #: body name -> its parent body's name, for that lookup.
        self._parent_body: dict[str, str] = {}
        self._foot_render: dict[str, dict] = {}
        # Actuator cylinders, by geom name. World placement is filled in after
        # compilation from `mj_forward`, not accumulated from body offsets.
        self._motor_records: dict[str, dict] = {}
        self._body_pairs: list[tuple[str, str]] = []
        self._model: mujoco.MjModel | None = None
        self._model_data = None
        #: Integrity complaints raised while attaching modules, surfaced by the
        #: generator alongside the trend warnings rather than swallowed here.
        self.module_warnings: list[str] = []
        #: Mesh/asset files a module referenced, as {filename in the emitted XML:
        #: source path}. The generator copies these next to the model — without
        #: it a module that uses meshes emits a file that will not load.
        self.module_assets: dict[str, Path] = {}
        # Module mesh name → its volume in m³, measured from the file. A mesh
        # geom's volume cannot be read off its size fields the way a primitive's
        # can, and without this every mesh in a module weighs nothing in the role
        # split — which is what the link-trend audit is computed from.
        self._module_mesh_vol: dict[str, float] = {}
        # tree node name → the body a module actually attached under. A module's
        # root body carries its own name from its own file (`index_proximal`,
        # not `index`), and contact excludes have to name the real body.
        self._module_roots: dict[str, str] = {}
        self._mesh_volume: float | None = None
        self._setup()

    # ── Model-level setup ──────────────────────────────────────────────────────

    def _setup(self) -> None:
        self.spec.compiler.degree = False           # angles in radians
        self.spec.compiler.autolimits = True
        opt = self.spec.option
        opt.timestep = 0.002
        opt.iterations = 50
        opt.solver = mujoco.mjtSolver.mjSOL_NEWTON
        opt.tolerance = 1e-10

        # Root defaults: every physical geom collides, every joint has a little
        # damping. Patched per robot in `emit` from parameters.yaml.
        d = self.spec.default
        d.geom.contype = 1
        d.geom.conaffinity = 1
        d.geom.condim = 3
        d.geom.friction = [0.7, 0.1, 0.1]
        d.joint.damping = _perdof(0.01)

        self._visual = self.spec.add_default('visual', self.spec.default)
        self._visual.geom.contype = 0
        self._visual.geom.conaffinity = 0
        self._visual.geom.group = 2

        if self._mesh_name:
            # The STL is written into the output directory by the mesh builder
            # before this runs. It is handed to the compiler as bytes rather than
            # by setting `meshdir`, so the emitted XML keeps a bare relative
            # filename and no absolute path from this machine leaks into it.
            self.spec.add_mesh(name=self._mesh_name, file=self._mesh_file)
            if self._asset_dir:
                stl = self._asset_dir / self._mesh_file
                if stl.exists():
                    self.spec.assets = {self._mesh_file: stl.read_bytes()}

    # ── Entry point ────────────────────────────────────────────────────────────

    def emit(self, tree: dict, params: dict) -> None:
        self._params = params
        # Robots that need specific contact dynamics (the hand, for in-hand
        # manipulation) state them in parameters.yaml; everything else takes the
        # builder defaults.
        d = self.spec.default
        if 'geom_friction' in params:
            d.geom.friction = _size3(str(params['geom_friction']).split())
        if 'geom_solimp' in params:
            d.geom.solimp = ([float(x) for x in str(params['geom_solimp']).split()]
                             + [0.0] * 5)[:5]
        if 'geom_solref' in params:
            d.geom.solref = ([float(x) for x in str(params['geom_solref']).split()]
                             + [0.0] * 2)[:2]

        self._build_body(self.spec.worldbody, tree)
        self._emit_contact_excludes(tree)

        # No <actuator> block: the controller (PD for RL, torque for trajopt) is
        # owned by the consumer, not the model. Each motor's two static limits go
        # where both consumers read them — peak torque onto the joint's
        # actuatorfrcrange (Pinocchio reads it as effortLimit, mjlab as
        # jnt_actfrcrange), and no-load speed into a custom numeric, since MuJoCo
        # joints have no native velocity-limit field.
        for jname, mp in self._motor_joints:
            self.spec.add_numeric(name=f'{jname}_velocity_limit',
                                  data=[float(mp['velocity'])])

        for s in tree.get('sensors', []) or []:
            self._emit_sensor(s)

    # ── Body dispatch ──────────────────────────────────────────────────────────

    def _build_body(self, parent, node: dict):
        name = node['name']
        t = node.get('type', 'basic')

        # A module node is a whole MJCF file, attached rather than built.
        if 'module' in node:
            return self._attach_module(parent, node)

        body = parent.add_body(name=name,
                               pos=_size3(node.get('pos', [0, 0, 0])))
        self._parent_body[name] = str(getattr(parent, 'name', '') or '')
        _set_euler(body, node.get('euler'))

        if t == 'root':
            body.add_freejoint(name=f'{name}_freejoint')
        elif isinstance(node.get('joint'), dict):
            self._emit_joint(body, node, node['joint'])

        if   t == 'root':   self._emit_root_geoms(body, node)
        elif t == 'basic':  self._emit_basic_geoms(body, node)
        elif t == 'sphere': self._emit_sphere_geoms(body, node)
        elif t == 'foot':   self._emit_foot_geoms(body, node)
        elif t == 'geom':   self._emit_geom(body, node)

        for site in node.get('sites', []) or []:
            body.add_site(name=site['name'],
                          pos=_size3(site.get('pos', [0, 0, 0])), group=5)

        for child in node.get('children', []) or []:
            self._build_body(body, child)
        return body

    # ── Modules ────────────────────────────────────────────────────────────────

    def _attach_module(self, parent, node: dict):
        """Attach a real MJCF file as a subtree.

        The contract, which is deliberately small:

          module:  path to an .xml, relative to the robot directory. It is an
                   ordinary MuJoCo model — nominal numbers, loadable on its own.
          prefix:  namespace for every name it brings in. Defaults to `<name>_`.
          set:     `<kind>.<name>.<attr>: value` overrides applied BEFORE attach,
                   addressing the module's own elements by their own names. This
                   is what makes a nominal file parametric without templating it:
                   `body.distal.pos`, `geom.prox_link.size`, `joint.mcp.range`.
          joints:  `<joint name>: <motor class>`. The laws price actuators per
                   declared joint, so a module's joints have to be declared to be
                   paid for — this is where the class's armature, damping,
                   friction and torque limit are stamped onto them.
          motors:  `<geom name>: <motor class>`. Resizes that geom to the
                   trend-derived envelope and density for the class, so a module's
                   drawn actuator is the actuator the trends charged for.
          roles:   `<geom name>: <mass role>` for the link-trend audit. Geoms whose
                   names end in `_motor` or `_link` are classified without it.

        The sub-spec is re-read on every call: `attach` consumes what it is given,
        and attaching one parsed module twice compounds its prefix.
        """
        path = (self._robot_dir or Path('.')) / str(node['module'])
        if not path.exists():
            raise FileNotFoundError(f"module '{node['module']}' not found at {path}")
        sub = mujoco.MjSpec.from_file(str(path))
        # Before `set:`, so a per-element override still wins — a fingertip that
        # needs more grip than the rest of the hand says so in the assembly.
        self._stamp_contact(sub)

        for key, val in (node.get('set') or {}).items():
            kind, _, rest = str(key).partition('.')
            ename, _, attr = rest.rpartition('.')
            if not (kind and ename and attr):
                raise ValueError(
                    f"module set key '{key}' must read <kind>.<name>.<attr>, "
                    f"e.g. body.distal.pos")
            lookup = getattr(sub, kind, None)
            if not callable(lookup):
                raise ValueError(
                    f"module set key '{key}' names an unknown element kind "
                    f"'{kind}' — expected one of body, geom, joint, site")
            # MjSpec RETURNS None for a name it does not have rather than
            # raising, so a typo would otherwise surface as an AttributeError on
            # NoneType several lines later, naming the attribute and not the
            # element that is actually missing.
            elem = lookup(ename)
            if elem is None:
                raise ValueError(
                    f"module '{node['module']}' has no {kind} named '{ename}' "
                    f"(from set key '{key}')")
            cur = getattr(elem, attr)
            # Vector attributes are fixed-width in MjSpec; match what is there.
            if hasattr(cur, '__len__') and not isinstance(cur, (str, bytes)):
                vals = [float(v) for v in (val if isinstance(val, (list, tuple))
                                           else str(val).split())]
                setattr(elem, attr, (vals + [0.0] * len(cur))[:len(cur)])
            else:
                setattr(elem, attr, type(cur)(val) if cur is not None else val)

        prefix = str(node.get('prefix', f"{node['name']}_"))
        # Mass bookkeeping has to happen while the module's own geoms are still
        # addressable; after attach they carry the prefix.
        pending = [(f'{prefix}{g.name}', g) for g in sub.geoms if g.name]
        roles = {str(k): str(v) for k, v in (node.get('roles') or {}).items()}
        # What the module weighs on its own, straight from MuJoCo. The per-geom
        # split below has to be computed by hand because roles are per geom and
        # MuJoCo only reports mass per body — but the TOTAL is checkable, and an
        # unnamed geom or a shape this file's volume math does not cover would
        # otherwise go into the model weighing something nobody accounted for.
        module_mass = float(sub.copy().compile().body_mass.sum())

        sub_bodies = list(sub.worldbody.bodies)
        if not sub_bodies:
            raise ValueError(f"module '{node['module']}' declares no body")
        self._module_roots[node['name']] = f'{prefix}{sub_bodies[0].name}'
        # Read before attaching: `attach` moves the module's elements into this
        # spec, and the handles captured from the sub-spec do not survive it.
        module_joint_names = {j.name for j in _module_joints(sub_bodies)}

        frame = parent.add_frame(pos=_size3(node.get('pos', [0, 0, 0])))
        _set_euler(frame, node.get('euler'))
        self._claim_module_assets(sub, prefix, path)
        self.spec.attach(sub, prefix=prefix, frame=frame)

        for full_name, g in pending:
            gtype = str(mujoco.mjtGeom(g.type).name).replace('mjGEOM_', '').lower()
            # An UNSET fromto reads back as [nan, 0, 0, 0, 0, 0], and nan is
            # truthy — testing it with any() sends a nan into the volume and
            # every mass downstream comes out nan.
            ft = list(g.fromto)
            fromto = ft if all(v == v for v in ft) else None
            mesh_vol = self._module_mesh_vol.get(str(g.meshname)) if gtype == 'mesh' else None
            mass = (float(g.mass) if float(g.mass) > 0 else
                    float(g.density if g.density else _DEFAULT_DENSITY)
                    * geom_volume(gtype, list(g.size), fromto, mesh_vol))
            bare = full_name[len(prefix):]
            role = roles.get(bare, roles.get(full_name))
            if role is None:
                role = ('motor' if bare.endswith('_motor') else
                        'detail' if bare.endswith('_detail') else 'link')
            self._geom_roles[full_name] = role
            self._geom_mass[full_name] = (mass, node['name'])
            if role == 'motor':
                self._motor_records[full_name] = {
                    'name': full_name, 'body': node['name'],
                    'motor_class': None, 'drives': None,
                    'path': (node['name'],),
                }

        accounted = sum(m for n, (m, _) in self._geom_mass.items()
                        if n.startswith(prefix))
        if module_mass > 0 and abs(accounted - module_mass) / module_mass > 0.01:
            self.module_warnings.append(
                f"module '{node['module']}' compiles to {module_mass:.4f} kg but "
                f"{accounted:.4f} kg was attributed to roles — an unnamed geom, or "
                f"a shape whose volume this builder does not compute. Every mass "
                f"law below is applied to the first figure and audited on the "
                f"second, so they have to agree.")

        # `motors:` resizes a module's actuator geoms to the LAW-DERIVED envelope
        # for their class. Without it a module ships whatever cylinder its author
        # drew, the actuator-mass audit reports the disagreement, and every mass
        # law below is applied to a robot the motor trend never priced. The laws
        # own motor radius, length and density everywhere else in this
        # repository; a module does not get to be the exception.
        for gname, cls in (node.get('motors') or {}).items():
            mp = motor_props(str(cls), self._params)
            full = f'{prefix}{gname}'
            g = self.spec.geom(full)
            g.size = _size3([mp['r'], mp['L'] / 2])
            g.density = mp['rho']
            # `mass` is deliberately left alone. It defaults to NaN, meaning
            # "derive me from density"; assigning 0.0 does not clear it, it
            # asserts a massless geom — which silently zeroed every module
            # actuator while the role accounting went on charging for them.
            vol = geom_volume('cylinder', [mp['r'], mp['L'] / 2])
            self._geom_roles[full] = 'motor'
            self._geom_mass[full] = (mp['rho'] * vol, node['name'])
            self._motor_records[full] = {
                'name': full, 'body': node['name'],
                'motor_class': str(cls), 'drives': None,
                'r': float(mp['r']), 'L': float(mp['L']),
            }

        declared = {str(k) for k in (node.get('joints') or {})}
        actual = module_joint_names
        undeclared = sorted(actual - declared)
        if undeclared:
            self.module_warnings.append(
                f"module '{node['module']}' has joint(s) {', '.join(undeclared)} that "
                f"the assembly does not declare under `joints:`. They enter the model "
                f"unpriced by the actuator trends and unactuated — no torque limit, no "
                f"armature, no reflected inertia.")
        missing = sorted(declared - actual)
        if missing:
            raise ValueError(
                f"module '{node['module']}' has no joint(s) named "
                f"{', '.join(missing)}, declared under `joints:`")

        for jname, cls in (node.get('joints') or {}).items():
            mp = motor_props(str(cls), self._params)
            j = self.spec.joint(f'{prefix}{jname}')
            j.armature = mp['armature']
            j.damping = _perdof(mp['damping'])
            j.frictionloss = mp['friction']
            j.actfrclimited = mujoco.mjtLimited.mjLIMITED_TRUE
            j.actfrcrange = [-mp['effort'], mp['effort']]
            self._motor_joints.append((f'{prefix}{jname}', mp))
        return None

    def _stamp_contact(self, sub) -> None:
        """Give a module's geoms the ASSEMBLY's contact dynamics, per geom.

        Contact is a property of the machine being simulated, not of the part: a
        hand generated for in-hand manipulation declares near-rigid contacts, and
        a finger that keeps MuJoCo's factory `solref` inside that hand is a
        different simulation from the one the robot asked for.

        It has to be stamped per GEOM. A module's `<default>` classes are already
        resolved by the time the file is parsed — a geom in class `phalanx` reads
        back the factory friction as its own value — so writing the parameters
        onto the attached class reaches nothing that names a class, which is
        every geom in a module that bothers to define one.
        """
        p = self._params
        friction = (_size3(str(p['geom_friction']).split())
                    if 'geom_friction' in p else None)
        solimp = (([float(x) for x in str(p['geom_solimp']).split()] + [0.0] * 5)[:5]
                  if 'geom_solimp' in p else None)
        solref = (([float(x) for x in str(p['geom_solref']).split()] + [0.0] * 2)[:2]
                  if 'geom_solref' in p else None)
        for g in sub.geoms:
            if friction is not None:
                g.friction = friction
            if solimp is not None:
                g.solimp = solimp
            if solref is not None:
                g.solref = solref

    def _claim_module_assets(self, sub, prefix: str, module_path: Path) -> None:
        """Take ownership of the files a module's assets point at.

        `attach` namespaces a mesh's NAME but not its `file`, and the assets do
        not travel with it — so a module that uses meshes compiled fine here (its
        own directory was on the search path) and then emitted a model that could
        not be opened, because the STL was never next to it. Every referenced
        file is resolved against the module's own directory and registered for
        the generator to copy out.

        Filenames are namespaced only when two modules disagree about what a
        given name means, so the common case stays readable.
        """
        base = Path(getattr(sub, 'modelfiledir', '') or module_path.parent)
        meshdir = str(getattr(sub, 'meshdir', '') or '')
        for mesh in sub.meshes:
            ref = str(mesh.file or '')
            if not ref:
                continue                     # inline vertices, nothing to copy
            src = (base / meshdir / ref) if meshdir else (base / ref)
            src = src.resolve()
            if not src.is_file():
                self.module_warnings.append(
                    f"module '{module_path.name}' references asset '{ref}', which is "
                    f"not at {src}. The emitted model will not load.")
                continue
            dest = Path(ref).name
            if self.module_assets.get(dest, src) != src:
                dest = f'{prefix}{dest}'     # same name, different file
            self.module_assets[dest] = src
            mesh.file = dest
            try:
                import trimesh
                loaded = trimesh.load(str(src), force='mesh')
                scale = float(getattr(mesh, 'scale', [1.0, 1.0, 1.0])[0] or 1.0)
                vol = abs(float(loaded.volume)) * scale ** 3
                # Under BOTH names. This runs before `attach`, but the geoms are
                # read after it — and by then their `meshname` has been renamed
                # to the namespaced form, so the bare key would never be hit.
                self._module_mesh_vol[str(mesh.name)] = vol
                self._module_mesh_vol[f'{prefix}{mesh.name}'] = vol
            except Exception as exc:
                self.module_warnings.append(
                    f"module '{module_path.name}': could not measure the volume of "
                    f"'{ref}' ({type(exc).__name__}), so its mass is missing from the "
                    f"role breakdown the link-trend audit reads.")
        # The module's own meshdir was relative to ITS directory; the files are
        # about to sit beside the model instead.
        if meshdir:
            sub.meshdir = ''

    # ── Joint ──────────────────────────────────────────────────────────────────

    def _emit_joint(self, body, node: dict, jspec: dict) -> None:
        jname = jspec.get('name', node['name'])
        cls = str(jspec['motor_class'])
        overrides = {k: jspec[k] for k
                     in ('effort', 'velocity', 'friction', 'damping', 'armature')
                     if k in jspec}
        mp = motor_props(cls, self._params, overrides)
        lo, hi = jspec['range']
        j = body.add_joint(name=jname, type=mujoco.mjtJoint.mjJNT_HINGE,
                           axis=_size3(avec(str(jspec['axis']))))
        j.limited = mujoco.mjtLimited.mjLIMITED_TRUE
        j.range = [float(lo), float(hi)]
        j.actfrclimited = mujoco.mjtLimited.mjLIMITED_TRUE
        j.actfrcrange = [-mp['effort'], mp['effort']]
        j.damping = _perdof(mp['damping'])
        j.frictionloss = mp['friction']
        j.armature = mp['armature']
        self._motor_joints.append((jname, mp))

    # ── Geom helpers ───────────────────────────────────────────────────────────

    def _add_geom(self, body, name: str, gtype: str, size, role: str,
                  pos=(0, 0, 0), euler=None, color=None, density: float | None = None,
                  mass: float | None = None, fromto=None, cls=None,
                  friction=None) -> None:
        """Create a geom and record what it weighs and what role it plays."""
        g = body.add_geom(name=name, type=_GEOM_TYPE[gtype], size=_size3(size))
        if fromto is not None:
            g.fromto = [float(x) for x in fromto]
        else:
            g.pos = _size3(pos)
        _set_euler(g, euler)
        if color is not None:
            g.rgba = rgba(color)
        if cls is not None:
            g.classname = cls
        if friction is not None:
            g.friction = _size3(friction)
        if mass is not None:
            g.mass = float(mass)
            resolved = float(mass)
        else:
            rho = _DEFAULT_DENSITY if density is None else float(density)
            g.density = rho
            resolved = rho * geom_volume(gtype, _size3(size), fromto,
                                         self._mesh_volume)
        self._geom_roles[name] = role
        self._geom_mass[name] = (resolved, body.name)

    def _draw_link(self, geom_name: str, g: dict, r_struct: float,
                   link_l: float, mp: dict | None, link_axis: str = 'z',
                   motor_axis: str | None = None,
                   node: dict | None = None) -> float:
        parent = (self._body_motor.get(self._parent_body.get(node['name'], ''))
                  if node else None)
        r_draw = drawn_radius(g, self._params, r_struct, mp, link_axis,
                              motor_axis, (parent or {}).get('mp'),
                              (parent or {}).get('axis'))
        if abs(r_draw - r_struct) > 1e-12:
            self._link_render[geom_name] = {
                'r_structural_m': round(r_struct, 6),
                'r_drawn_m': round(r_draw, 6),
                'length_m': round(link_l, 6),
            }
        return r_draw

    def _structural_cap(self, g: dict, node: dict, mp: dict | None,
                        link_axis: str, motor_axis: str | None) -> float:
        """Widest a structural member may be: the faces of the actuators it joins.

        The one it carries (or that drives it) and the one its parent carries.
        A coaxial actuator presents its radius; a broadside one presents a
        `2r × L` flat, so the member's radius is bounded by min(r, L/2). An
        optional `link_r_max` bounds it further.
        """
        from .tree_ops import structural_radius_cap
        parent = (self._body_motor.get(self._parent_body.get(node['name'], ''))
                  or {})
        cap = structural_radius_cap(mp, motor_axis, parent.get('mp'),
                                    parent.get('axis'), link_axis)
        if 'link_r_max' in g:
            cap = min(cap, float(g['link_r_max']))
        return cap

    def _structural_link_r(self, geom_name: str, g: dict, mass_kg: float,
                           rho: float, length: float, fixed_kg: float = 0.0,
                           cap: float = math.inf) -> float:
        """Radius at which a member weighs the structural mass its class trend gives.

        `mass_kg` is this member's share of its segment's trend mass
        (`LinkTrends.structural_mass` at the segment's joint-to-joint length);
        `length` is the stretch the cylinder occupies after it is trimmed at its
        actuators, and `fixed_kg` is anything else in the same measured segment
        (a foot or hand sphere), which is paid first. Two bounds, both reported:
        a member is never wider than the actuators it joins (`cap`), and never
        less than 5% of the target, so a segment whose fixed mass already
        exceeds the trend keeps a member at all.
        """
        cyl_kg = mass_kg - fixed_kg
        floored = cyl_kg < 0.05 * mass_kg
        cyl_kg = max(cyl_kg, 0.05 * mass_kg)
        r = math.sqrt(cyl_kg / (rho * math.pi * length))
        capped = r > cap
        if capped:
            # Mass and inertia come first, density second. At the class density
            # the member would have to be wider than the actuators it joins, so
            # it is kept at the widest they allow and its density is raised until
            # it weighs its share of the segment's trend mass.
            r = cap
            member_rho = cyl_kg / (math.pi * r * r * length)
        else:
            member_rho = rho
        law = g.get('link_mass_basis') or {}
        self._structural_links[geom_name] = {
            'class': law.get('segment'),
            'basis': law.get('basis'),
            'segment_root': law.get('segment_root'),
            'share_of_segment': law.get('share'),
            'joint_to_joint_m': round(float(law.get('length_m', length)), 6),
            'lambda_kg_per_m': round(float(law.get('lambda_kg_per_m', 0.0)), 4),
            'target_kg': round(mass_kg, 4),
            'fixed_in_segment_kg': round(fixed_kg, 4),
            'structural_length_m': round(length, 6),
            'class_density_kg_m3': round(rho, 2),
            'density_kg_m3': round(member_rho, 2),
            'r_m': round(r, 6),
            'r_cap_m': round(cap, 6) if math.isfinite(cap) else None,
            'emitted_member_kg': round(member_rho * math.pi * r * r * length, 4),
            'density_raised_at_cap': bool(capped),
            'floored_at_5pct': bool(floored),
        }
        return r, member_rho

    def structural_link_report(self) -> dict | None:
        """Per member of a measured class: the trend target and the radius solved for it."""
        return dict(sorted(self._structural_links.items())) or None

    # ── Geom emitters ──────────────────────────────────────────────────────────

    def _emit_root_geoms(self, body, node: dict) -> None:
        if not self._mesh_name:
            return
        g = body.add_geom(name=f'{node["name"]}_mesh',
                          type=mujoco.mjtGeom.mjGEOM_MESH)
        g.meshname = self._mesh_name
        g.rgba = rgba(node.get('color', '0.5 0.5 0.5 1'))
        rho = float(self._params.get(node.get('density_param', 'torso_rho'), 100.0))
        g.density = rho
        self._geom_roles[f'{node["name"]}_mesh'] = 'torso'
        # Mesh volume is not known from the size fields; it is supplied by the
        # mesh builder and patched in by `mass_report`.
        self._geom_mass[f'{node["name"]}_mesh'] = (('mesh', rho), body.name)

    def _proximal_inset(self, node: dict, link_axis: str, link_sign: int,
                        link_unit, penetration: float) -> float:
        """Where this body's member has to start to clear its parent's actuator.

        The parent draws the actuator for the joint THIS body hangs from, on the
        same point, so the member starts inside it unless it is trimmed. See
        `tree_ops.proximal_inset` for why that overlap is fixed rather than
        angle-dependent.

        Skipped for a body that carries its own rotation: `euler` puts the two
        frames at an angle this rule has no closed form for, and no tree here
        does it on a jointed member.
        """
        parent = self._body_motor.get(self._parent_body.get(node['name'], ''))
        if parent is None or node.get('euler'):
            return 0.0
        pos = [float(v) for v in _size3(node.get('pos', [0, 0, 0]))]
        # Where the parent's actuator sits along THIS link's axis, measured from
        # this body's origin. Non-zero when the parent shifted it off the joint.
        along = link_sign * sum((parent['ctr'][i] - pos[i]) * link_unit[i]
                                for i in range(3))
        return proximal_inset(parent['mp'], parent['axis'], along, link_axis,
                              penetration=penetration)

    def _emit_basic_geoms(self, body, node: dict) -> None:
        g = node.get('geometry', {})
        name = node['name']
        p = self._params

        link_axis = str(g.get('link_axis', 'z'))
        link_l = float(g['link_l'])
        link_r = float(g.get('link_r', p.get('link_r', 0.02)))
        link_rho = float(g.get('link_rho', p.get('link_rho', 500.0)))
        link_color = g.get('link_color', p.get('link_color', '0.5 0.5 0.5 1'))
        motor_axis = str(g.get('motor_axis', 'x'))
        # `motor_class: null` means this body's actuator was pruned with the joint
        # it drove (see `prune_disabled_joints`). The structural link stays — the
        # limb segment is still there, it simply does not bend at that point.
        motor_cls = g.get('motor_class')
        mp = motor_props(str(motor_cls), p) if motor_cls else None
        # The DRAWN link radius keys off the motor class's own length, before any
        # per-link override — `link_render_radius_scale` is a rendering rule about
        # the size class, and a knee whose `motor_rho: 0` says "already paid for"
        # must not also change how wide its link is drawn.
        mp_draw = mp

        # Per-link motor overrides. `motor_rho: 0` draws an actuator part WITHOUT
        # weighing it — a drivetrain modelled as two bodies (a belt-driven knee:
        # motor at the hip, output at the joint) where the motor trend has already
        # charged the whole actuator once. Without it the actuator is paid for
        # twice; `actuator_mass_audit` is what catches that.
        if mp is not None and {'motor_r', 'motor_L', 'motor_rho'} & set(g):
            mp = dict(mp)
            for key, prop in (('motor_r', 'r'), ('motor_L', 'L'), ('motor_rho', 'rho')):
                if key in g:
                    mp[prop] = float(g[key])

        # The motor sits at the tip of the link, or on the body origin when the
        # body carries no link. Compare base axes only, so mirroring does not
        # break the coaxial check.
        link_base = link_axis.lstrip('+-')
        link_sign = -1 if link_axis.startswith('-') else 1
        link_unit = avec(link_base)
        motor_base = motor_axis.lstrip('+-')
        mot_offset = shift = mot_ctr = mot_euler = None
        if mp is not None:
            axes_align = mp['L'] / 2 if link_base == motor_base else 0
            mot_offset = 0.0 if link_l <= 0 else link_l - axes_align
            # `motor_offset` pulls the actuator BACK along the link, toward the
            # parent, instead of centring it on the child joint — the ankle roll
            # unit is centred on the ankle joint by default, so a cylinder of
            # radius `ankle_roll_motor_r` reaches that far below the sole and the
            # robot stands on its actuator.
            mot_offset -= float(g.get('motor_offset', 0.0))
            # `motor_shift` translates the actuator PERPENDICULAR to its link,
            # where two actuators on one body would otherwise occupy the same
            # space (the quadruped hip). Shifting separates them for real, and
            # the packing gate then checks it rather than being told to look away.
            shift = [float(v) for v in (g.get('motor_shift') or (0.0, 0.0, 0.0))]
            mot_ctr = tuple(link_sign * v * mot_offset + sv
                            for v, sv in zip(link_unit, shift))
            mot_euler = euler_for_axis(motor_axis)

        # `link_l: 0` means the body IS its actuator, with no structural member
        # of its own — a housing bolted straight onto its parent (the quadruped
        # hip-roll motor, flush against the torso wall).
        if link_l > 0:
            def span(r_d: float) -> tuple[float, float]:
                # Stop the structural member at the face of its own actuator
                # instead of running it to the joint centre through the middle of
                # the motor. See `tree_ops.link_span`: coaxial, that overlap is the
                # actuator's WHOLE length, charged once as structure and once as
                # actuator.
                if not p.get('link_motor_inset', True):
                    return 0.0, link_l
                pen = float(p.get('link_motor_penetration', LINK_MOTOR_PENETRATION_M))
                return link_span(
                    link_l, mot_offset if mot_offset is not None else link_l, mp,
                    link_axis, motor_axis, shift, r_d, penetration=pen,
                    t0=self._proximal_inset(node, link_axis, link_sign,
                                            link_unit, pen))

            mass_kg = g.get('link_mass_kg')
            if mass_kg is not None:
                # A member of a measured class has no stated radius: it weighs
                # its class trend's mass over the length it actually occupies,
                # no wider than either actuator it joins. The cap bounds the
                # provisional drawn radius the span is cut with.
                cap = self._structural_cap(g, node, mp_draw, link_axis, motor_axis)
                link_r = cap if math.isfinite(cap) else link_r
            else:
                self.stated_members.append(f'{name}_link')
            r_draw = self._draw_link(f'{name}_link', g, link_r, link_l, mp_draw,
                                     link_axis, motor_axis, node)
            t0, t1 = span(r_draw)
            if mass_kg is not None:
                link_r, link_rho = self._structural_link_r(
                    f'{name}_link', g, float(mass_kg), link_rho,
                    max(t1 - t0, 1e-6), cap=cap)
                self._link_render.pop(f'{name}_link', None)
                r_draw = self._draw_link(f'{name}_link', g, link_r, link_l, mp_draw,
                                         link_axis, motor_axis, node)
                t0, t1 = span(r_draw)
            seg = max(t1 - t0, 1e-6)
            if seg < link_l - 1e-9:
                self._link_inset[f'{name}_link'] = {
                    'joint_to_joint_m': round(link_l, 6),
                    'structural_m': round(seg, 6),
                    'removed_m': round(link_l - seg, 6),
                    'removed_frac': round(1.0 - seg / link_l, 4),
                }
            self._add_geom(
                body, f'{name}_link', 'cylinder', [r_draw, seg / 2], 'link',
                pos=axis_center(link_axis, t0 + seg / 2),
                euler=euler_for_axis(link_axis), color=link_color,
                density=slim_density(link_rho, link_r, r_draw))

        if mp is None:
            return

        self._add_geom(body, f'{name}_motor', 'cylinder', [mp['r'], mp['L'] / 2],
                       'motor', pos=mot_ctr, euler=mot_euler,
                       color=mp['color'], density=mp['rho'])
        self._motor_records[f'{name}_motor'] = {
            'name': f'{name}_motor', 'body': name,
            'motor_class': str(motor_cls), 'drives': g.get('motor_for'),
            'r': float(mp['r']), 'L': float(mp['L']),
        }
        self._body_motor[name] = {'mp': mp, 'axis': motor_axis,
                                  'ctr': [float(v) for v in mot_ctr]}
        # Detail ring — visual only, weightless.
        self._add_geom(body, f'{name}_detail', 'cylinder',
                       [mp['r'] * 0.8, mp['L'] * 0.55], 'detail',
                       pos=mot_ctr, euler=mot_euler, color=mp['detail'],
                       density=0.0, cls=self._visual)

    def _emit_sphere_geoms(self, body, node: dict) -> None:
        g = node.get('geometry', {})
        name = node['name']
        p = self._params

        link_axis = str(g.get('link_axis', 'z'))
        link_l = float(g['link_l'])
        link_r = float(g.get('link_r', p.get('link_r', 0.02)))
        link_rho = float(g.get('link_rho', p.get('link_rho', 500.0)))
        link_color = g.get('link_color', p.get('link_color', '0.5 0.5 0.5 1'))
        sphere_r = float(g['sphere_r'])
        sphere_dir = int(g.get('sphere_dir', 1))
        sphere_color = g.get('sphere_color', link_color)

        av = avec(link_axis)
        cyl_ctr = tuple(v * sphere_dir * link_l / 2 for v in av)
        sph_ctr = tuple(v * sphere_dir * link_l for v in av)

        # A sphere link (hand, head) carries no motor of its own, so the drawn
        # radius keys off the motor driving its joint when there is one.
        jcls = str((node.get('joint') or {}).get('motor_class', '')
                   or g.get('motor_class', ''))
        mp = motor_props(jcls, p) if jcls else None
        # The cylinder's own density; the sphere keeps `sphere_rho` / `link_rho`.
        member_rho = link_rho
        if g.get('link_mass_kg') is not None:
            # The sphere at the end (a quadruped's foot) sits in the same measured
            # segment as the member, so the trend's mass pays for it first.
            sphere_kg = (float(g.get('sphere_rho', link_rho))
                         * 4.0 / 3.0 * math.pi * sphere_r ** 3)
            link_r, member_rho = self._structural_link_r(
                f'{name}_link', g, float(g['link_mass_kg']), link_rho, link_l,
                fixed_kg=sphere_kg,
                cap=self._structural_cap(g, node, mp, link_axis,
                                         str(g.get('motor_axis', link_axis))))
        elif link_l > 0:
            self.stated_members.append(f'{name}_link')
        r_draw = self._draw_link(f'{name}_link', g, link_r, link_l, mp,
                                 link_axis, str(g.get('motor_axis', link_axis)),
                                 node)

        self._add_geom(body, f'{name}_link', 'cylinder', [r_draw, link_l / 2],
                       'link', pos=cyl_ctr, euler=euler_for_axis(link_axis),
                       color=link_color,
                       density=slim_density(member_rho, link_r, r_draw))

        # A head and a hand are not structural members and must not be weighed
        # like one. Both are shells around empty volume, and `datasets/robot_descriptions`'s
        # per-class effective densities measure exactly that: head 449 kg/m³
        # (n=13) and hand 504 (n=28) against a structural `link_rho` of 700.
        sphere_rho = float(g.get('sphere_rho', link_rho))
        role = ('head' if 'head' in name else 'hand' if 'hand' in name else 'link')
        # A surface that needs its own contact — a fingertip that has to grip —
        # states it on the geometry block. It used to be read from a global
        # `fingertip_friction` parameter and applied to EVERY sphere of any robot
        # that declared the key, which was the hand's contact model living in the
        # engine; the hand is assembled from modules now and stamps friction onto
        # its own tip geoms.
        friction = ([float(v) for v in g['friction']] if 'friction' in g else None)
        self._add_geom(body, f'{name}_sphere', 'sphere', [sphere_r], role,
                       pos=sph_ctr, color=sphere_color, density=sphere_rho,
                       friction=friction)

    def _emit_foot_geoms(self, body, node: dict) -> None:
        g = node.get('geometry', {})
        name = node['name']
        p = self._params

        foot_l = float(g['foot_l'])
        foot_w = float(g['foot_w'])
        foot_h = float(g.get('foot_h', p.get('foot_h', 0.025)))
        offset_x = float(g.get('foot_offset_x', p.get('foot_offset_x', 0.03)))
        color = g.get('color', p.get('foot_color', '0.5 0.5 0.5 1'))
        link_rho = float(p.get('link_rho', 500.0))
        mot_cls = str((node.get('joint') or {}).get('motor_class', 'S'))
        mot_r = float(p.get(f'{mot_cls}_motor_r', 0.04))

        # A foot is a SOLE PLATE on a RISER: the plate is what touches the
        # ground, the riser is the member between the ankle-roll axis and the
        # plate's top face. Both belong to THIS body because the roll unit turns
        # them — which is the whole point of drawing the riser here.
        #
        # The riser used to be missing, and the gap it should have filled was
        # paid for on the parent instead: the shank's link ran a further
        # `ankle_roll_motor_r` past its own actuator down to the plate, and the
        # actuator was pushed that far back UP its link (`motor_offset`) to keep
        # it out of the sole. The result reads exactly wrong — the roll actuator
        # sits a full radius above the axis it drives, and the joint appears to
        # pivot at the end of a bare stub that disappears into the foot. Seated
        # on its own axis with the riser under it, the actuator turns the foot
        # about its own centreline, which is what the hardware does.
        box_h = float(g.get('foot_plate_h', p.get('foot_plate_h', 0.015)))
        # Ankle-to-sole is a real distance now, not a plate thickness: the riser
        # makes up the rest of the MEASURED `foot_h` envelope, and is never
        # shorter than the roll actuator's radius or that actuator would sit in
        # the sole. `tree.yaml` stands the robot on `max(foot_h, mot_r + plate)`
        # for the same reason — keep the two rules in step.
        riser_h = max(foot_h - box_h, mot_r)
        riser_r = float(g.get('riser_r', mot_r))
        box_rho = float(g.get('foot_rho', p.get('foot_rho', link_rho)))
        # MASS comes from the trend's envelope, not the plate's own volume.
        # `foot_rho` was measured against each real foot's inertia-equivalent
        # box — the whole ankle-to-sole envelope. Multiplying it by a 15 mm plate
        # applies a density measured on one volume to a smaller one, and charged
        # the G1 twin 70 g for a foot that weighs 610 g.
        box_mass = box_rho * foot_l * foot_w * foot_h

        # Weightless: `box_mass` above already charges the whole ankle-to-sole
        # envelope, which is the volume the riser stands in. Giving it a density
        # would charge the same foot twice.
        self._add_geom(body, f'{name}_riser', 'cylinder', [riser_r, riser_h / 2],
                       'foot', pos=(0, 0, -riser_h / 2),
                       color=g.get('riser_color', color), density=0.0)
        self._add_geom(body, f'{name}_box', 'box',
                       [foot_l / 2, foot_w / 2, box_h / 2], 'foot',
                       pos=(offset_x, 0, -riser_h - box_h / 2), color=color,
                       mass=box_mass)
        self._foot_render[f'{name}_box'] = {
            'ankle_to_sole_m': round(riser_h + box_h, 6),
            'foot_h_measured_m': round(foot_h, 6),
            'ankle_motor_r_m': round(mot_r, 6),
            'riser_height_m': round(riser_h, 6),
            'riser_radius_m': round(riser_r, 6),
            'plate_thickness_m': round(box_h, 6),
            'plate_rho_kg_m3': round(box_rho, 2),
            'plate_mass_kg': round(box_mass, 6),
            # Signed: negative when the fit-sized roll actuator is FATTER than
            # the real foot is deep, so the emitted ankle stands taller than the
            # machine it copies. Reported rather than chased — shrinking it would
            # put the actuator through the sole.
            'ankle_to_sole_deficit_m': round(foot_h - (riser_h + box_h), 6),
        }

        bottom_z = -(riser_h + box_h)
        sites_xy = [
            (foot_l / 2 + offset_x,  foot_w / 2),
            (foot_l / 2 + offset_x, -foot_w / 2),
            (-foot_l / 2 + offset_x,  foot_w / 2),
            (-foot_l / 2 + offset_x, -foot_w / 2),
            (foot_l / 2 + offset_x,  0),
        ]
        names = [f'{name}_sphere_{i}' for i in range(4)] + [f'{name}_toe_sphere']
        for sname, (sx, sy) in zip(names, sites_xy):
            body.add_site(name=sname, pos=[sx, sy, bottom_z], group=3)

    def _emit_geom(self, body, node: dict) -> None:
        g = node.get('geometry', {})
        name = node['name']
        shape = g.get('shape', 'cylinder')
        color = g.get('color', '0.5 0.5 0.5 1')
        rho = float(g.get('rho', self._params.get('motor_rho', 2700.0)))
        r = float(g['r'])
        mass = float(g['mass']) if 'mass' in g else None

        # Role `other`, not `link`: a raw primitive is an escape hatch (a payload
        # slab, an eye) and the link-trend audit's structure fraction is fit
        # against limb members. Anything that really is structure says so with
        # `roles:` or a typed link, rather than being swept in by its shape.
        role = str(g.get('role', 'other'))

        # `decorative: true` — an eye, a bezel, a livery panel. It is drawn and
        # it is WEIGHTLESS, the same contract the motor's detail ring already
        # has: a feature that exists to be looked at must not turn up in a mass
        # budget the feasibility trends are then judged against. It also leaves
        # the collision set, because a decoration that can be stood on is not a
        # decoration.
        kw = {}
        if bool(g.get('decorative', False)):
            rho, mass, kw = 0.0, None, {'cls': self._visual}

        if shape == 'sphere':
            self._add_geom(body, f'{name}_geom', 'sphere', [r], role,
                           color=color, density=rho, mass=mass, **kw)
        elif shape in ('cylinder', 'capsule'):
            if 'fromto' in g:
                self._add_geom(body, f'{name}_geom', shape, [r], role,
                               fromto=[float(x) for x in g['fromto']],
                               color=color, density=rho, mass=mass, **kw)
            else:
                l = float(g['l'])
                self._add_geom(body, f'{name}_geom', shape, [r, l / 2], role,
                               euler=euler_for_axis(str(g.get('axis', 'z'))),
                               color=color, density=rho, mass=mass, **kw)
        elif shape == 'box':
            lx = float(g.get('lx', r))
            ly = float(g.get('ly', r))
            lz = float(g.get('lz', g.get('l', r)))
            self._add_geom(body, f'{name}_geom', 'box', [lx / 2, ly / 2, lz / 2],
                           role, color=color, density=rho, mass=mass, **kw)

    # ── Contacts and sensors ───────────────────────────────────────────────────

    def _collect_body_pairs(self, node: dict, parent: str | None = None,
                            grandparent: str | None = None) -> list[tuple[str, str]]:
        """1- and 2-hop neighbour pairs in the kinematic tree.

        1-hop is covered by MuJoCo's `filterparent`, but listed explicitly for
        robustness across versions. 2-hop is NOT covered, and is needed for the
        hand, where compact motor geometry puts a metacarpal in spurious contact
        with its grandchild proximal body.
        """
        pairs: list[tuple[str, str]] = []
        name = self._module_roots.get(node['name'], node['name'])
        if 'module' in node:
            # A module's internal contacts are the module's own business; only
            # the seam between it and what it bolts to is excluded here.
            if parent:
                pairs.append((parent, name))
            return pairs
        if parent:
            pairs.append((parent, name))
        if grandparent:
            pairs.append((grandparent, name))
        for child in node.get('children', []) or []:
            pairs.extend(self._collect_body_pairs(child, name, parent))
        return pairs

    def _emit_contact_excludes(self, tree: dict) -> None:
        for b1, b2 in self._collect_body_pairs(tree):
            self.spec.add_exclude(name=f'{b1}__{b2}', bodyname1=b1, bodyname2=b2)

    def _emit_sensor(self, s: dict) -> None:
        stype = str(s['type'])
        if stype not in _SENSOR_TYPE:
            raise ValueError(f'unsupported sensor type: {stype}')
        kind, objtype = _SENSOR_TYPE[stype]
        objname = s.get('site') or s.get('body') or s.get('objname')
        self.spec.add_sensor(name=s.get('name', stype), type=kind,
                             objtype=objtype, objname=str(objname))

    # ── Compilation ────────────────────────────────────────────────────────────

    def compile(self, mesh_volume_m3: float | None = None) -> mujoco.MjModel:
        """Compile, then read the world back out of MuJoCo rather than guessing it.

        Actuator world placements come from `mj_forward` at the neutral pose, so
        the packing gate sees the frames the model actually has — including any
        rotation, which the previous arithmetic could not represent.
        """
        self._mesh_volume = mesh_volume_m3
        self._model = self.spec.compile()
        model = self._model
        data = mujoco.MjData(model)
        mujoco.mj_forward(model, data)
        # Kept so a check that needs world placement — the actuator-vs-structure
        # test in `packing.structure_overlap` — reads the same compiled pose the
        # packing gate does rather than compiling the model a second time.
        self._model_data = data

        for name, rec in self._motor_records.items():
            gid = mujoco.mj_name2id(model, mujoco.mjtObj.mjOBJ_GEOM, name)
            if gid < 0:
                continue
            size = model.geom_size[gid]
            rec['center'] = tuple(float(v) for v in data.geom_xpos[gid])
            rec['R'] = [float(v) for v in data.geom_xmat[gid]]
            # A cylinder's own frame puts its axis on local z; half-extents are
            # (r, r, L/2) there, whatever the body it hangs off is doing.
            rec['half'] = (float(size[0]), float(size[0]), float(size[1]))
            rec.setdefault('r', float(size[0]))
            rec.setdefault('L', float(size[1]) * 2.0)
            bid = model.geom_bodyid[gid]
            rec['path'] = self._body_path(model, bid)
        return model

    @staticmethod
    def _body_path(model, bid: int) -> tuple:
        """Body chain from the root, so the packing check can tell a pair of
        consecutive actuators on one limb from two that merely stand next to
        each other in the neutral pose."""
        chain = []
        while bid > 0:
            chain.append(mujoco.mj_id2name(model, mujoco.mjtObj.mjOBJ_BODY, bid))
            bid = model.body_parentid[bid]
        return tuple(reversed(chain))

    @property
    def motor_geoms(self) -> list:
        return list(self._motor_records.values())

    @property
    def model(self):
        return self._model

    @property
    def model_data(self):
        return getattr(self, '_model_data', None)

    # ── Mass accounting ────────────────────────────────────────────────────────

    def mass_report(self, mesh_volume_m3: float | None = None) -> dict:
        """Mass of the emitted model, broken down by role.

        Roles are per geom and MuJoCo only reports mass per body, so the split is
        computed from the densities and envelopes that were emitted. The TOTAL is
        then checked against the compiled model, which is a stronger invariant
        than the old emitter had: it re-walked its own XML and so could only ever
        agree with itself.
        """
        by_role: dict[str, float] = {}
        by_body: dict[str, float] = {}
        per_geom: dict[str, float] = {}

        for name, (mass, bname) in self._geom_mass.items():
            if isinstance(mass, tuple) and mass[0] == 'mesh':
                mass = float(mass[1]) * float(mesh_volume_m3 or 0.0)
            mass = float(mass)
            if mass <= 0:
                continue
            role = self._geom_roles.get(name, 'other')
            if role == 'detail':
                continue
            by_role[role] = by_role.get(role, 0.0) + mass
            by_body[bname] = by_body.get(bname, 0.0) + mass
            per_geom[name] = mass

        total = sum(by_role.values())
        report = {'by_role': by_role, 'by_body': by_body, 'per_geom': per_geom,
                  'total': total}
        if self._model is not None:
            compiled = float(self._model.body_mass.sum())
            report['compiled_total_kg'] = compiled
            if total > 0 and abs(compiled - total) / total > 0.01:
                report['disagreement'] = (
                    f'role accounting totals {total:.4f} kg but the compiled '
                    f'model weighs {compiled:.4f} kg')
        return report

    # ── Reports ────────────────────────────────────────────────────────────────

    def link_render_report(self, link_rho: float | None = None) -> dict | None:
        """How far drawn link cylinders were slimmed from their structural envelope.

        Emitted so nobody reading a density of 2100 kg/m³ in the XML mistakes it
        for a structural density: it is `link_rho` re-expressed against a thinner
        drawn cylinder, and ρ·V — the only thing any mass trend sees — is unchanged.
        """
        if not self._link_render:
            return None
        rho = float(link_rho if link_rho is not None
                    else self._params.get('link_rho', 0.0))
        ratios = [e['r_drawn_m'] / e['r_structural_m']
                  for e in self._link_render.values() if e['r_structural_m'] > 0]
        return {
            'n_links_slimmed': len(self._link_render),
            'structural_link_rho_kg_m3': round(rho, 2),
            'drawn_radius_over_structural': [round(min(ratios), 4),
                                             round(max(ratios), 4)],
            'emitted_density_kg_m3': [round(rho / max(ratios) ** 2, 1),
                                      round(rho / min(ratios) ** 2, 1)],
            'mass_effect': 'none — density compensates exactly; ρ·π·r²·L is invariant',
            'inertia_effect': ('slimmer cylinders: transverse inertia within a few '
                               'percent, axial inertia scales with (r_drawn/r_struct)² '
                               'and is dominated by the joint armature anyway'),
            'links': dict(sorted(self._link_render.items())),
        }

    def link_inset_report(self) -> dict | None:
        """How much structural length each link gave up to its own actuator.

        A `basic` body used to draw its link from the joint all the way to its
        tip and then draw the actuator centred on that tip, so the two solids
        overlapped over the whole depth the actuator reaches back — the
        actuator's ENTIRE length when the two are coaxial. That volume was
        charged twice, once at `link_rho` and once at the density the motor trend
        solved. This is the mass that double charge was worth.
        """
        if not self._link_inset:
            return None
        removed = [e['removed_frac'] for e in self._link_inset.values()]
        return {
            'n_links_inset': len(self._link_inset),
            'removed_fraction_of_length': [round(min(removed), 4),
                                           round(max(removed), 4)],
            'rule': ('a structural link stops at its actuator housing face plus '
                     'a bolt flange, rather than running to the joint centre '
                     'through the motor — see core/tree_ops.py:link_span'),
            'penetration_m': float(self._params.get(
                'link_motor_penetration', LINK_MOTOR_PENETRATION_M)),
            'scope': ('the DISTAL end only: this body\'s own actuator shares its '
                      'frame so the overlap is fixed, while the actuator at the '
                      'proximal end is on the far side of a joint and how much it '
                      'interpenetrates depends on the angle — core/packing.py '
                      'governs that pair instead'),
            'links': dict(sorted(self._link_inset.items())),
        }

    def foot_render_report(self) -> dict | None:
        return dict(sorted(self._foot_render.items())) or None

    def to_string(self) -> str:
        return self.spec.to_xml()

    @staticmethod
    def roundtrip_check(path: Path, expected_kg: float) -> dict:
        """Load the file that was just written and weigh it.

        MuJoCo's XML writer emits 6 significant figures and offers no way to ask
        for more, so the artifact on disk is a rounded copy of the model these
        reports describe — about 1e-6 relative, or 45 mg on a 45 kg humanoid.
        That is far below anything the fitted trends resolve, but it is a real gap
        between the numbers here and the file a consumer loads, so it is measured
        rather than assumed: this reloads the artifact and reports the drift.
        """
        model = mujoco.MjModel.from_xml_path(str(path))
        got = float(model.body_mass.sum())
        rel = abs(got - expected_kg) / expected_kg if expected_kg else 0.0
        return {
            'written_mass_kg': round(got, 6),
            'in_memory_mass_kg': round(expected_kg, 6),
            'relative_drift': float(f'{rel:.3g}'),
            'note': ('MuJoCo writes 6 significant figures; this is the cost of '
                     'that rounding, not a modelling difference'),
        }
