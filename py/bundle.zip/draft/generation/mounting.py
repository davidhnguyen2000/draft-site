"""Cross-section outlines, and placing parts on their boundary.

Two halves of the same idea, both pure 2-D geometry over a polygon with no
dependency on MuJoCo, trimesh or anything else — which is why a `${}` expression
is allowed to call them (see `expr_eval._SAFE`).

`rect_outline` builds the default outline of a slab-shaped root body. `mount_pos`
and `mount_euler` place a part on an EDGE of an outline and point it along that
edge's outward normal, so a mount stays attached to a face rather than to a
coordinate: reshape the polygon and the parts follow. A `mesh.yaml` lofts the
outline into a slab and a `tree.yaml` mounts parts on it, so the outline itself
has to be something either file can name.

That is not a hand-specific idea, which is why it lives here rather than in a
robot's own Python — it is the general "a limb leaves the trunk here, pointing
that way", and it is what lets the hand be a `tree.yaml` instead of a `tree.py`.

The polygon is 2-D in the root's own cross-section plane — for a palm extruded
along X, that is (y, z). A mount therefore returns a 3-vector with x = 0, and a
rotation about x that points the part's local +z along the edge's outward normal.
"""
from __future__ import annotations

import math


# ── Outline constructors ───────────────────────────────────────────────────────

def rect_outline(lu: float, lv: float, chamfer_factor: float = 0.15,
                 cu: float = 0.0, cv: float = 0.0) -> list:
    """A chamfered rectangle as 8 [u, v] vertices, CCW from the +axis side.

    The default outline for a slab-shaped root body: a rectangle `lu` x `lv`
    with its corners cut back by `chamfer_factor` of the shorter side. `cu`/`cv`
    offset the centre, which is how a palm puts its wrist edge at v = 0 rather
    than straddling the origin.
    """
    hu, hv = lu / 2.0, lv / 2.0
    c = min(lu, lv) * chamfer_factor
    if c <= 0 or c >= hu or c >= hv:
        raise ValueError(f'chamfer {c:.5f} out of range for lu={lu}, lv={lv}')
    return [
        [cu - hu + c, cv - hv],      # 0 bottom edge, near -u corner
        [cu + hu - c, cv - hv],      # 1 bottom edge, near +u corner
        [cu + hu,     cv - hv + c],  # 2 right edge,  near -v corner
        [cu + hu,     cv + hv - c],  # 3 right edge,  near +v corner
        [cu + hu - c, cv + hv],      # 4 top edge,    near +u corner
        [cu - hu + c, cv + hv],      # 5 top edge,    near -u corner
        [cu - hu,     cv + hv - c],  # 6 left edge,   near +v corner
        [cu - hu,     cv - hv + c],  # 7 left edge,   near -v corner
    ]


def edge_outward_normal(polygon: list, edge: int) -> tuple[float, float]:
    """Outward unit normal (ny, nz) of `polygon`'s edge `edge`.

    Outward is decided against the polygon's centroid rather than assumed from
    winding order, so a polygon drawn either way — and the GUI's editor lets a
    user drag vertices into either — gives the same answer.
    """
    n = len(polygon)
    if n < 3:
        raise ValueError(f'a mounting polygon needs at least 3 vertices, got {n}')
    y0, z0 = polygon[edge % n]
    y1, z1 = polygon[(edge + 1) % n]
    dy, dz = y1 - y0, z1 - z0
    length = math.hypot(dy, dz)
    if length < 1e-12:
        return (0.0, 1.0)                      # degenerate edge: point "up"
    a = (-dz / length, dy / length)
    cy = sum(v[0] for v in polygon) / n
    cz = sum(v[1] for v in polygon) / n
    inward = (cy - (y0 + y1) / 2, cz - (z0 + z1) / 2)
    return a if a[0] * inward[0] + a[1] * inward[1] <= 0 else (-a[0], -a[1])


def edge_point(polygon: list, edge: int, t: float = 0.5) -> tuple[float, float]:
    """The point `t` of the way along edge `edge`, as (y, z)."""
    n = len(polygon)
    y0, z0 = polygon[edge % n]
    y1, z1 = polygon[(edge + 1) % n]
    return (y0 + t * (y1 - y0), z0 + t * (z1 - z0))


def _anchored(polygon, spec: dict) -> bool:
    return bool(polygon) and 'palm_edge' in spec


def mount_pos(polygon: list, spec: dict) -> list:
    """Where a part mounts, as a body `pos`.

    `spec` is the part's own parameter dict. It anchors to the outline with
    ``palm_edge`` (+ optional ``palm_edge_t``), or states ``palm_pos_y`` /
    ``palm_pos_z`` directly — the GUI resolves an edge to coordinates as the user
    drags, and a hand-written parameters file names the edge. Both are honoured
    here so the tree needs no conditional of its own.
    """
    if _anchored(polygon, spec):
        y, z = edge_point(polygon, int(spec['palm_edge']),
                          float(spec.get('palm_edge_t', 0.5)))
    else:
        y, z = float(spec.get('palm_pos_y', 0.0)), float(spec.get('palm_pos_z', 0.0))
    return [0.0, y, z]


def mount_euler(polygon: list, spec: dict) -> list:
    """How a part is oriented at its mount, as a body `euler`.

    A roll about x that carries the part's local +z onto the edge's outward
    normal, so a finger leaves the palm perpendicular to the face it sits on.
    """
    if _anchored(polygon, spec):
        ny, nz = edge_outward_normal(polygon, int(spec['palm_edge']))
        angle = math.atan2(-ny, nz)
    else:
        angle = float(spec.get('exit_angle', 0.0))
    return [angle, 0.0, 0.0]
