"""Where things are, resolved once.

Seventeen modules used to each rebuild the repository root out of
``Path(__file__).parents[N]``, with N counted by hand from that file's depth.
Every one of them broke the first time a file moved, silently — a wrong root
does not raise, it just fails to find a description and skips a twin. So the
count lives here, once.

Two kinds of path, and the difference matters:

* **Package data** travels with an installed Draft — the fitted trends
  (``draft.trends``) and the robot specifications (``draft.robots``). Ask those
  packages, not this module.
* **Repository paths** exist only in a checkout: the vendor description cache the
  twins measure against, the generated-model directory, the experiment configs.
  An installed wheel has none of them, so :func:`repo_root` says so plainly
  rather than handing back a directory that does not exist.
"""

from pathlib import Path

#: ``src/draft`` — the installed package itself.
PACKAGE_DIR = Path(__file__).resolve().parent

#: The checkout root, when there is one. A wheel installed into site-packages
#: has no ``pyproject.toml`` two levels up, and this is then ``None``.
_candidate = PACKAGE_DIR.parent.parent
REPO_ROOT = _candidate if (_candidate / "pyproject.toml").exists() else None


def repo_root() -> Path:
    """The checkout root, or a clear failure.

    Raises RuntimeError rather than returning a plausible-looking wrong path,
    because the failure mode this replaced was a silently skipped twin.
    """
    if REPO_ROOT is None:
        raise RuntimeError(
            "no Draft checkout found: this needs repository files (the vendor "
            "description cache, configs/, generated/) that an installed "
            "package does not carry. Run from a clone of the repository.")
    return REPO_ROOT


def description_cache() -> Path:
    """Vendor robot descriptions the twins are measured against."""
    return repo_root() / "datasets" / "robot_descriptions" / "cache_extra"


def generated_dir() -> Path:
    """Where generators write. Gitignored; created on demand."""
    d = repo_root() / "generated"
    d.mkdir(parents=True, exist_ok=True)
    return d


def configs_dir() -> Path:
    """Experiment configuration that is not part of any robot's own spec."""
    return repo_root() / "experiments"
